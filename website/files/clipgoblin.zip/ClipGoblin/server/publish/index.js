// Publishing: OAuth for YouTube/TikTok/Instagram, publish/schedule endpoints, the scheduler loop and autopilot.
import fs from 'node:fs';
import path from 'node:path';
import { store } from '../store.js';
import { emit } from '../events.js';
import { PublishError, randomToken, pkceVerifier } from './util.js';
import { getRecord, setRecord, patchRecord, isConnected, rememberState, consumeState, getAccessToken } from './tokens.js';
import { buildMeta } from './captions.js';
import youtube from './youtube.js';
import tiktok, { tiktokMode } from './tiktok.js';
import instagram from './instagram.js';

export const PLATFORMS = { youtube, tiktok, instagram };
const PLATFORM_IDS = Object.keys(PLATFORMS);
const ACTIVE = new Set(['scheduled', 'uploading', 'processing']);
const MAX_RETRIES = 3;

let ctxRef = null;
const opts = {
  tickMs: 15_000,
  backoffMs: [60_000, 5 * 60_000, 15 * 60_000],
  pollMs: undefined, // per-platform defaults
  pollTimeoutMs: undefined,
  autopilotLeadMs: 30_000, // "immediately-ish": first autopilot post goes out ~30 s after the job finishes
};

const settings = () => ctxRef.getSettings();

// YouTube and TikTok (Desktop app type) always use the localhost callback; only Instagram, which
// requires HTTPS, goes through settings.publicBaseUrl.
function redirectUri(platform) {
  const pub = platform === 'instagram' ? settings().publicBaseUrl : '';
  const base = (pub || ctxRef.baseUrl).replace(/\/+$/, '');
  return `${base}/api/auth/${platform}/callback`;
}

function httpError(status, message) {
  return Object.assign(new Error(message), { status });
}

function clipFilePath(clip) {
  if (!clip?.file) return null;
  return path.join(ctxRef.paths.clips, path.basename(clip.file.split('?')[0]));
}

function toast(level, message) {
  emit({ type: 'toast', data: { level, message } });
}

// ---------- publication state (+ mirror into clip.publish) ----------
function setPub(id, patch) {
  const pub = store.update('publications', id, patch);
  if (!pub) return null;
  const clip = store.get('clips', pub.clipId);
  if (clip) {
    const cur = clip.publish?.[pub.platform];
    // Don't let an old/canceled publication overwrite the summary of a newer one.
    const newer = cur?.publicationId && cur.publicationId !== pub.id
      && store.get('publications', cur.publicationId)
      && (store.get('publications', cur.publicationId).createdAt ?? 0) > (pub.createdAt ?? 0);
    if (!newer) {
      store.update('clips', clip.id, {
        publish: {
          ...(clip.publish ?? {}),
          [pub.platform]: {
            status: pub.status,
            url: pub.url ?? null,
            publicationId: pub.id,
            scheduledAt: pub.scheduledAt ?? null,
            error: pub.error ?? null,
            ...(pub.delivery ? { delivery: pub.delivery } : {}),
          },
        },
      });
    }
  }
  return pub;
}

function createPublication(clip, platform, { scheduledAt, title, caption, source = 'manual' }) {
  const meta = buildMeta(platform, clip, { title, caption });
  const existing = store.list('publications', (p) => p.clipId === clip.id && p.platform === platform && ACTIVE.has(p.status))[0];
  if (existing) {
    if (existing.status !== 'scheduled') return existing; // already uploading: leave it alone
    return setPub(existing.id, {
      scheduledAt, overrideTitle: title ?? null, overrideCaption: caption ?? null,
      title: meta.title, caption: meta.caption, attempts: 0, error: null, source,
    });
  }
  const pub = store.insert('publications', {
    id: store.newId('pub'),
    clipId: clip.id,
    jobId: clip.jobId,
    platform,
    status: 'scheduled',
    scheduledAt,
    publishedAt: null,
    progress: 0,
    remoteId: null,
    url: null,
    error: null,
    title: meta.title,
    caption: meta.caption,
    overrideTitle: title ?? null,
    overrideCaption: caption ?? null,
    attempts: 0,
    source,
  });
  return setPub(pub.id, {});
}

// ---------- the actual upload of one publication ----------
const running = new Map(); // platform -> publicationId
const controllers = new Map(); // publicationId -> AbortController

async function runPublication(id) {
  let pub = store.get('publications', id);
  if (!pub || pub.status !== 'scheduled') return;
  const mod = PLATFORMS[pub.platform];
  const clip = store.get('clips', pub.clipId);

  if (!clip) return void setPub(id, { status: 'error', error: 'The clip was deleted.' });
  if (clip.status === 'rendering' || clip.status === 'pending') {
    return void setPub(id, { scheduledAt: Date.now() + 60_000, error: 'Waiting for the clip to finish rendering…' });
  }
  const filePath = clipFilePath(clip);
  if (clip.status !== 'ready' || !filePath || !fs.existsSync(filePath)) {
    return void setPub(id, { status: 'error', error: 'The clip is not rendered (or its video file is missing). Render it, then retry.' });
  }

  const ac = new AbortController();
  controllers.set(id, ac);
  const meta = buildMeta(pub.platform, clip, { title: pub.overrideTitle ?? undefined, caption: pub.overrideCaption ?? undefined });
  pub = setPub(id, { status: 'uploading', progress: 0, error: null, startedAt: Date.now(), title: meta.title, caption: meta.caption });

  let lastProgress = 0;
  const stillMine = () => store.get('publications', id)?.status !== 'canceled';
  try {
    const s = settings();
    const token = await getAccessToken(mod, s);
    const { size } = await fs.promises.stat(filePath);
    const result = await mod.publish({
      token, filePath, size, meta, settings: s, clip, signal: ac.signal,
      pollMs: opts.pollMs, pollTimeoutMs: opts.pollTimeoutMs,
      onProgress: (f) => {
        const p = Math.round(Math.min(1, Math.max(0, f)) * 0.9 * 1000) / 1000; // upload = first 90 %
        if (stillMine() && (p - lastProgress >= 0.02 || f >= 1)) { lastProgress = p; setPub(id, { progress: p }); }
      },
      onStatus: (status) => { if (stillMine()) setPub(id, { status, progress: Math.max(lastProgress, 0.9) }); },
      onRemote: (remoteId) => { if (stillMine()) setPub(id, { remoteId }); },
    });
    if (!stillMine()) return;
    setPub(id, {
      status: 'published', progress: 1, publishedAt: Date.now(), error: null,
      remoteId: result.remoteId ?? null, url: result.url ?? null,
      note: result.note ?? null, delivery: result.delivery ?? null,
    });
    toast('success', result.delivery === 'inbox'
      ? `Sent "${meta.title}" to your TikTok inbox. Finish posting in the TikTok app.`
      : `Published "${meta.title}" to ${mod.label}.`);
  } catch (err) {
    if (!stillMine() || err?.name === 'AbortError') return;
    const cur = store.get('publications', id);
    const message = err instanceof PublishError ? err.message : `${mod.label} upload failed: ${err?.message || err}`;
    const attempts = (cur?.attempts ?? 0) + 1;
    if (err instanceof PublishError && err.transient && attempts <= MAX_RETRIES) {
      const delay = Math.max(err.retryAfterMs ?? 0, opts.backoffMs[Math.min(attempts - 1, opts.backoffMs.length - 1)]);
      setPub(id, {
        status: 'scheduled', scheduledAt: Date.now() + delay, attempts, progress: 0,
        error: `${message} Retrying (${attempts}/${MAX_RETRIES}) in ${Math.round(delay / 1000)} s…`,
      });
    } else {
      if (!(err instanceof PublishError)) console.error(`[publish] ${pub.platform} ${id}`, err);
      setPub(id, { status: 'error', error: message, attempts });
      toast('error', `${mod.label}: ${message}`);
    }
  } finally {
    controllers.delete(id);
  }
}

// ---------- autopilot ----------
let autopilotSince = null; // only jobs that finish while autopilot is on get auto-posted

function runAutopilot() {
  const ap = settings().autopilot ?? {};
  if (!ap.enabled) { autopilotSince = null; return; }
  if (autopilotSince == null) autopilotSince = Date.now();
  const jobs = store.list('jobs', (j) => j.status === 'done' && !j.autopilotScheduled
    && (j.finishedAt ?? j.updatedAt ?? 0) >= autopilotSince - 60_000);
  for (const job of jobs.reverse()) scheduleAutopilotForJob(job, ap);
}

export function scheduleAutopilotForJob(job, ap = settings().autopilot ?? {}) {
  const spacing = Math.max(0, Number(ap.spacingMinutes ?? 180)) * 60_000;
  const minScore = Number(ap.minScore ?? 0);
  const maxPerJob = Math.max(0, Number(ap.maxPerJob ?? 3));
  const wanted = (ap.platforms ?? []).filter((p) => PLATFORMS[p]);
  const platforms = wanted.filter((p) => isConnected(p));
  const skipped = wanted.filter((p) => !platforms.includes(p));

  const clips = store.list('clips', (c) => c.jobId === job.id && c.status === 'ready' && (c.score ?? 0) >= minScore)
    .sort((a, b) => (b.score ?? 0) - (a.score ?? 0) || (a.rank ?? 99) - (b.rank ?? 99))
    .slice(0, maxPerJob);

  const created = [];
  const now = Date.now();
  for (const platform of platforms) {
    // Continue after anything already queued/posted recently on this platform so posts never bunch up.
    const anchor = store.list('publications', (p) => p.platform === platform && (ACTIVE.has(p.status) || p.status === 'published'))
      .map((p) => (p.status === 'published' ? p.publishedAt : p.scheduledAt) ?? 0)
      .reduce((a, b) => Math.max(a, b), 0);
    let at = Math.max(now + opts.autopilotLeadMs, anchor ? anchor + spacing : 0);
    for (const clip of clips) {
      if (clip.publish?.[platform]?.status === 'published') continue;
      created.push(createPublication(clip, platform, { scheduledAt: at, source: 'autopilot' }));
      at += spacing;
    }
  }
  store.update('jobs', job.id, { autopilotScheduled: true });
  if (created.length) toast('info', `Autopilot queued ${created.length} post${created.length === 1 ? '' : 's'} from "${job.source?.name ?? job.id}".`);
  if (skipped.length) toast('error', `Autopilot skipped ${skipped.map((p) => PLATFORMS[p].label).join(', ')}: not connected.`);
  return created;
}

// ---------- scheduler loop ----------
let timer = null;
let lastMaintenance = 0;

function tick() {
  if (!ctxRef) return;
  try { runAutopilot(); } catch (err) { console.error('[publish] autopilot', err); }
  const now = Date.now();
  const due = store.list('publications', (p) => p.status === 'scheduled' && (p.scheduledAt ?? 0) <= now)
    .sort((a, b) => (a.scheduledAt ?? 0) - (b.scheduledAt ?? 0));
  for (const pub of due) {
    if (running.has(pub.platform)) continue; // one upload at a time per platform
    running.set(pub.platform, pub.id);
    runPublication(pub.id)
      .catch((err) => console.error('[publish] run', err))
      .finally(() => { running.delete(pub.platform); setImmediate(tick); });
  }
  if (now - lastMaintenance > 60 * 60 * 1000) {
    lastMaintenance = now;
    maintainTokens();
  }
}

// Keep long-lived tokens (Instagram's 60-day token in particular) fresh even when nothing is posting.
function maintainTokens() {
  for (const mod of Object.values(PLATFORMS)) {
    if (isConnected(mod.id)) getAccessToken(mod, settings()).catch(() => {});
  }
}

export function kick() {
  if (ctxRef) setImmediate(tick);
}

export function startScheduler(ctx) {
  ctxRef ??= ctx;
  Object.assign(opts, ctx.publishOptions ?? {});
  // Uploads interrupted by a restart: re-queue uploads, flag ones the platform may already have.
  for (const p of store.list('publications', (x) => x.status === 'uploading' || x.status === 'processing')) {
    if (p.status === 'uploading') setPub(p.id, { status: 'scheduled', scheduledAt: Date.now(), progress: 0 });
    else setPub(p.id, { status: 'error', error: 'Interrupted by a server restart while the platform was processing. Check your account and retry if it did not post.' });
  }
  clearInterval(timer);
  timer = setInterval(tick, opts.tickMs);
  timer.unref?.();
  setImmediate(tick);
  return { stop: () => clearInterval(timer), tick };
}

// ---------- routes ----------
function accountInfo(id) {
  const mod = PLATFORMS[id];
  const s = settings();
  const rec = getRecord(id);
  const uri = redirectUri(id);
  const connected = isConnected(id);
  const notes = [];
  if (rec?.needsReconnect) notes.push(rec.lastError || `${mod.label} needs to be reconnected.`);
  if (rec?.profile?.warning) notes.push(rec.profile.warning);
  notes.push(mod.note(s, rec, uri));
  // Refresh stale profile info (names, expiring avatar URLs) in the background.
  if (connected && Date.now() - (rec.profileFetchedAt ?? 0) > 6 * 60 * 60 * 1000) refreshProfile(id).catch(() => {});
  return {
    configured: mod.isConfigured(s),
    connected,
    name: rec?.profile?.name ?? null,
    avatar: rec?.profile?.avatar ?? null,
    note: notes.filter(Boolean).join(' '),
    setup: mod.setup(uri, s),
    redirectUri: uri,
    ...(id === 'tiktok' ? { mode: tiktokMode(s), privacyOptions: rec?.profile?.privacyOptions ?? null } : {}),
    ...(id === 'instagram' ? { httpsRequired: true, httpsReady: uri.startsWith('https://') } : {}),
    ...(rec?.expires_at && id === 'instagram' ? { expiresAt: rec.expires_at } : {}),
  };
}

const profileRefreshing = new Set();
async function refreshProfile(id) {
  if (profileRefreshing.has(id)) return;
  profileRefreshing.add(id);
  try {
    const rec = await getAccessToken(PLATFORMS[id], settings());
    const profile = await PLATFORMS[id].fetchProfile(rec, settings());
    patchRecord(id, { profile, profileFetchedAt: Date.now() });
  } finally {
    profileRefreshing.delete(id);
  }
}

function settingsRedirect(res, params) {
  res.redirect(302, `/settings?${new URLSearchParams(params).toString()}`);
}

export function registerPublishRoutes(app, ctx) {
  ctxRef = ctx;

  app.get('/api/accounts', (_req, res) => {
    res.json(Object.fromEntries(PLATFORM_IDS.map((id) => [id, accountInfo(id)])));
  });

  app.get('/api/auth/:platform/start', (req, res) => {
    const mod = PLATFORMS[req.params.platform];
    if (!mod) return res.status(404).json({ error: 'Unknown platform' });
    const s = settings();
    if (!mod.isConfigured(s)) {
      return settingsRedirect(res, { error: `Add your ${mod.label} app credentials in Settings first.`, platform: mod.id });
    }
    const uri = redirectUri(mod.id);
    const problem = mod.checkRedirect?.(uri);
    if (problem) return settingsRedirect(res, { error: problem, platform: mod.id });
    const state = randomToken(24);
    const verifier = pkceVerifier();
    rememberState(state, { platform: mod.id, verifier, redirectUri: uri });
    res.redirect(302, mod.authorizeUrl({ settings: s, redirectUri: uri, state, verifier }));
  });

  app.get('/api/auth/:platform/callback', async (req, res) => {
    const mod = PLATFORMS[req.params.platform];
    if (!mod) return res.status(404).json({ error: 'Unknown platform' });
    const { code, state, error, error_description: desc, error_reason: reason } = req.query;
    const saved = consumeState(String(state ?? ''));
    if (error) {
      return settingsRedirect(res, { error: `${mod.label} sign-in was canceled or refused: ${desc || reason || error}`, platform: mod.id });
    }
    if (!saved || saved.platform !== mod.id) {
      return settingsRedirect(res, { error: `${mod.label} sign-in expired or came from another tab. Please try connecting again.`, platform: mod.id });
    }
    if (!code) return settingsRedirect(res, { error: `${mod.label} did not return an authorization code.`, platform: mod.id });
    try {
      const s = settings();
      const rec = await mod.exchangeCode({ settings: s, code: String(code), redirectUri: saved.redirectUri, verifier: saved.verifier });
      let profile = null;
      try { profile = await mod.fetchProfile(rec, s); } catch (err) { console.warn(`[publish] ${mod.id} profile`, err.message); }
      setRecord(mod.id, { ...rec, profile, profileFetchedAt: Date.now(), connectedAt: Date.now() });
      if (profile?.id && !rec.user_id) patchRecord(mod.id, { user_id: profile.id });
      settingsRedirect(res, { connected: mod.id });
    } catch (err) {
      console.warn(`[publish] ${mod.id} callback`, err.message);
      settingsRedirect(res, { error: err.message || `${mod.label} sign-in failed.`, platform: mod.id });
    }
  });

  app.post('/api/auth/:platform/disconnect', async (req, res) => {
    const mod = PLATFORMS[req.params.platform];
    if (!mod) return res.status(404).json({ error: 'Unknown platform' });
    const rec = getRecord(mod.id);
    setRecord(mod.id, null);
    if (rec && mod.revoke) mod.revoke(rec, settings()).catch(() => {});
    res.json({ ok: true, account: accountInfo(mod.id) });
  });

  app.post('/api/clips/:id/publish', (req, res) => {
    const clip = store.get('clips', req.params.id);
    if (!clip) throw httpError(404, 'Clip not found');
    const { platforms, scheduleAt, title, caption } = req.body ?? {};
    const list = [...new Set(Array.isArray(platforms) ? platforms : [platforms].filter(Boolean))];
    if (!list.length) throw httpError(400, 'Choose at least one platform.');
    const unknown = list.filter((p) => !PLATFORMS[p]);
    if (unknown.length) throw httpError(400, `Unknown platform: ${unknown.join(', ')}`);
    if (clip.status !== 'ready' || !clip.file) throw httpError(409, 'This clip is not rendered yet. Wait for rendering to finish.');
    const notConnected = list.filter((p) => !isConnected(p));
    if (notConnected.length) {
      throw httpError(400, `Connect ${notConnected.map((p) => PLATFORMS[p].label).join(', ')} in Settings first.`);
    }
    let when = Date.now();
    if (scheduleAt != null && scheduleAt !== '') {
      when = typeof scheduleAt === 'number' ? scheduleAt : Date.parse(scheduleAt);
      if (!Number.isFinite(when)) throw httpError(400, 'scheduleAt must be a millisecond timestamp.');
    }
    const clean = (v) => (typeof v === 'string' && v.trim() ? v : undefined);
    const pubs = list.map((p) => createPublication(clip, p, { scheduledAt: when, title: clean(title), caption: clean(caption) }));
    if (when <= Date.now()) kick();
    res.json(pubs);
  });

  app.get('/api/publications', (req, res) => {
    const { clipId, jobId, platform, status } = req.query;
    res.json(store.list('publications', (p) =>
      (!clipId || p.clipId === clipId) && (!jobId || p.jobId === jobId)
      && (!platform || p.platform === platform) && (!status || p.status === status)));
  });

  // Cancels a queued/in-flight publication; deleting a finished one removes it from history.
  app.delete('/api/publications/:id', (req, res) => {
    const pub = store.get('publications', req.params.id);
    if (!pub) throw httpError(404, 'Publication not found');
    if (ACTIVE.has(pub.status)) {
      const updated = setPub(pub.id, { status: 'canceled', error: null });
      controllers.get(pub.id)?.abort();
      return res.json(updated);
    }
    store.remove('publications', pub.id);
    const clip = store.get('clips', pub.clipId);
    if (clip?.publish?.[pub.platform]?.publicationId === pub.id) {
      const { [pub.platform]: _gone, ...rest } = clip.publish;
      store.update('clips', clip.id, { publish: rest });
    }
    res.json({ ok: true, removed: pub.id });
  });

  app.post('/api/publications/:id/retry', (req, res) => {
    const pub = store.get('publications', req.params.id);
    if (!pub) throw httpError(404, 'Publication not found');
    if (!['error', 'canceled'].includes(pub.status)) throw httpError(409, `Can't retry a publication that is ${pub.status}.`);
    const clip = store.get('clips', pub.clipId);
    if (!clip) throw httpError(404, 'The clip was deleted.');
    if (clip.status !== 'ready' || !clip.file) throw httpError(409, 'This clip is not rendered yet. Wait for rendering to finish.');
    const updated = setPub(pub.id, { status: 'scheduled', scheduledAt: Date.now(), attempts: 0, error: null, progress: 0, remoteId: null, url: null });
    kick();
    res.json(updated);
  });
}
