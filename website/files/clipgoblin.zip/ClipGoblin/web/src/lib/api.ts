import type { Accounts, Clip, Job, JobOptions, Platform, Publication, Settings, SystemInfo } from './types';

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

export interface UploadHandle {
  promise: Promise<Job>;
  abort: () => void;
}

export interface UploadProgress {
  loaded: number;
  total: number;
}

export interface EventSourceLike {
  onopen: ((ev: Event) => void) | null;
  onerror: ((ev: Event) => void) | null;
  onmessage: ((ev: MessageEvent) => void) | null;
  close: () => void;
  readyState: number;
}

/**
 * Low-level transport. Everything the UI does with the network goes through here, so the dev-only
 * mock (src/mocks, enabled with VITE_MOCK=1) can swap it out wholesale.
 */
export const transport = {
  async request<T>(method: string, url: string, body?: unknown): Promise<T> {
    const res = await fetch(url, {
      method,
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    const text = await res.text();
    let data: unknown = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch {
      data = text;
    }
    if (!res.ok) {
      const errField = data && typeof data === 'object' ? (data as { error?: unknown }).error : undefined;
      const msg: string = errField ? String(errField) : `${res.status} ${res.statusText}`;
      throw new ApiError(msg, res.status);
    }
    return data as T;
  },

  upload(file: File, options: Partial<JobOptions>, onProgress: (p: UploadProgress) => void): UploadHandle {
    const xhr = new XMLHttpRequest();
    const promise = new Promise<Job>((resolve, reject) => {
      const form = new FormData();
      form.append('file', file, file.name);
      form.append('options', JSON.stringify(options));
      xhr.open('POST', '/api/jobs');
      xhr.responseType = 'text';
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) onProgress({ loaded: e.loaded, total: e.total });
      };
      xhr.onload = () => {
        let data: unknown = null;
        try {
          data = JSON.parse(xhr.responseText);
        } catch {
          /* ignore */
        }
        if (xhr.status >= 200 && xhr.status < 300) resolve(data as Job);
        else {
          const msg = (data as { error?: string } | null)?.error || `Upload failed (${xhr.status})`;
          reject(new ApiError(msg, xhr.status));
        }
      };
      xhr.onerror = () => reject(new ApiError('Network error during upload', 0));
      xhr.onabort = () => reject(new ApiError('Upload canceled', 0));
      xhr.send(form);
    });
    return { promise, abort: () => xhr.abort() };
  },

  events(): EventSourceLike {
    return new EventSource('/api/events');
  },

  frameUrl(jobId: string, t: number): string {
    return `/api/jobs/${encodeURIComponent(jobId)}/frame?t=${t.toFixed(2)}`;
  },

  connectUrl(platform: string): string {
    return `/api/auth/${platform}/start`;
  },
};

const get = <T,>(url: string) => transport.request<T>('GET', url);
const post = <T,>(url: string, body?: unknown) => transport.request<T>('POST', url, body ?? {});
const put = <T,>(url: string, body: unknown) => transport.request<T>('PUT', url, body);
const patch = <T,>(url: string, body: unknown) => transport.request<T>('PATCH', url, body);
const del = <T,>(url: string) => transport.request<T>('DELETE', url);

const e = encodeURIComponent;

export const api = {
  jobs: () => get<Job[]>('/api/jobs'),
  job: (id: string) => get<{ job: Job; clips: Clip[] }>(`/api/jobs/${e(id)}`),
  createJobFromUrl: (url: string, options: Partial<JobOptions>) => post<Job>('/api/jobs', { url, options }),
  uploadJob: (file: File, options: Partial<JobOptions>, onProgress: (p: UploadProgress) => void) =>
    transport.upload(file, options, onProgress),
  deleteJob: (id: string) => del<unknown>(`/api/jobs/${e(id)}`),
  retryJob: (id: string) => post<Job>(`/api/jobs/${e(id)}/retry`),
  cancelJob: (id: string) => post<Job>(`/api/jobs/${e(id)}/cancel`),
  frameUrl: (id: string, t: number) => transport.frameUrl(id, t),

  clips: () => get<Clip[]>('/api/clips'),
  clip: (id: string) => get<Clip>(`/api/clips/${e(id)}`),
  updateClip: (id: string, body: Partial<Clip>) => patch<Clip>(`/api/clips/${e(id)}`, body),
  renderClip: (id: string) => post<Clip>(`/api/clips/${e(id)}/render`),
  deleteClip: (id: string) => del<unknown>(`/api/clips/${e(id)}`),

  system: () => get<SystemInfo>('/api/system'),
  settings: () => get<Settings>('/api/settings'),
  saveSettings: (p: DeepPartial<Settings>) => put<Settings>('/api/settings', p),

  accounts: () => get<Accounts>('/api/accounts'),
  disconnect: (p: Platform) => post<unknown>(`/api/auth/${p}/disconnect`),
  connectUrl: (p: Platform) => transport.connectUrl(p),

  publish: (clipId: string, body: { platforms: Platform[]; scheduleAt?: number; title?: string; caption?: string }) =>
    post<Publication[]>(`/api/clips/${e(clipId)}/publish`, body),
  publications: () => get<Publication[]>('/api/publications'),
  cancelPublication: (id: string) => del<unknown>(`/api/publications/${e(id)}`),
  retryPublication: (id: string) => post<Publication>(`/api/publications/${e(id)}/retry`),
};

export type DeepPartial<T> = { [K in keyof T]?: T[K] extends object ? (T[K] extends unknown[] ? T[K] : DeepPartial<T[K]>) : T[K] };

export function errMsg(err: unknown): string {
  if (err instanceof Error) return err.message;
  return String(err);
}
