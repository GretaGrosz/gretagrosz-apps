// Animated word-by-word captions + hook banner, generated as an ASS subtitle file (burned by libass).
// All text is measured with the real font metrics so nothing runs off the 1080×1920 frame, and
// everything stays inside the platform safe zone (bottom ~18% and right edge are covered by UI).
import { measure, renderable } from './fonts.js';
import { stripEmoji } from './util.js';

const W = 1080;
const H = 1920;
export const SAFE = { left: 80, right: 150, bottomY: Math.round(H * 0.82) }; // right edge hosts like/comment buttons
const CX = Math.round((SAFE.left + (W - SAFE.right)) / 2); // 505 — visually centred, clear of the right-side UI
const MAX_W = W - SAFE.left - SAFE.right; // 850

// ASS colours are &HAABBGGRR
const C = {
  white: '&H00FFFFFF&', black: '&H00000000&', yellow: '&H0000E5FF&', green: '&H0014FF39&', red: '&H003B30FF&',
  grey: '&H00D0D0D0&', dim: '&H40FFFFFF&',
};
const CHAOS_COLORS = ['&H0000E5FF&', '&H0014FF39&', '&H00FF9A1F&', '&H00F25BFF&', '&H0000A5FF&', '&H00FFFF00&', '&H00FFFFFF&'];

function rng(seed) {
  let s = seed >>> 0 || 1;
  return () => { s ^= s << 13; s ^= s >>> 17; s ^= s << 5; return ((s >>> 0) % 10000) / 10000; };
}
function hashStr(str) { let h = 2166136261; for (const c of String(str)) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }

const ts = (t) => {
  t = Math.max(0, t);
  const h = Math.floor(t / 3600); const m = Math.floor((t % 3600) / 60); const s = t % 60;
  return `${h}:${String(m).padStart(2, '0')}:${s.toFixed(2).padStart(5, '0')}`;
};
const esc = (s) => String(s).replace(/\\/g, '/').replace(/\{/g, '(').replace(/\}/g, ')').replace(/\n/g, ' ');

const STYLE_FONTS = {
  beast: { font: 'Impact', size: 124, outline: 9, shadow: 4, upper: true },
  chaos: { font: 'Impact', size: 118, outline: 9, shadow: 5, upper: true },
  karaoke: { font: 'Arial Black', size: 80, outline: 6, shadow: 3, upper: false },
  minimal: { font: 'Arial Rounded MT Bold', size: 58, outline: 14, shadow: 0, upper: false },
};

function header(styleName) {
  const f = STYLE_FONTS[styleName] || STYLE_FONTS.beast;
  const minimal = styleName === 'minimal';
  return `[Script Info]
ScriptType: v4.00+
PlayResX: ${W}
PlayResY: ${H}
WrapStyle: 2
ScaledBorderAndShadow: yes
YCbCr Matrix: TV.709

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,${f.font},${f.size},&H00FFFFFF,&H00FFFFFF,${minimal ? '&H70000000' : '&H00000000'},&H90000000,0,0,0,0,100,100,0,0,${minimal ? 3 : 1},${f.outline},${f.shadow},5,0,0,0,1
Style: Hook,Arial Black,62,&H00000000,&H00000000,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,0,0,5,0,0,0,1
Style: HookBox,Arial Black,62,&H00FFFFFF,&H00FFFFFF,&H00FFFFFF,&H78000000,0,0,0,0,100,100,0,0,1,0,7,7,0,0,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
`;
}

function cleanToken(w, upper, keepPunct) {
  let t = stripEmoji(w).replace(/["“”]/g, '').trim();
  if (!keepPunct) t = t.replace(/[.,;:]+$/g, '').replace(/^[.,;:]+/g, '');
  if (upper) t = t.toUpperCase();
  return t;
}

/** Group words into caption pages. */
function paginate(words, { maxWords, fontName, size, maxW, gapBreak = 0.45 }) {
  const pages = [];
  let cur = [];
  const width = (toks) => measure(toks.map((t) => t.text).join(' '), fontName, size);
  for (let i = 0; i < words.length; i++) {
    const w = words[i];
    const prev = cur[cur.length - 1];
    const brk = prev && (
      cur.length >= maxWords
      || w.s - prev.e > gapBreak
      || /[.!?…]$/.test(prev.raw)
      || width([...cur, w]) > maxW
      || (maxWords <= 3 && cur.length >= 2 && [...cur, w].reduce((a, t) => a + t.text.length, 0) > 15)
    );
    if (brk) { pages.push(cur); cur = []; }
    cur.push(w);
  }
  if (cur.length) pages.push(cur);
  return pages;
}

/** Fit a single-line page: shrink font if needed. Returns the font size to use. */
function fitSize(text, fontName, size, maxW, min = 60) {
  const w = measure(text, fontName, size);
  if (w <= maxW) return size;
  return Math.max(min, Math.floor(size * maxW / w));
}

/**
 * Split items into 1–2 visually balanced rows that fit maxW (no orphan words); falls back to
 * greedy wrapping for longer text. textOf(item) gives the rendered string of an item.
 */
function balancedRows(items, fontName, size, maxW, textOf = (x) => x) {
  const width = (arr) => measure(arr.map(textOf).join(' '), fontName, size);
  if (width(items) <= maxW || items.length < 2) return [items];
  let best = null;
  for (let k = 1; k < items.length; k++) {
    const a = items.slice(0, k); const b = items.slice(k);
    const m = Math.max(width(a), width(b));
    if (m <= maxW && (!best || m < best.m)) best = { m, rows: [a, b] };
  }
  if (best) return best.rows;
  const rows = []; let cur = [];
  for (const it of items) {
    if (cur.length && width([...cur, it]) > maxW) { rows.push(cur); cur = [it]; } else cur.push(it);
  }
  if (cur.length) rows.push(cur);
  return rows;
}

// ------------------------------------------------------------------ caption styles

/** When a page leaves the screen: hold through short pauses (no flicker), clear on real ones. */
function holdUntil(page, next, tail) {
  const lastE = page[page.length - 1].e;
  if (!next) return lastE + tail;
  return next[0].s - lastE < 1.2 ? next[0].s : lastE + tail;
}

function beastEvents(words, y, { chaos = false, seed = 1 }) {
  const cfg = STYLE_FONTS[chaos ? 'chaos' : 'beast'];
  const rand = rng(seed);
  const toks = words.map((w) => ({ ...w, raw: w.w, text: renderable(cleanToken(w.w, true, false), cfg.font) })).filter((t) => t.text);
  const pages = paginate(toks, { maxWords: 3, fontName: cfg.font, size: cfg.size, maxW: MAX_W });
  const out = [];
  pages.forEach((page, pi) => {
    const next = pages[pi + 1];
    const pageEnd = holdUntil(page, next, 0.8);
    const full = page.map((t) => t.text).join(' ');
    const size = fitSize(full, cfg.font, cfg.size, MAX_W);
    const sizeTag = size !== cfg.size ? `\\fs${size}` : '';
    // Chaos: per-page colour + tilt; beast: clean white with yellow active word.
    const baseColor = chaos ? CHAOS_COLORS[Math.floor(rand() * CHAOS_COLORS.length)] : C.white;
    const tilt = chaos ? (rand() * 12 - 6).toFixed(1) : '0';
    const jitterY = chaos ? Math.round(rand() * 60 - 30) : 0;
    page.forEach((tok, wi) => {
      const start = tok.s;
      const end = wi + 1 < page.length ? page[wi + 1].s : pageEnd;
      if (end - start < 0.02) return;
      const parts = page.map((t, k) => {
        if (k !== wi) return `${esc(t.text)}`;
        if (chaos && t.loud) {
          return `{\\1c${C.red}\\fscx142\\fscy142\\frz${(rand() * 10 - 5).toFixed(1)}\\t(0,70,\\fscx128\\fscy128)\\t(70,140,\\frz${(rand() * 8 - 4).toFixed(1)})}${esc(t.text)}{\\1c${baseColor}\\fscx100\\fscy100\\frz0}`;
        }
        const hi = chaos ? (baseColor === C.yellow ? C.white : C.yellow) : (t.loud ? C.green : C.yellow);
        const pop = t.loud ? 128 : 118;
        return `{\\1c${hi}\\fscx${pop}\\fscy${pop}\\t(0,90,\\fscx${pop - 12}\\fscy${pop - 12})}${esc(t.text)}{\\1c${baseColor}\\fscx100\\fscy100}`;
      });
      const fade = wi === 0 ? '\\fad(40,0)' : '';
      const rot = chaos ? `\\frz${tilt}` : '';
      out.push(`Dialogue: 1,${ts(start)},${ts(end)},Cap,,0,0,0,,{\\an5\\pos(${CX},${y + jitterY})${sizeTag}\\1c${baseColor}${rot}${fade}}${parts.join(' ')}`);
    });
  });
  return out;
}

function karaokeEvents(words, y) {
  const cfg = STYLE_FONTS.karaoke;
  const toks = words.map((w) => ({ ...w, raw: w.w, text: renderable(cleanToken(w.w, false, true), cfg.font) })).filter((t) => t.text);
  // Pages of up to 2 lines.
  const pages = paginate(toks, { maxWords: 9, fontName: cfg.font, size: cfg.size, maxW: MAX_W * 1.9, gapBreak: 0.8 });
  const out = [];
  pages.forEach((page, pi) => {
    const next = pages[pi + 1];
    const pageEnd = holdUntil(page, next, 0.8);
    // Balanced wrap by measured width, keeping token indexes so the active word can be highlighted.
    const rows = balancedRows(page.map((_, k) => k), cfg.font, cfg.size * 1.08, MAX_W, (k) => page[k].text);
    page.forEach((tok, wi) => {
      const start = tok.s;
      const end = wi + 1 < page.length ? page[wi + 1].s : pageEnd;
      if (end - start < 0.02) return;
      const text = rows.map((r) => r.map((k) => {
        const t = page[k];
        if (k === wi) return `{\\1c${C.green}\\fscx108\\fscy108}${esc(t.text)}{\\1c${C.white}\\fscx100\\fscy100}`;
        if (k > wi) return `{\\1c${C.grey}}${esc(t.text)}{\\1c${C.white}}`;
        return esc(t.text);
      }).join(' ')).join('\\N');
      out.push(`Dialogue: 1,${ts(start)},${ts(end)},Cap,,0,0,0,,{\\an5\\pos(${CX},${y})${wi === 0 ? '\\fad(60,0)' : ''}}${text}`);
    });
  });
  return out;
}

function minimalEvents(words, y) {
  const cfg = STYLE_FONTS.minimal;
  const toks = words.map((w) => ({ ...w, raw: w.w, text: renderable(cleanToken(w.w, false, true), cfg.font) })).filter((t) => t.text);
  const pages = paginate(toks, { maxWords: 12, fontName: cfg.font, size: cfg.size, maxW: (MAX_W - 40) * 2, gapBreak: 0.9 });
  const out = [];
  pages.forEach((page, pi) => {
    const next = pages[pi + 1];
    const start = page[0].s;
    const end = holdUntil(page, next, 1.0);
    const rows = balancedRows(page.map((t) => esc(t.text)), cfg.font, cfg.size, MAX_W - 40);
    out.push(`Dialogue: 1,${ts(start)},${ts(end)},Cap,,0,0,0,,{\\an5\\pos(${CX},${y})\\fad(80,60)}${rows.map((r) => r.join(' ')).join('\\N')}`);
  });
  return out;
}

// ------------------------------------------------------------------ hook banner

function roundedRect(w, h, r) {
  w = Math.round(w); h = Math.round(h); r = Math.round(r);
  return `m ${r} 0 l ${w - r} 0 b ${w} 0 ${w} 0 ${w} ${r} l ${w} ${h - r} b ${w} ${h} ${w} ${h} ${w - r} ${h} l ${r} ${h} b 0 ${h} 0 ${h} 0 ${h - r} l 0 ${r} b 0 0 0 0 ${r} 0`;
}

function hookEvents(hook, y, duration) {
  const font = 'Arial Black';
  let text = renderable(stripEmoji(hook), font);
  if (!text) return [];
  let size = 84;
  const words = text.split(/\s+/);
  let rows = balancedRows(words, font, size, MAX_W - 100);
  while (rows.length > 2 && size > 58) { size -= 4; rows = balancedRows(words, font, size, MAX_W - 100); }
  const lineH = size * 1.06;
  const padX = 44; const padY = 26;
  const textW = Math.max(...rows.map((r) => measure(r.join(' '), font, size)));
  const boxW = Math.min(MAX_W, textW + padX * 2);
  const boxH = rows.length * lineH + padY * 2;
  const x0 = Math.round(CX - boxW / 2); const y0 = Math.round(y - boxH / 2);
  const anim = `\\org(${CX},${y})\\frz1.5\\fscx35\\fscy35\\t(0,130,\\fscx107\\fscy107)\\t(130,210,\\fscx100\\fscy100)\\fad(0,160)`;
  // One fully-capitalised word (≥ 2 letters) is the emphasis word → red.
  const styled = rows.map((r) => r.map((wd) => (/^[A-Z][A-Z'!?]+$/.test(wd) && /[A-Z]{2}/.test(wd) ? `{\\1c&H002A2AE6&}${esc(wd)}{\\1c&H00000000&}` : esc(wd))).join(' ')).join('\\N');
  const end = ts(duration);
  return [
    `Dialogue: 5,${ts(0)},${end},HookBox,,0,0,0,,{\\an7\\pos(${x0},${y0})${anim}\\p1}${roundedRect(boxW, boxH, 28)}{\\p0}`,
    `Dialogue: 6,${ts(0)},${end},Hook,,0,0,0,,{\\an5\\pos(${CX},${y + Math.round(size * 0.04)})\\fs${size}${anim}}${styled}`,
  ];
}

/**
 * Build the .ass file.
 * words: [{w, s, e, loud}] in OUTPUT timeline seconds.
 * opts: { captionStyle, captionY, hook, hookY, hookDuration, seed, captions: bool }
 */
export function buildAss(words, opts) {
  const style = STYLE_FONTS[opts.captionStyle] ? opts.captionStyle : 'beast';
  const lines = [header(style)];
  if (opts.captions !== false && words.length) {
    const y = style === 'minimal' ? Math.min(opts.captionY + 120, SAFE.bottomY - 110) : opts.captionY;
    if (style === 'beast') lines.push(...beastEvents(words, y, { seed: opts.seed }));
    else if (style === 'chaos') lines.push(...beastEvents(words, y, { chaos: true, seed: opts.seed }));
    else if (style === 'karaoke') lines.push(...karaokeEvents(words, y));
    else lines.push(...minimalEvents(words, y));
  }
  if (opts.hook && opts.hookDuration > 0) lines.push(...hookEvents(opts.hook, opts.hookY, opts.hookDuration));
  return `${lines.join('\n')}\n`;
}

export { hashStr };
