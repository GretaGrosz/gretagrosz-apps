import clsx from 'clsx';
import { motion } from 'framer-motion';
import { Check, Copy, Loader2, Minus, Plus } from 'lucide-react';
import { useState, type ReactNode } from 'react';

export function Switch({
  checked,
  onChange,
  disabled,
  size = 'md',
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  disabled?: boolean;
  size?: 'sm' | 'md';
  label?: string;
}) {
  const w = size === 'sm' ? 'w-8 h-[18px]' : 'w-11 h-6';
  const knob = size === 'sm' ? 'h-3.5 w-3.5' : 'h-5 w-5';
  const shift = size === 'sm' ? 14 : 20;
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={(e) => {
        e.stopPropagation();
        onChange(!checked);
      }}
      className={clsx(
        'relative inline-flex shrink-0 items-center rounded-full p-[2px] transition-colors duration-200 disabled:opacity-40',
        w,
        checked ? 'bg-goblin-400 shadow-[0_0_16px_-2px_rgba(198,255,61,.6)]' : 'bg-ink-600',
      )}
    >
      <motion.span
        initial={false}
        animate={{ x: checked ? shift : 0 }}
        transition={{ type: 'spring', stiffness: 700, damping: 35 }}
        className={clsx('block rounded-full shadow', knob, checked ? 'bg-ink-950' : 'bg-zinc-300')}
      />
    </button>
  );
}

export function Spinner({ className }: { className?: string }) {
  return <Loader2 className={clsx('animate-spin', className ?? 'h-4 w-4')} />;
}

export function ProgressBar({
  value,
  className,
  tone = 'goblin',
  indeterminate,
  thin,
}: {
  value: number;
  className?: string;
  tone?: 'goblin' | 'hex' | 'rose' | 'sky';
  indeterminate?: boolean;
  thin?: boolean;
}) {
  const pct = Math.max(0, Math.min(1, value || 0)) * 100;
  const fill = {
    goblin: 'bg-goblin-gradient',
    hex: 'bg-hex-500',
    rose: 'bg-rose-500',
    sky: 'bg-sky-400',
  }[tone];
  return (
    <div className={clsx('relative overflow-hidden rounded-full bg-white/[0.07]', thin ? 'h-1' : 'h-1.5', className)}>
      {indeterminate ? (
        <div className={clsx('absolute inset-y-0 w-1/3 animate-shimmer rounded-full', fill)} />
      ) : (
        <motion.div
          className={clsx('absolute inset-y-0 left-0 rounded-full', fill)}
          initial={false}
          animate={{ width: `${pct}%` }}
          transition={{ type: 'spring', stiffness: 120, damping: 24 }}
        >
          <div className="absolute inset-0 overflow-hidden rounded-full">
            <div className="absolute inset-y-0 w-1/2 animate-shimmer bg-gradient-to-r from-transparent via-white/40 to-transparent" />
          </div>
        </motion.div>
      )}
    </div>
  );
}

export function Segmented<T extends string>({
  value,
  onChange,
  options,
  className,
  size = 'md',
}: {
  value: T;
  onChange: (v: T) => void;
  options: { value: T; label: ReactNode; icon?: ReactNode }[];
  className?: string;
  size?: 'sm' | 'md';
}) {
  return (
    <div className={clsx('inline-flex rounded-xl border border-white/[0.07] bg-ink-950/60 p-1', className)}>
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          onClick={() => onChange(o.value)}
          className={clsx(
            'relative flex flex-1 items-center justify-center gap-1.5 whitespace-nowrap rounded-lg px-3 font-medium transition-colors',
            size === 'sm' ? 'h-7 text-xs' : 'h-8 text-[13px]',
            value === o.value ? 'text-ink-950' : 'text-zinc-400 hover:text-zinc-200',
          )}
        >
          {value === o.value && (
            <motion.span
              layoutId={`seg-${options.map((x) => x.value).join('-')}`}
              className="absolute inset-0 rounded-lg bg-goblin-400"
              transition={{ type: 'spring', stiffness: 500, damping: 38 }}
            />
          )}
          <span className="relative z-10 flex items-center gap-1.5">
            {o.icon}
            {o.label}
          </span>
        </button>
      ))}
    </div>
  );
}

export function NumberStepper({
  value,
  onChange,
  min = 0,
  max = 999,
  step = 1,
  suffix,
  className,
}: {
  value: number;
  onChange: (v: number) => void;
  min?: number;
  max?: number;
  step?: number;
  suffix?: string;
  className?: string;
}) {
  const clamp = (v: number) => Math.max(min, Math.min(max, v));
  return (
    <div
      className={clsx(
        'flex h-10 items-center rounded-xl border border-white/[0.08] bg-ink-950/60 focus-within:border-goblin-400/60',
        className,
      )}
    >
      <button
        type="button"
        className="grid h-full w-9 place-items-center text-zinc-400 transition hover:text-white disabled:opacity-30"
        onClick={() => onChange(clamp(+(value - step).toFixed(2)))}
        disabled={value <= min}
        aria-label="Decrease"
      >
        <Minus className="h-3.5 w-3.5" />
      </button>
      <div className="flex flex-1 items-baseline justify-center gap-0.5">
        <input
          type="number"
          className="w-full min-w-0 bg-transparent text-center text-sm font-semibold tabular text-white outline-none"
          value={Number.isFinite(value) ? value : ''}
          min={min}
          max={max}
          step={step}
          onChange={(e) => {
            const v = Number(e.target.value);
            if (Number.isFinite(v)) onChange(v);
          }}
          onBlur={() => onChange(clamp(value))}
        />
        {suffix && <span className="pr-1 text-xs text-zinc-500">{suffix}</span>}
      </div>
      <button
        type="button"
        className="grid h-full w-9 place-items-center text-zinc-400 transition hover:text-white disabled:opacity-30"
        onClick={() => onChange(clamp(+(value + step).toFixed(2)))}
        disabled={value >= max}
        aria-label="Increase"
      >
        <Plus className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}

export function CopyButton({ text, className, label }: { text: string; className?: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      className={clsx('btn btn-sm btn-outline shrink-0', className)}
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
        } catch {
          const ta = document.createElement('textarea');
          ta.value = text;
          document.body.appendChild(ta);
          ta.select();
          document.execCommand('copy');
          ta.remove();
        }
        setCopied(true);
        setTimeout(() => setCopied(false), 1400);
      }}
    >
      {copied ? <Check className="h-3.5 w-3.5 text-goblin-400" /> : <Copy className="h-3.5 w-3.5" />}
      {label ?? (copied ? 'Copied' : 'Copy')}
    </button>
  );
}

export function SectionTitle({
  icon,
  title,
  subtitle,
  right,
}: {
  icon?: ReactNode;
  title: ReactNode;
  subtitle?: ReactNode;
  right?: ReactNode;
}) {
  return (
    <div className="mb-5 flex items-start justify-between gap-4">
      <div className="flex min-w-0 items-start gap-3">
        {icon && (
          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-white/[0.08] bg-gradient-to-br from-white/[0.08] to-transparent text-goblin-300">
            {icon}
          </div>
        )}
        <div className="min-w-0">
          <h2 className="font-display text-lg font-bold tracking-tight text-white">{title}</h2>
          {subtitle && <p className="mt-0.5 text-sm text-zinc-400">{subtitle}</p>}
        </div>
      </div>
      {right}
    </div>
  );
}

export function Field({ label, hint, children, className }: { label: ReactNode; hint?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <label className={clsx('block', className)}>
      <span className="label">{label}</span>
      {children}
      {hint && <span className="mt-1.5 block text-xs leading-relaxed text-zinc-500">{hint}</span>}
    </label>
  );
}

export function Pill({ children, className }: { children: ReactNode; className?: string }) {
  return <span className={clsx('chip', className)}>{children}</span>;
}

export function Skeleton({ className }: { className?: string }) {
  return (
    <div className={clsx('relative overflow-hidden rounded-xl bg-white/[0.04]', className)}>
      <div className="absolute inset-0 animate-shimmer bg-gradient-to-r from-transparent via-white/[0.05] to-transparent" />
    </div>
  );
}
