import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import './index.css';

async function boot() {
  // Dev-only fake backend. `import.meta.env.VITE_MOCK` is statically replaced at build time,
  // so the mock code is dropped entirely from production bundles.
  if (import.meta.env.VITE_MOCK === '1') {
    const { installMocks } = await import('./mocks');
    installMocks();
  }
  ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
      <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
        <App />
      </BrowserRouter>
    </React.StrictMode>,
  );
}
void boot();
