import clsx from 'clsx';
import { AnimatePresence, motion } from 'framer-motion';
import { AlertTriangle, CalendarClock, CheckCircle2, Home, Info, KeyRound, Settings as SettingsIcon, X, XCircle } from 'lucide-react';
import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { useStore } from '../lib/store';
import { GoblinMark, Wordmark } from './Brand';

/* ───────────── Live indicator ───────────── */

export function LiveIndicator({ compact }: { compact?: boolean }) {
  const sse = useStore((s) => s.sse);
  const meta = {
    live: { label: 'Live', dot: 'bg-goblin-400', text: 'text-goblin-300', title: 'Connected — updates stream in real time' },
    connecting: { label: 'Connecting', dot: 'bg-amber-400', text: 'text-amber-300', title: 'Connecting to ClipGoblin…' },
    reconnecting: { label: 'Offline', dot: 'bg-rose-500', text: 'text-rose-300', title: 'Lost connection to the server — retrying' },
  }[sse];
  return (
    <div
      className="flex h-8 items-center gap-2 rounded-full border border-white/[0.07] bg-white/[0.03] px-3 text-xs font-medium"
      title={meta.title}
    >
      <span className="relative flex h-2 w-2">
        {sse === 'live' && <span className={clsx('absolute inset-0 animate-pulse-ring rounded-full', meta.dot)} />}
        <span className={clsx('relative h-2 w-2 rounded-full', meta.dot, sse !== 'live' && 'animate-pulse')} />
      </span>
      {!compact && <span className={meta.text}>{meta.label}</span>}
    </div>
  );
}

/* ───────────── Navigation ───────────── */

const NAV = [
  { to: '/', label: 'Clips', icon: Home, end: true },
  { to: '/queue', label: 'Queue', icon: CalendarClock },
  { to: '/settings', label: 'Settings', icon: SettingsIcon },
];

export function TopNav() {
  const pubs = useStore((s) => s.publications);
  const upcoming = useMemo(
    () => Object.values(pubs).filter((p) => p.status === 'scheduled' || p.status === 'uploading' || p.status === 'processing').length,
    [pubs],
  );
  return (
    <header className="sticky top-0 z-40 border-b border-white/[0.06] bg-ink-900/70 backdrop-blur-2xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6">
        <Link to="/" className="group flex items-center gap-2.5">
          <motion.div whileHover={{ rotate: [-6, 6, -3, 0], scale: 1.06 }} transition={{ duration: 0.5 }}>
            <GoblinMark className="h-9 w-9" />
          </motion.div>
          <Wordmark />
        </Link>
        <nav className="ml-6 hidden items-center gap-1 md:flex">
          {NAV.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              end={n.end}
              className={({ isActive }) =>
                clsx(
                  'relative flex h-9 items-center gap-2 rounded-lg px-3 text-sm font-medium transition-colors',
                  isActive ? 'text-white' : 'text-zinc-400 hover:text-zinc-100',
                )
              }
            >
              {({ isActive }) => (
                <>
                  {isActive && (
                    <motion.span
                      layoutId="nav-pill"
                      className="absolute inset-0 rounded-lg bg-white/[0.07] ring-1 ring-white/[0.08]"
                      transition={{ type: 'spring', stiffness: 500, damping: 40 }}
                    />
                  )}
                  <n.icon className="relative h-4 w-4" />
                  <span className="relative">{n.label}</span>
                  {n.to === '/queue' && upcoming > 0 && (
                    <span className="relative rounded-full bg-hex-500 px-1.5 text-[10px] font-bold leading-4 text-white">{upcoming}</span>
                  )}
                </>
              )}
            </NavLink>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <LiveIndicator />
        </div>
      </div>
    </header>
  );
}

export function BottomNav() {
  const pubs = useStore((s) => s.publications);
  const upcoming = Object.values(pubs).filter((p) => p.status === 'scheduled').length;
  return (
    <nav className="pb-safe fixed inset-x-0 bottom-0 z-40 border-t border-white/[0.07] bg-ink-900/85 pt-1.5 backdrop-blur-2xl md:hidden">
      <div className="mx-auto grid max-w-md grid-cols-3">
        {NAV.map((n) => (
          <NavLink
            key={n.to}
            to={n.to}
            end={n.end}
            className={({ isActive }) =>
              clsx(
                'relative flex flex-col items-center gap-0.5 py-1.5 text-[11px] font-medium transition-colors',
                isActive ? 'text-goblin-300' : 'text-zinc-500',
              )
            }
          >
            {({ isActive }) => (
              <>
                <div className="relative">
                  <n.icon className={clsx('h-5 w-5 transition-transform', isActive && 'scale-110')} />
                  {n.to === '/queue' && upcoming > 0 && (
                    <span className="absolute -right-2.5 -top-1.5 rounded-full bg-hex-500 px-1 text-[9px] font-bold leading-[14px] text-white">
                      {upcoming}
                    </span>
                  )}
                </div>
                {n.label}
                {isActive && <motion.span layoutId="bnav-dot" className="absolute -top-1.5 h-0.5 w-8 rounded-full bg-goblin-400" />}
              </>
            )}
          </NavLink>
        ))}
      </div>
    </nav>
  );
}

/* ───────────── Toasts ───────────── */

export function Toasts() {
  const toasts = useStore((s) => s.toasts);
  const dismiss = useStore((s) => s.dismiss);
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-20 z-[100] flex flex-col items-center gap-2 px-4 md:bottom-6 md:right-6 md:left-auto md:items-end">
      <AnimatePresence initial={false}>
        {toasts.map((t) => {
          const icon = {
            success: <CheckCircle2 className="h-5 w-5 text-goblin-400" />,
            error: <XCircle className="h-5 w-5 text-rose-400" />,
            info: <Info className="h-5 w-5 text-sky-400" />,
            goblin: <GoblinMark className="h-6 w-6" animated={false} />,
          }[t.kind];
          return (
            <motion.div
              key={t.id}
              layout
              initial={{ opacity: 0, y: 24, scale: 0.92 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, x: 40, scale: 0.95, transition: { duration: 0.18 } }}
              transition={{ type: 'spring', stiffness: 420, damping: 32 }}
              className={clsx(
                'pointer-events-auto flex w-full max-w-sm items-start gap-3 rounded-2xl border bg-ink-800/95 p-3.5 pr-2 shadow-2xl backdrop-blur-xl',
                t.kind === 'error' ? 'border-rose-500/25' : t.kind === 'success' ? 'border-goblin-400/20' : 'border-white/10',
              )}
            >
              <div className="mt-0.5">{icon}</div>
              <div className="min-w-0 flex-1">
                <div className="text-sm font-semibold text-white">{t.title}</div>
                {t.body && <div className="mt-0.5 break-words text-[13px] leading-snug text-zinc-400">{t.body}</div>}
              </div>
              <button onClick={() => dismiss(t.id)} className="rounded-lg p-1 text-zinc-500 hover:bg-white/5 hover:text-white" aria-label="Dismiss">
                <X className="h-4 w-4" />
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}

/* ───────────── System banner ───────────── */

export function SystemBanner() {
  const system = useStore((s) => s.system);
  const location = useLocation();
  const [dismissed, setDismissed] = useState<string[]>(() => {
    try {
      return JSON.parse(sessionStorage.getItem('cg-dismissed-banners') || '[]');
    } catch {
      return [];
    }
  });
  useEffect(() => {
    try {
      sessionStorage.setItem('cg-dismissed-banners', JSON.stringify(dismissed));
    } catch {
      /* ignore */
    }
  }, [dismissed]);

  if (!system) return null;
  const items: { id: string; tone: 'warn' | 'info' | 'error'; icon: ReactNode; text: ReactNode; action?: ReactNode }[] = [];
  if (!system.ffmpeg)
    items.push({
      id: 'ffmpeg',
      tone: 'error',
      icon: <XCircle className="h-4 w-4" />,
      text: <>ffmpeg isn't available — rendering won't work. Run <span className="kbd">npm install</span> in the project root.</>,
    });
  if (system.analyzer === 'heuristic')
    items.push({
      id: 'heuristic',
      tone: 'warn',
      icon: <KeyRound className="h-4 w-4" />,
      text: (
        <>
          <b className="font-semibold text-amber-100">Heuristic mode.</b> Add an Anthropic API key and Claude will pick the actually-funny moments.
        </>
      ),
      action: location.pathname.startsWith('/settings') ? null : (
        <Link to="/settings#ai" className="btn btn-sm border border-amber-300/30 bg-amber-300/10 text-amber-100 hover:bg-amber-300/20">
          Add key
        </Link>
      ),
    });
  if (system.ytdlp === false)
    items.push({
      id: 'ytdlp',
      tone: 'info',
      icon: <Info className="h-4 w-4" />,
      text: <>yt-dlp (for VOD links) downloads automatically the first time you paste a link — one-time, ~35 MB.</>,
    });
  if (system.transcription === 'local' && system.localModelReady === false)
    items.push({
      id: 'model',
      tone: 'info',
      icon: <Info className="h-4 w-4" />,
      text: <>The free on-device transcription model downloads on your first job (one-time, ~150 MB).</>,
    });

  const visible = items.filter((i) => !dismissed.includes(i.id));
  if (!visible.length) return null;
  return (
    <div className="mx-auto max-w-7xl space-y-2 px-4 pt-4 sm:px-6">
      <AnimatePresence initial={false}>
        {visible.map((i) => (
          <motion.div
            key={i.id}
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div
              className={clsx(
                'flex items-center gap-3 rounded-xl border px-3.5 py-2.5 text-[13px] leading-snug',
                i.tone === 'warn' && 'border-amber-300/20 bg-gradient-to-r from-amber-300/[0.08] to-transparent text-amber-200/90',
                i.tone === 'info' && 'border-sky-400/15 bg-sky-400/[0.05] text-sky-200/80',
                i.tone === 'error' && 'border-rose-500/25 bg-rose-500/[0.08] text-rose-200',
              )}
            >
              <span className="shrink-0">{i.tone === 'warn' ? <AlertTriangle className="h-4 w-4" /> : i.icon}</span>
              <div className="min-w-0 flex-1">{i.text}</div>
              {i.action}
              <button
                onClick={() => setDismissed((d) => [...d, i.id])}
                className="shrink-0 rounded-md p-1 opacity-60 hover:bg-white/5 hover:opacity-100"
                aria-label="Dismiss"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

/* ───────────── Modal / sheet ───────────── */

export function Modal({ open, onClose, children, className }: { open: boolean; onClose: () => void; children: ReactNode; className?: string }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);
  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-6" initial="hidden" animate="show" exit="hidden">
          <motion.div
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
            variants={{ hidden: { opacity: 0 }, show: { opacity: 1 } }}
            onClick={onClose}
          />
          <motion.div
            variants={{ hidden: { opacity: 0, y: 40, scale: 0.98 }, show: { opacity: 1, y: 0, scale: 1 } }}
            transition={{ type: 'spring', stiffness: 380, damping: 34 }}
            className={clsx(
              'relative max-h-[94dvh] w-full overflow-y-auto rounded-t-3xl border border-white/10 bg-ink-850 shadow-2xl sm:rounded-3xl',
              className ?? 'max-w-lg',
            )}
          >
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ───────────── Empty states ───────────── */

export function GoblinScene({ mood = 'idle', className }: { mood?: 'idle' | 'sleep' | 'hunt'; className?: string }) {
  return (
    <div className={clsx('relative mx-auto', className ?? 'h-28 w-28')}>
      <div className="absolute inset-4 rounded-full bg-goblin-400/20 blur-2xl" />
      <div className="absolute inset-6 translate-x-4 rounded-full bg-hex-500/25 blur-2xl" />
      <div className="relative h-full w-full animate-float">
        <GoblinMark className="h-full w-full drop-shadow-[0_12px_30px_rgba(198,255,61,.25)]" />
        {mood === 'sleep' && (
          <div className="absolute -right-2 -top-2 font-display text-lg font-extrabold text-hex-300">
            <motion.span
              className="inline-block"
              animate={{ y: [0, -8], opacity: [0, 1, 0] }}
              transition={{ repeat: Infinity, duration: 2.2 }}
            >
              z
            </motion.span>
            <motion.span
              className="inline-block text-sm"
              animate={{ y: [0, -10], opacity: [0, 1, 0] }}
              transition={{ repeat: Infinity, duration: 2.2, delay: 0.7 }}
            >
              z
            </motion.span>
          </div>
        )}
        {mood === 'hunt' && <div className="absolute -right-1 top-0 text-xl">🔎</div>}
      </div>
    </div>
  );
}

export function EmptyState({
  title,
  body,
  action,
  mood,
  className,
}: {
  title: ReactNode;
  body?: ReactNode;
  action?: ReactNode;
  mood?: 'idle' | 'sleep' | 'hunt';
  className?: string;
}) {
  return (
    <div
      className={clsx(
        'relative flex flex-col items-center overflow-hidden rounded-3xl border border-dashed border-white/10 bg-ink-850/40 px-6 py-12 text-center',
        className,
      )}
    >
      <div className="absolute inset-0 bg-grid opacity-60 [mask-image:radial-gradient(ellipse_at_center,black_20%,transparent_70%)]" />
      <GoblinScene mood={mood} className="relative h-20 w-20" />
      <h3 className="relative mt-5 font-display text-lg font-bold text-white">{title}</h3>
      {body && <p className="relative mt-1.5 max-w-sm text-sm text-zinc-400">{body}</p>}
      {action && <div className="relative mt-5">{action}</div>}
    </div>
  );
}
