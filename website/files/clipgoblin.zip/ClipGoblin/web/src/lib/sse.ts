import { useEffect } from 'react';
import { transport } from './api';
import { resyncAll, useStore } from './store';
import type { SSEMessage } from './types';

/**
 * One app-wide SSE connection to /api/events. Every message updates the central store, so every
 * screen is live without polling. Reconnects with backoff and resyncs after a gap.
 */
export function useEventStream() {
  useEffect(() => {
    let es: ReturnType<typeof transport.events> | null = null;
    let retry: ReturnType<typeof setTimeout> | null = null;
    let attempts = 0;
    let everConnected = false;
    let closed = false;
    const { setSse, apply } = useStore.getState();

    const connect = () => {
      if (closed) return;
      setSse(everConnected ? 'reconnecting' : 'connecting');
      es = transport.events();
      es.onopen = () => {
        attempts = 0;
        if (everConnected) resyncAll();
        everConnected = true;
        setSse('live');
      };
      es.onmessage = (ev) => {
        try {
          const msg = JSON.parse(ev.data) as SSEMessage;
          if (msg && msg.type) apply(msg);
        } catch {
          /* ignore malformed */
        }
      };
      es.onerror = () => {
        setSse('reconnecting');
        // Native EventSource retries on its own while CONNECTING; if it gave up (CLOSED), we retry.
        if (es && es.readyState === 2) {
          es.close();
          attempts++;
          retry = setTimeout(connect, Math.min(15000, 1000 * 2 ** Math.min(attempts, 4)));
        }
      };
    };
    connect();

    const onVisible = () => {
      if (document.visibilityState === 'visible' && (!es || es.readyState === 2)) {
        if (retry) clearTimeout(retry);
        connect();
      }
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      closed = true;
      document.removeEventListener('visibilitychange', onVisible);
      if (retry) clearTimeout(retry);
      es?.close();
    };
  }, []);
}
