# ClipGoblin — architecture contract

Local web app: drop in an hour-long VOD (file upload or Twitch/YouTube/Kick URL) → it finds the funniest /
weirdest / most hooky moments → renders vertical 9:16 shorts with burned-in animated captions, a hook
banner, a cold-open tease, jump cuts and a retention progress bar → publishes them to YouTube Shorts,
TikTok and Instagram Reels (manually, scheduled, or fully on autopilot).

Node 22, ESM JavaScript (no TypeScript on the server), Express. Port 4777. Data lives in `./data`.
Web UI: Vite + React + Tailwind in `./web`, built to `web/dist`, served by the server.

## Ownership (do not edit files you don't own; ask the orchestrator instead)

| Path | Owner |
|---|---|
| `server/config.js`, `server/store.js`, `server/events.js`, `server/index.js`, root `package.json` | orchestrator (already written — read them) |
| `server/routes/jobs.js`, `server/pipeline/**` | Pipeline agent |
| `server/publish/**` | Publishing agent |
| `web/**` | Frontend agent |

Root deps already installed: express, multer, @anthropic-ai/sdk, ffmpeg-static (ffmpeg 6.0 with libass,
drawtext, zoompan), ffprobe-static, @huggingface/transformers, nanoid. If you truly need another server
dependency, run `npm install --no-audit --no-fund <pkg>` in the repo root (retry once if npm reports a lock
conflict — another agent may be installing).

## Shared server modules (already written)

- `config.js`: `paths` (data, uploads, work, clips, bin, models, tokens, …), `getSettings()`,
  `updateSettings(patch)`, `publicSettings()`, `writeJsonAtomic(file, value)`, `PORT`.
- `store.js`: `store.newId(prefix)`, `store.get(coll,id)`, `store.list(coll, filter?)` (newest first),
  `store.insert(coll, doc)`, `store.update(coll, id, patch)` (shallow merge), `store.remove(coll,id)`.
  Collections: `jobs`, `clips`, `publications`. Every insert/update is broadcast over SSE automatically.
- `events.js`: `emit({type, data})`. SSE at `GET /api/events`; each message is JSON
  `{type: 'job'|'clip'|'publication'|'job:removed'|'clip:removed'|'publication:removed'|'toast', data}`.
- `index.js` imports `registerJobRoutes(app, ctx)` + `resumeJobs()` from `server/routes/jobs.js`, and
  `registerPublishRoutes(app, ctx)` + `startScheduler(ctx)` from `server/publish/index.js`.
  `ctx = { app, paths, getSettings, baseUrl }`.

Settings shape: see `DEFAULT_SETTINGS` in `server/config.js`. `GET /api/settings` returns it with
secrets masked as `"••••abcd"`; `PUT /api/settings` deep-merges a partial patch (masked values ignored).

## Data model

```js
Job = {
  id: 'job_xxx', createdAt, updatedAt,
  source: { type: 'file'|'url', name, url? },
  status: 'queued'|'downloading'|'probing'|'transcribing'|'analyzing'|'rendering'|'done'|'error'|'canceled',
  progress: 0..1,          // progress of the whole job
  stage: 'Transcribing 12:30 / 58:02',   // human-readable current step
  error: null|string,
  durationSec, width, height, videoPath,
  options: { maxClips, minSec, maxSec, layout, captionStyle, facecam, coldOpen, jumpCuts, progressBar, hookBanner, chaos },
  clipIds: [],
  thumb: '/media/clips/job_xxx.jpg',   // poster frame of the VOD
  analyzer: 'claude'|'heuristic',      // heuristic = no Anthropic key configured
}

Clip = {
  id: 'clip_xxx', jobId, createdAt, updatedAt,
  rank: 1,                  // 1 = best
  score: 0..100,            // predicted virality / retention
  start, end,               // seconds in the source VOD
  coldOpen: { start, end } | null,   // ≤1.5 s payoff flashed at the very beginning
  hook: 'he did NOT expect that 💀',  // on-screen hook text for the first ~3 s (≤ 7 words)
  title: 'string ≤ 90 chars',          // used for YouTube/TikTok title
  description: 'string',               // post caption
  hashtags: ['#fyp', ...],
  category: 'funny'|'rage'|'wtf'|'clutch'|'wholesome'|'cringe'|'weird',
  why: 'one sentence: why this will hold attention',
  transcript: 'text of the clip',
  status: 'pending'|'rendering'|'ready'|'error',
  progress: 0..1, error: null|string,
  file: '/media/clips/clip_xxx.mp4' | null,   // URL path, file lives in paths.clips
  thumb: '/media/clips/clip_xxx.jpg' | null,
  durationSec,
  style: { layout, captionStyle, coldOpen, jumpCuts, progressBar, hookBanner, chaos }, // overrides job.options
  publish: { youtube?: {status, url, publicationId}, tiktok?: {...}, instagram?: {...} }, // written by publishing agent
}

Publication = {
  id: 'pub_xxx', clipId, jobId, platform: 'youtube'|'tiktok'|'instagram',
  status: 'scheduled'|'uploading'|'processing'|'published'|'error'|'canceled',
  scheduledAt: ms epoch, publishedAt, progress: 0..1,
  remoteId, url, error,
  title, caption,        // snapshot of what was posted
}
```

## REST API

Pipeline agent (`server/routes/jobs.js`):
- `POST /api/jobs` — multipart (`file` field + optional `options` JSON string field) **or** JSON
  `{ url, options }`. Returns the Job. Starts processing in the background (queue: one job at a time).
- `GET /api/jobs` → Job[] ; `GET /api/jobs/:id` → `{ job, clips: Clip[] }` (clips sorted by rank)
- `DELETE /api/jobs/:id` — cancels if running, deletes job, its clips and files.
- `POST /api/jobs/:id/retry` — restart a failed/canceled job.
- `GET /api/jobs/:id/frame?t=SECONDS` → image/jpeg of the source at time t (for the facecam picker).
- `GET /api/clips` → Clip[] (all, newest first) ; `GET /api/clips/:id` → Clip
- `PATCH /api/clips/:id` — edit `hook,title,description,hashtags,start,end,style` (does not re-render).
- `POST /api/clips/:id/render` — re-render with current fields.
- `DELETE /api/clips/:id`
- `GET /api/system` → `{ ffmpeg: true, ytdlp: bool, analyzer: 'claude'|'heuristic', transcription: provider, localModelReady: bool }`

Publishing agent (`server/publish/index.js`):
- `GET /api/accounts` → `{ youtube: {configured, connected, name?, avatar?, note?}, tiktok: {...}, instagram: {...} }`
- `GET /api/auth/:platform/start` → 302 to the provider's OAuth consent page.
- `GET /api/auth/:platform/callback` → stores tokens, redirects to `/settings?connected=<platform>`.
- `POST /api/auth/:platform/disconnect`
- `POST /api/clips/:id/publish` `{ platforms: ['youtube',...], scheduleAt?: ms, title?, caption? }` → Publication[]
- `GET /api/publications` → Publication[] ; `DELETE /api/publications/:id` (cancel scheduled)
- `POST /api/publications/:id/retry`
- Autopilot: when a job reaches `status: 'done'` and `settings.autopilot.enabled`, schedule its top
  clips (score ≥ minScore, up to maxPerJob, spaced spacingMinutes apart) on the chosen platforms.
  Detect this by polling the store in the scheduler loop (mark `job.autopilotScheduled = true`).

Static: rendered clips and thumbnails at `/media/clips/<file>`.
