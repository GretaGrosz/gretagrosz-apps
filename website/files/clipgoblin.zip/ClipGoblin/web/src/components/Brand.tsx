import clsx from 'clsx';
import { useId } from 'react';
import type { Platform } from '../lib/types';

/** The goblin mark: pointy ears, glowing eyes, a slightly unhinged grin. */
export function GoblinMark({ className, animated = true }: { className?: string; animated?: boolean }) {
  const id = useId().replace(/:/g, '');
  return (
    <svg viewBox="0 0 40 40" className={clsx('shrink-0', className ?? 'h-8 w-8')} aria-hidden>
      <defs>
        <linearGradient id={`g${id}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#d6ff73" />
          <stop offset="0.55" stopColor="#9ff05a" />
          <stop offset="1" stopColor="#8b5cf6" />
        </linearGradient>
        <radialGradient id={`e${id}`} cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#fff" />
          <stop offset="0.5" stopColor="#f5ff9e" />
          <stop offset="1" stopColor="#c6ff3d" />
        </radialGradient>
      </defs>
      <rect x="0" y="0" width="40" height="40" rx="11" fill="#0d0d14" />
      <rect x="0.5" y="0.5" width="39" height="39" rx="10.5" fill="none" stroke="rgba(255,255,255,.08)" />
      {/* ears + head */}
      <path
        d="M3.5 13.5 L13 16.2 Q20 7.5 27 16.2 L36.5 13.5 L30.6 21.4 Q29.8 32.5 20 32.5 Q10.2 32.5 9.4 21.4 Z"
        fill={`url(#g${id})`}
      />
      {/* brow shading */}
      <path d="M13.2 18.6 Q16 17.2 18 19.2" stroke="#0d0d14" strokeWidth="1.3" fill="none" strokeLinecap="round" />
      <path d="M26.8 18.6 Q24 17.2 22 19.2" stroke="#0d0d14" strokeWidth="1.3" fill="none" strokeLinecap="round" />
      {/* eyes */}
      <g className={animated ? 'origin-center animate-blink' : undefined} style={{ transformBox: 'fill-box' }}>
        <ellipse cx="15.6" cy="22" rx="2.6" ry="2.3" fill="#0d0d14" />
        <ellipse cx="24.4" cy="22" rx="2.6" ry="2.3" fill="#0d0d14" />
        <circle cx="16.2" cy="21.6" r="1" fill={`url(#e${id})`} />
        <circle cx="25" cy="21.6" r="1" fill={`url(#e${id})`} />
      </g>
      {/* grin with teeth */}
      <path d="M14.2 26.4 Q20 30.6 25.8 26.4 Q20 28.4 14.2 26.4 Z" fill="#0d0d14" />
      <path d="M16.4 27.3 l0.9 1.5 l0.8 -1.2 Z M22.7 27.3 l-0.9 1.5 l-0.8 -1.2 Z" fill="#f4ffd6" />
    </svg>
  );
}

export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={clsx('font-display text-[19px] font-extrabold tracking-tight', className)}>
      <span className="text-white">Clip</span>
      <span className="text-gradient">Goblin</span>
    </span>
  );
}

export function PlatformIcon({ platform, className }: { platform: Platform | string; className?: string }) {
  const cls = clsx('shrink-0', className ?? 'h-4 w-4');
  if (platform === 'youtube')
    return (
      <svg viewBox="0 0 24 24" className={cls} aria-label="YouTube">
        <path
          fill="#ff2d2d"
          d="M23 7.2a3 3 0 0 0-2.1-2.1C19 4.6 12 4.6 12 4.6s-7 0-8.9.5A3 3 0 0 0 1 7.2 31 31 0 0 0 .5 12 31 31 0 0 0 1 16.8a3 3 0 0 0 2.1 2.1c1.9.5 8.9.5 8.9.5s7 0 8.9-.5a3 3 0 0 0 2.1-2.1c.4-1.6.5-4.8.5-4.8s0-3.2-.5-4.8Z"
        />
        <path fill="#fff" d="m9.75 15.1 5.85-3.1-5.85-3.1z" />
      </svg>
    );
  if (platform === 'tiktok')
    return (
      <svg viewBox="0 0 24 24" className={cls} aria-label="TikTok">
        <path
          fill="#25f4ee"
          transform="translate(-0.8 -0.6)"
          d="M16.6 2h-3.3v13.3a2.9 2.9 0 1 1-2.9-2.9c.3 0 .6 0 .9.1V9.1a6.3 6.3 0 1 0 5.3 6.2V8.6a7.9 7.9 0 0 0 4.6 1.5V6.8a4.6 4.6 0 0 1-4.6-4.8Z"
        />
        <path
          fill="#fe2c55"
          transform="translate(0.8 0.6)"
          d="M16.6 2h-3.3v13.3a2.9 2.9 0 1 1-2.9-2.9c.3 0 .6 0 .9.1V9.1a6.3 6.3 0 1 0 5.3 6.2V8.6a7.9 7.9 0 0 0 4.6 1.5V6.8a4.6 4.6 0 0 1-4.6-4.8Z"
        />
        <path
          fill="#fff"
          d="M16.6 2h-3.3v13.3a2.9 2.9 0 1 1-2.9-2.9c.3 0 .6 0 .9.1V9.1a6.3 6.3 0 1 0 5.3 6.2V8.6a7.9 7.9 0 0 0 4.6 1.5V6.8a4.6 4.6 0 0 1-4.6-4.8Z"
        />
      </svg>
    );
  if (platform === 'instagram')
    return (
      <svg viewBox="0 0 24 24" className={cls} aria-label="Instagram">
        <defs>
          <radialGradient id="ig-grad" cx="0.3" cy="1.05" r="1.2">
            <stop offset="0" stopColor="#fdd56b" />
            <stop offset="0.3" stopColor="#f77737" />
            <stop offset="0.6" stopColor="#e1306c" />
            <stop offset="1" stopColor="#833ab4" />
          </radialGradient>
        </defs>
        <rect x="2" y="2" width="20" height="20" rx="6" fill="url(#ig-grad)" />
        <circle cx="12" cy="12" r="4.4" fill="none" stroke="#fff" strokeWidth="1.9" />
        <circle cx="17.4" cy="6.6" r="1.25" fill="#fff" />
      </svg>
    );
  if (platform === 'twitch')
    return (
      <svg viewBox="0 0 24 24" className={cls} aria-label="Twitch">
        <path fill="#a970ff" d="M4.3 2 3 5.4v14h4.7V22h2.7l2.6-2.6h3.8L22 14.2V2H4.3Zm15.9 11.3-3 3h-4.7l-2.6 2.6v-2.6h-4V3.8h14.3v9.5Z" />
        <path fill="#a970ff" d="M15.5 7h1.8v5.2h-1.8zM10.6 7h1.8v5.2h-1.8z" />
      </svg>
    );
  if (platform === 'kick')
    return (
      <svg viewBox="0 0 24 24" className={cls} aria-label="Kick">
        <rect width="24" height="24" rx="5" fill="#53fc18" />
        <path fill="#0b0b0b" d="M6 5h4v4h2V7h2V5h4v6h-2v2h2v6h-4v-2h-2v-2h-2v4H6z" />
      </svg>
    );
  return null;
}
