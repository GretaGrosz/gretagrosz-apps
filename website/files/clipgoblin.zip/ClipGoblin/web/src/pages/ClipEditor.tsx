import clsx from 'clsx';
import { motion } from 'framer-motion';
import {
  AlertTriangle,
  ArrowLeft,
  Download,
  Hash,
  Lightbulb,
  Minus,
  Plus,
  RefreshCw,
  Save,
  Scissors,
  Send,
  Trash2,
  Type,
  Wand2,
  X,
  Zap,
} from 'lucide-react';
import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { EmptyState } from '../components/Chrome';
import { PublicationRow, PublishForm } from '../components/Publish';
import { ScoreRing } from '../components/ScoreRing';
import { CaptionPicker, LayoutPicker, StyleToggles } from '../components/StyleControls';
import { ProgressBar, Skeleton, Spinner } from '../components/ui';
import { api, errMsg } from '../lib/api';
import { fmtDuration, fmtTimecode, parseTimecode } from '../lib/format';
import { categoryMeta } from '../lib/meta';
import { toast, useStore } from '../lib/store';
import type { CaptionStyle, Clip, ClipStyle, Layout } from '../lib/types';

interface Draft {
  hook: string;
  title: string;
  description: string;
  hashtags: string[];
  start: number;
  end: number;
  style: ClipStyle;
}

const DEFAULT_STYLE: ClipStyle = {
  layout: 'auto',
  captionStyle: 'beast',
  coldOpen: true,
  jumpCuts: true,
  progressBar: true,
  hookBanner: true,
  chaos: false,
};

function toDraft(c: Clip, jobStyle: Partial<ClipStyle>): Draft {
  return {
    hook: c.hook ?? '',
    title: c.title ?? '',
    description: c.description ?? '',
    hashtags: c.hashtags ?? [],
    start: c.start,
    end: c.end,
    style: { ...DEFAULT_STYLE, ...pickStyle(jobStyle), ...pickStyle(c.style ?? {}) },
  };
}

function pickStyle(o: Partial<ClipStyle> & Record<string, unknown>): Partial<ClipStyle> {
  const out: Partial<ClipStyle> = {};
  for (const k of Object.keys(DEFAULT_STYLE) as (keyof ClipStyle)[]) if (o[k] !== undefined && o[k] !== null) (out as Record<string, unknown>)[k] = o[k];
  return out;
}

const same = (a: Draft, b: Draft) => JSON.stringify(a) === JSON.stringify(b);

export default function ClipEditor({ asModal }: { asModal?: boolean }) {
  const { id = '' } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const clip = useStore((s) => s.clips[id]);
  const job = useStore((s) => (clip ? s.jobs[clip.jobId] : undefined));
  const pubsMap = useStore((s) => s.publications);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [base, setBase] = useState<Draft | null>(null);
  const baseRef = useRef<Draft | null>(null);
  const [saving, setSaving] = useState<null | 'save' | 'render'>(null);
  const [tab, setTab] = useState<'edit' | 'publish'>('edit');

  const close = () => {
    const bg = (location.state as { backgroundLocation?: Location } | null)?.backgroundLocation;
    if (bg) navigate(-1);
    else navigate(clip ? `/jobs/${clip.jobId}` : '/');
  };

  // Load clip (and its job, for duration/options) if not in the store yet.
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const c = clip ?? (await api.clip(id));
        if (!alive) return;
        if (!clip) useStore.getState().upsertClips([c]);
        if (!useStore.getState().jobs[c.jobId]) await useStore.getState().loadJob(c.jobId).catch(() => {});
      } catch (err) {
        if (alive) setLoadError(errMsg(err));
      }
    })();
    if (!useStore.getState().loaded.publications) void useStore.getState().loadPublications();
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  // Keep the draft in sync with server changes unless the user has unsaved edits.
  useEffect(() => {
    if (!clip) return;
    const next = toDraft(clip, (job?.options ?? {}) as Partial<ClipStyle>);
    const prevBase = baseRef.current;
    baseRef.current = next;
    setBase(next);
    setDraft((d) => (!d || !prevBase || same(d, prevBase) ? next : d));
  }, [clip, job?.options]);

  // Escape closes the modal.
  useEffect(() => {
    if (!asModal) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !(e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement)) close();
    };
    window.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [asModal]);

  const pubs = useMemo(
    () => Object.values(pubsMap).filter((p) => p.clipId === id).sort((a, b) => (b.scheduledAt ?? 0) - (a.scheduledAt ?? 0)),
    [pubsMap, id],
  );

  const body = (() => {
    if (loadError && !clip)
      return (
        <div className="p-6">
          <EmptyState mood="hunt" title="Clip not found" body={loadError} action={<button className="btn btn-primary" onClick={close}>Go back</button>} />
        </div>
      );
    if (!clip || !draft || !base)
      return (
        <div className="grid gap-6 p-5 md:grid-cols-[minmax(0,340px)_1fr]">
          <Skeleton className="aspect-[9/16]" />
          <div className="space-y-4">
            <Skeleton className="h-10" />
            <Skeleton className="h-24" />
            <Skeleton className="h-40" />
          </div>
        </div>
      );

    const dirty = !same(draft, base);
    const rendering = clip.status === 'rendering' || clip.status === 'pending';
    const cat = categoryMeta(clip.category);
    const set = (p: Partial<Draft>) => setDraft((d) => (d ? { ...d, ...p } : d));
    const setStyle = (p: Partial<ClipStyle>) => setDraft((d) => (d ? { ...d, style: { ...d.style, ...p } } : d));
    const maxT = job?.durationSec ?? Math.max(clip.end + 60, draft.end + 60);
    const dur = draft.end - draft.start;
    const trimInvalid = dur <= 0.5 || draft.start < 0 || draft.end > maxT + 0.01;
    const hookWords = draft.hook.trim().split(/\s+/).filter(Boolean).length;

    const patchBody = () => ({
      hook: draft.hook,
      title: draft.title,
      description: draft.description,
      hashtags: draft.hashtags,
      start: +draft.start.toFixed(2),
      end: +draft.end.toFixed(2),
      style: draft.style,
    });
    const save = async (quiet = false) => {
      const updated = await api.updateClip(clip.id, patchBody());
      if (updated && updated.id) useStore.getState().upsertClips([updated]);
      baseRef.current = draft;
      setBase(draft);
      if (!quiet) toast.success('Saved');
    };
    const onSave = async () => {
      setSaving('save');
      try {
        await save();
      } catch (err) {
        toast.error('Save failed', errMsg(err));
      } finally {
        setSaving(null);
      }
    };
    const onRender = async () => {
      if (trimInvalid) return toast.error('Fix the trim first', 'End must be after start.');
      setSaving('render');
      try {
        if (dirty) await save(true);
        const c = await api.renderClip(clip.id);
        if (c && c.id) useStore.getState().upsertClips([c]);
        else useStore.getState().upsertClips([{ ...clip, status: 'pending', progress: 0 }]);
        toast.goblin('Re-rendering', 'Fresh pixels incoming.');
      } catch (err) {
        toast.error('Re-render failed', errMsg(err));
      } finally {
        setSaving(null);
      }
    };
    const onDelete = async () => {
      if (!confirm('Delete this clip?')) return;
      try {
        await api.deleteClip(clip.id);
        useStore.getState().apply({ type: 'clip:removed', data: { id: clip.id } });
        toast.info('Clip deleted');
        close();
      } catch (err) {
        toast.error('Could not delete', errMsg(err));
      }
    };

    return (
      <div className="grid gap-0 md:grid-cols-[minmax(0,380px)_1fr]">
        {/* Player */}
        <div className="relative border-white/[0.06] bg-ink-950/60 md:border-r">
         <div className="p-4 sm:p-5 md:sticky md:top-0">
          <Player clip={clip} />
          <div className="mt-4 flex gap-2">
            {clip.file ? (
              <a className="btn btn-outline flex-1" href={clip.file} download={`${(clip.title || clip.id).replace(/[^\w\- ]+/g, '').slice(0, 60) || clip.id}.mp4`}>
                <Download className="h-4 w-4" /> Download
              </a>
            ) : (
              <button className="btn btn-outline flex-1" disabled>
                <Download className="h-4 w-4" /> Download
              </button>
            )}
            <button className="btn btn-hex flex-1" onClick={onRender} disabled={!!saving || rendering}>
              {saving === 'render' || rendering ? <Spinner /> : <RefreshCw className="h-4 w-4" />}
              {rendering ? 'Rendering…' : dirty ? 'Save & re-render' : 'Re-render'}
            </button>
          </div>
          {rendering && (
            <div className="mt-3">
              <ProgressBar value={clip.progress} indeterminate={clip.status === 'pending'} tone="hex" />
              <div className="mt-1.5 flex justify-between text-[11px] text-zinc-500">
                <span>{clip.status === 'pending' ? 'Queued for render' : 'Rendering'}</span>
                <span className="font-mono">{Math.round((clip.progress || 0) * 100)}%</span>
              </div>
            </div>
          )}
          {clip.status === 'error' && (
            <div className="mt-3 flex items-start gap-2 rounded-xl bg-rose-500/10 p-2.5 text-xs text-rose-200">
              <AlertTriangle className="mt-px h-3.5 w-3.5 shrink-0" /> <span className="break-words">{clip.error || 'Render failed'}</span>
            </div>
          )}
         </div>
        </div>

        {/* Form */}
        <div className="min-w-0">
          {/* header */}
          <div className={clsx('sticky z-10 border-b border-white/[0.06] bg-ink-850/95 px-4 py-3 backdrop-blur-xl sm:px-6', asModal ? 'top-0' : 'top-16')}>
            <div className="flex items-center gap-3">
              {!asModal && (
                <button onClick={close} className="rounded-lg p-1.5 text-zinc-400 hover:bg-white/5 hover:text-white" aria-label="Back">
                  <ArrowLeft className="h-5 w-5" />
                </button>
              )}
              <ScoreRing score={clip.score} size={40} />
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className={clsx('chip', cat.cls)}>
                    {cat.emoji} {cat.label}
                  </span>
                  <span className="chip border-white/10 bg-white/[0.03] text-zinc-400">Rank #{clip.rank}</span>
                </div>
                {job && (
                  <Link to={`/jobs/${job.id}`} className="mt-0.5 block truncate text-xs text-zinc-500 hover:text-zinc-300">
                    from {job.source?.name}
                  </Link>
                )}
              </div>
              <button onClick={onDelete} className="rounded-lg p-2 text-zinc-500 hover:bg-rose-500/10 hover:text-rose-300" title="Delete clip">
                <Trash2 className="h-4 w-4" />
              </button>
              {asModal && (
                <button onClick={close} className="rounded-lg p-2 text-zinc-400 hover:bg-white/5 hover:text-white" aria-label="Close">
                  <X className="h-5 w-5" />
                </button>
              )}
            </div>
            <div className="mt-3 flex gap-1 rounded-xl bg-ink-950/60 p-1">
              {(['edit', 'publish'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className={clsx(
                    'relative flex h-8 flex-1 items-center justify-center gap-1.5 rounded-lg text-[13px] font-semibold transition-colors',
                    tab === t ? 'text-white' : 'text-zinc-500 hover:text-zinc-300',
                  )}
                >
                  {tab === t && <motion.span layoutId="editor-tab" className="absolute inset-0 rounded-lg bg-white/[0.08] ring-1 ring-white/10" />}
                  <span className="relative flex items-center gap-1.5">
                    {t === 'edit' ? <Wand2 className="h-3.5 w-3.5" /> : <Send className="h-3.5 w-3.5" />}
                    {t === 'edit' ? 'Edit' : 'Publish'}
                    {t === 'publish' && pubs.length > 0 && (
                      <span className="rounded-full bg-hex-500/80 px-1.5 text-[10px] leading-4 text-white">{pubs.length}</span>
                    )}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {tab === 'edit' ? (
            <div className="space-y-7 px-4 py-5 sm:px-6">
              {clip.why && (
                <div className="flex items-start gap-2.5 rounded-xl border border-goblin-400/15 bg-goblin-400/[0.04] p-3 text-[13px] leading-snug text-zinc-300">
                  <Lightbulb className="mt-px h-4 w-4 shrink-0 text-goblin-400" />
                  <span>
                    <b className="font-semibold text-goblin-200">Why it hits: </b>
                    {clip.why}
                  </span>
                </div>
              )}

              <EditorSection icon={<Zap className="h-4 w-4" />} title="Hook & copy">
                <div className="space-y-4">
                  <div>
                    <div className="flex items-baseline justify-between">
                      <span className="label">On-screen hook</span>
                      <span className={clsx('text-[11px] tabular', hookWords > 7 ? 'text-amber-300' : 'text-zinc-500')}>{hookWords}/7 words</span>
                    </div>
                    <input
                      className="input h-12 font-display text-lg font-bold"
                      value={draft.hook}
                      onChange={(e) => set({ hook: e.target.value })}
                      placeholder="he did NOT expect that 💀"
                    />
                  </div>
                  <div>
                    <div className="flex items-baseline justify-between">
                      <span className="label">Title</span>
                      <span className={clsx('text-[11px] tabular', draft.title.length > 90 ? 'text-rose-300' : 'text-zinc-500')}>{draft.title.length}/90</span>
                    </div>
                    <input className="input" value={draft.title} onChange={(e) => set({ title: e.target.value })} maxLength={140} />
                  </div>
                  <div>
                    <span className="label">Description / caption</span>
                    <textarea className="input min-h-[88px] resize-y" rows={3} value={draft.description} onChange={(e) => set({ description: e.target.value })} />
                  </div>
                  <div>
                    <span className="label flex items-center gap-1">
                      <Hash className="h-3 w-3" /> Hashtags
                    </span>
                    <HashtagInput value={draft.hashtags} onChange={(hashtags) => set({ hashtags })} />
                  </div>
                </div>
              </EditorSection>

              <EditorSection icon={<Scissors className="h-4 w-4" />} title="Trim" right={<span className="font-mono text-xs text-zinc-400">{fmtTimecode(dur)} long</span>}>
                <TrimBar start={draft.start} end={draft.end} total={maxT} coldOpen={clip.coldOpen} />
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <TimeField label="Start" value={draft.start} onChange={(v) => set({ start: Math.max(0, Math.min(v, draft.end - 0.5)) })} />
                  <TimeField label="End" value={draft.end} onChange={(v) => set({ end: Math.min(maxT, Math.max(v, draft.start + 0.5)) })} />
                </div>
                {trimInvalid && <p className="mt-2 text-xs text-rose-300">End must be at least 0.5 s after start and within the VOD.</p>}
                <p className="mt-2 text-xs text-zinc-500">Trim changes need a re-render to show up in the video.</p>
              </EditorSection>

              <EditorSection icon={<Type className="h-4 w-4" />} title="Style">
                <div className="space-y-5">
                  <div>
                    <span className="label">Layout</span>
                    <LayoutPicker value={draft.style.layout} onChange={(layout: Layout) => setStyle({ layout })} compact />
                  </div>
                  <div>
                    <span className="label">Captions</span>
                    <CaptionPicker value={draft.style.captionStyle} onChange={(captionStyle: CaptionStyle) => setStyle({ captionStyle })} />
                  </div>
                  <StyleToggles value={draft.style} onChange={(k, v) => setStyle({ [k]: v })} />
                </div>
              </EditorSection>
              <div className="h-16 md:h-4" />
            </div>
          ) : (
            <div className="space-y-6 px-4 py-5 sm:px-6">
              <div className="rounded-xl border border-white/[0.06] bg-ink-950/40 p-3.5">
                <div className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">Posting as</div>
                <div className="mt-1 font-semibold text-white">{draft.title || 'Untitled'}</div>
                <div className="mt-1 line-clamp-2 text-[13px] text-zinc-400">
                  {draft.description} <span className="text-hex-300">{draft.hashtags.join(' ')}</span>
                </div>
                <button className="mt-2 text-xs font-medium text-goblin-400 hover:underline" onClick={() => setTab('edit')}>
                  Edit copy
                </button>
              </div>
              <PublishForm
                clipIds={[clip.id]}
                single={{
                  title: draft.title,
                  caption: [draft.description, draft.hashtags.join(' ')].filter(Boolean).join('\n\n'),
                  beforeSubmit: async () => {
                    if (dirty) await save(true);
                  },
                }}
              />
              {clip.status !== 'ready' && (
                <p className="text-xs text-amber-300/80">Heads up: this clip isn't rendered yet — it'll post once the render is ready, or fail if it never finishes.</p>
              )}
              <div>
                <h4 className="mb-2 text-xs font-medium uppercase tracking-wider text-zinc-500">History</h4>
                {pubs.length ? (
                  <div className="space-y-2">
                    {pubs.map((p) => (
                      <PublicationRow key={p.id} pub={p} />
                    ))}
                  </div>
                ) : (
                  <p className="rounded-xl border border-dashed border-white/10 p-4 text-center text-sm text-zinc-500">Not posted anywhere yet.</p>
                )}
              </div>
            </div>
          )}

          {/* Save bar */}
          {tab === 'edit' && (
            <div
              className={clsx(
                'sticky z-10 flex items-center gap-2 border-t border-white/[0.06] bg-ink-850 px-4 py-3 sm:px-6',
                asModal ? 'bottom-0' : 'bottom-[72px] md:bottom-0',
              )}
            >
              <span className="flex-1 text-xs text-zinc-500">{dirty ? 'Unsaved changes' : 'All changes saved'}</span>
              {dirty && (
                <button className="btn btn-sm btn-ghost" onClick={() => setDraft(base)}>
                  Discard
                </button>
              )}
              <button className="btn btn-sm btn-outline" onClick={onSave} disabled={!dirty || !!saving || trimInvalid}>
                {saving === 'save' ? <Spinner className="h-3.5 w-3.5" /> : <Save className="h-3.5 w-3.5" />} Save
              </button>
              <button className="btn btn-sm btn-primary" onClick={onRender} disabled={!!saving || rendering || trimInvalid}>
                <RefreshCw className="h-3.5 w-3.5" /> {dirty ? 'Save & render' : 'Re-render'}
              </button>
            </div>
          )}
        </div>
      </div>
    );
  })();

  if (asModal)
    return (
      <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-5">
        <motion.div className="absolute inset-0 bg-black/75 backdrop-blur-sm" initial={{ opacity: 0 }} animate={{ opacity: 1 }} onClick={close} />
        <motion.div
          initial={{ opacity: 0, y: 40, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ type: 'spring', stiffness: 360, damping: 34 }}
          className="relative h-[96dvh] w-full max-w-5xl overflow-y-auto overscroll-contain rounded-t-3xl border border-white/10 bg-ink-850 shadow-2xl sm:h-auto sm:max-h-[92dvh] sm:rounded-3xl"
        >
          {body}
        </motion.div>
      </div>
    );

  return (
    <div className="mx-auto max-w-6xl px-0 pb-24 sm:px-6 sm:pt-6">
      <div className="overflow-clip border-white/[0.07] bg-ink-850/80 sm:rounded-3xl sm:border">{body}</div>
    </div>
  );
}

function EditorSection({ icon, title, right, children }: { icon: ReactNode; title: string; right?: ReactNode; children: ReactNode }) {
  return (
    <section>
      <div className="mb-3 flex items-center gap-2">
        <span className="text-goblin-400">{icon}</span>
        <h3 className="flex-1 text-sm font-bold text-white">{title}</h3>
        {right}
      </div>
      {children}
    </section>
  );
}

function Player({ clip }: { clip: Clip }) {
  const ref = useRef<HTMLVideoElement>(null);
  const src = clip.file && clip.status === 'ready' ? `${clip.file}${clip.file.includes('?') ? '&' : '?'}v=${clip.updatedAt}` : null;
  return (
    <div className="relative mx-auto aspect-[9/16] max-h-[58dvh] w-full overflow-hidden rounded-2xl bg-black shadow-[0_30px_80px_-30px_rgba(139,92,246,.5)] ring-1 ring-white/10 md:max-h-[70dvh]">
      {src ? (
        <video
          key={src}
          ref={ref}
          src={src}
          poster={clip.thumb ?? undefined}
          className="h-full w-full object-contain"
          controls
          playsInline
          autoPlay
          muted
          loop
        />
      ) : (
        <>
          {clip.thumb && <img src={clip.thumb} alt="" className="absolute inset-0 h-full w-full object-cover opacity-40 blur-sm" />}
          <div className="absolute inset-0 grid place-items-center p-6 text-center">
            <div>
              <Spinner className="mx-auto h-6 w-6 text-hex-300" />
              <div className="mt-3 text-sm font-medium text-zinc-300">{clip.status === 'error' ? 'Render failed' : 'Rendering preview…'}</div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function TimeField({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  const [text, setText] = useState(fmtTimecode(value));
  const [focused, setFocused] = useState(false);
  useEffect(() => {
    if (!focused) setText(fmtTimecode(value));
  }, [value, focused]);
  const commit = () => {
    const v = parseTimecode(text);
    if (v != null) onChange(v);
    else setText(fmtTimecode(value));
  };
  return (
    <div>
      <span className="label">{label}</span>
      <div className="flex h-10 items-center rounded-xl border border-white/[0.08] bg-ink-950/60 focus-within:border-goblin-400/60">
        <button type="button" className="flex h-full items-center gap-0.5 px-2.5 text-xs font-medium text-zinc-400 hover:text-white" onClick={() => onChange(+(value - 0.5).toFixed(2))}>
          <Minus className="h-3 w-3" />
          0.5
        </button>
        <input
          className="h-full w-full min-w-0 bg-transparent text-center font-mono text-sm text-white outline-none"
          value={text}
          onFocus={() => setFocused(true)}
          onBlur={() => {
            setFocused(false);
            commit();
          }}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') (e.target as HTMLInputElement).blur();
            if (e.key === 'ArrowUp') (e.preventDefault(), onChange(+(value + 0.1).toFixed(2)));
            if (e.key === 'ArrowDown') (e.preventDefault(), onChange(+(value - 0.1).toFixed(2)));
          }}
          inputMode="decimal"
          aria-label={`${label} time`}
        />
        <button type="button" className="flex h-full items-center gap-0.5 px-2.5 text-xs font-medium text-zinc-400 hover:text-white" onClick={() => onChange(+(value + 0.5).toFixed(2))}>
          <Plus className="h-3 w-3" />
          0.5
        </button>
      </div>
    </div>
  );
}

/** Where the clip sits in the VOD, zoomed to a window around it. */
function TrimBar({ start, end, total, coldOpen }: { start: number; end: number; total: number; coldOpen: Clip['coldOpen'] }) {
  const pad = Math.max(10, (end - start) * 0.6);
  const from = Math.max(0, start - pad);
  const to = Math.min(total, end + pad);
  const span = Math.max(1, to - from);
  const pct = (t: number) => `${((t - from) / span) * 100}%`;
  return (
    <div>
      <div className="relative h-11 overflow-hidden rounded-xl bg-ink-950/70 ring-1 ring-white/[0.06]">
        <div className="absolute inset-0 opacity-50 [background:repeating-linear-gradient(90deg,rgba(255,255,255,.06)_0_2px,transparent_2px_9px)]" />
        <motion.div
          className="absolute inset-y-1 rounded-lg border-2 border-goblin-400 bg-goblin-400/15 shadow-[0_0_20px_-4px_rgba(198,255,61,.5)]"
          initial={false}
          animate={{ left: pct(start), width: `${((end - start) / span) * 100}%` }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        />
        {coldOpen && coldOpen.end > coldOpen.start && (
          <div
            className="absolute inset-y-3 rounded bg-hex-400/70"
            style={{ left: pct(coldOpen.start), width: `max(3px, ${((coldOpen.end - coldOpen.start) / span) * 100}%)` }}
            title="Cold-open payoff"
          />
        )}
      </div>
      <div className="mt-1 flex justify-between font-mono text-[10px] text-zinc-600">
        <span>{fmtDuration(from)}</span>
        {coldOpen && <span className="text-hex-300/80">▮ cold-open payoff</span>}
        <span>{fmtDuration(to)}</span>
      </div>
    </div>
  );
}

function HashtagInput({ value, onChange }: { value: string[]; onChange: (v: string[]) => void }) {
  const [text, setText] = useState('');
  const add = (raw: string) => {
    const tags = raw
      .split(/[\s,]+/)
      .map((t) => t.trim().replace(/^#*/, ''))
      .filter(Boolean)
      .map((t) => `#${t}`);
    const next = [...value];
    for (const t of tags) if (!next.some((x) => x.toLowerCase() === t.toLowerCase())) next.push(t);
    onChange(next);
    setText('');
  };
  return (
    <div className="flex min-h-10 flex-wrap items-center gap-1.5 rounded-xl border border-white/[0.08] bg-ink-950/60 p-1.5 focus-within:border-goblin-400/60">
      {value.map((t) => (
        <motion.span
          layout
          key={t}
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="inline-flex items-center gap-1 rounded-lg bg-hex-500/15 py-1 pl-2 pr-1 text-[13px] font-medium text-hex-200"
        >
          {t}
          <button type="button" onClick={() => onChange(value.filter((x) => x !== t))} className="rounded p-0.5 text-hex-300/70 hover:bg-white/10 hover:text-white" aria-label={`Remove ${t}`}>
            <X className="h-3 w-3" />
          </button>
        </motion.span>
      ))}
      <input
        className="h-7 min-w-[120px] flex-1 bg-transparent px-1.5 text-sm text-white outline-none placeholder:text-zinc-600"
        placeholder={value.length ? 'Add more…' : '#fyp #gaming'}
        value={text}
        onChange={(e) => {
          const v = e.target.value;
          if (/[\s,]$/.test(v)) add(v);
          else setText(v);
        }}
        onKeyDown={(e) => {
          if (e.key === 'Enter') {
            e.preventDefault();
            if (text.trim()) add(text);
          } else if (e.key === 'Backspace' && !text && value.length) onChange(value.slice(0, -1));
        }}
        onBlur={() => text.trim() && add(text)}
        onPaste={(e) => {
          e.preventDefault();
          add(text + ' ' + e.clipboardData.getData('text'));
        }}
      />
    </div>
  );
}
