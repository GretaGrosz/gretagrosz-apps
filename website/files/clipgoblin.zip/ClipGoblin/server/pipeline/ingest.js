// Ingest: download URLs with yt-dlp (auto-installed standalone binary), probe, poster frame.
import fs from 'node:fs';
import path from 'node:path';
import { paths } from '../config.js';
import { run, ffmpegDir, probe, grabFrame } from './ffmpeg.js';
import { CanceledError } from './util.js';

const YTDLP_URL = 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos';
export const ytdlpPath = () => path.join(paths.bin, 'yt-dlp');
export const ytdlpInstalled = () => {
  try { return fs.statSync(ytdlpPath()).size > 1_000_000; } catch { return false; }
};

let installing = null;
export function ensureYtdlp(onStage) {
  if (ytdlpInstalled()) return Promise.resolve(ytdlpPath());
  installing ??= (async () => {
    onStage?.('Installing yt-dlp (one-time download)…');
    let res;
    try {
      res = await fetch(YTDLP_URL, { redirect: 'follow' });
    } catch (e) {
      const cause = e.cause?.code || e.cause?.message || e.message;
      throw new Error(`Could not download yt-dlp (${cause}). Check your internet connection, or download ${YTDLP_URL} manually to ${ytdlpPath()} and chmod +x it.`);
    }
    if (!res.ok) throw new Error(`Could not download yt-dlp: HTTP ${res.status}`);
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.length < 1_000_000) throw new Error('yt-dlp download looks truncated');
    const tmp = `${ytdlpPath()}.tmp`;
    fs.writeFileSync(tmp, buf, { mode: 0o755 });
    fs.renameSync(tmp, ytdlpPath());
    fs.chmodSync(ytdlpPath(), 0o755);
    return ytdlpPath();
  })().finally(() => { installing = null; });
  return installing;
}

const FORMAT = [
  'bv*[height<=1080][ext=mp4]+ba[ext=m4a]',
  'b[height<=1080][ext=mp4]',
  'bv*[height<=1080]+ba',
  'b[height<=1080]',
  'b',
].join('/');

/**
 * Download a VOD URL to paths.uploads/<jobId>.mp4.
 * onProgress(fraction 0..1, stageText). Returns {file, title}.
 */
export async function downloadUrl(jobId, url, { signal, onProgress } = {}) {
  const bin = await ensureYtdlp((s) => onProgress?.(0, s));
  if (signal?.aborted) throw new CanceledError();
  onProgress?.(0, 'Fetching video info…');
  let title = null;
  let durationSec = null;
  try {
    const { stdout } = await run(bin, ['-J', '--no-playlist', '--no-warnings', url], { signal });
    const info = JSON.parse(stdout);
    title = info.title || info.fulltitle || null;
    durationSec = info.duration || null;
  } catch (e) {
    if (e.canceled) throw e;
    const msg = String(e.stderr || e.message).split('\n').find((l) => /ERROR/.test(l)) || e.message;
    throw new Error(`Could not read that URL: ${msg.replace(/^.*ERROR:\s*/, '')}`);
  }

  // Remove any partial leftovers from a previous attempt with a different extension.
  for (const f of fs.readdirSync(paths.uploads)) {
    if (f.startsWith(`${jobId}.`) && !f.endsWith('.part')) fs.rmSync(path.join(paths.uploads, f), { force: true });
  }

  const outTmpl = path.join(paths.uploads, `${jobId}.%(ext)s`);
  let phase = 0; // yt-dlp downloads video then audio as separate passes
  let lastPct = 0;
  const args = [
    '--no-playlist', '--newline', '--no-warnings', '--no-mtime', '--continue',
    '-f', FORMAT, '-S', 'res:1080,ext:mp4:m4a',
    '--merge-output-format', 'mp4', '--remux-video', 'mp4',
    '--ffmpeg-location', ffmpegDir(),
    '--concurrent-fragments', '4',
    '--progress-template', 'download:[dl] %(progress._percent_str)s|%(progress._eta_str)s|%(progress._speed_str)s',
    '-o', outTmpl, url,
  ];
  await run(bin, args, {
    signal,
    onStdoutLine: (line) => {
      if (line.startsWith('[dl]')) {
        const [pctS, eta, speed] = line.slice(4).trim().split('|');
        const pct = parseFloat(pctS) || 0;
        if (pct + 20 < lastPct) phase++;
        lastPct = pct;
        const frac = phase === 0 ? pct / 100 * 0.9 : 0.9 + pct / 100 * 0.1;
        onProgress?.(Math.min(0.99, frac), `Downloading ${pct.toFixed(0)}%${eta && eta !== 'NA' ? ` · ${eta} left` : ''}${speed && speed !== 'NA' ? ` · ${speed.trim()}` : ''}`);
      } else if (/^\[(Merger|VideoRemuxer|FixupM3u8|ExtractAudio)\]/.test(line)) {
        onProgress?.(0.99, 'Merging video + audio…');
      }
    },
  }).catch((e) => {
    if (e.canceled) throw e;
    const errLine = String(e.stderr || '').split('\n').reverse().find((l) => /ERROR/.test(l));
    throw new Error(`Download failed: ${(errLine || e.message).replace(/^.*ERROR:\s*/, '').slice(0, 400)}`);
  });

  const file = fs.readdirSync(paths.uploads)
    .filter((f) => f.startsWith(`${jobId}.`) && !/\.(part|ytdl|temp)$/.test(f))
    .map((f) => path.join(paths.uploads, f))
    .sort((a, b) => fs.statSync(b).size - fs.statSync(a).size)[0];
  if (!file) throw new Error('Download finished but no video file was produced');
  return { file, title, durationSec };
}

/** Probe the source and grab a poster frame into paths.clips/<jobId>.jpg */
export async function probeAndPoster(jobId, file, { signal } = {}) {
  const info = await probe(file);
  if (!info.hasVideo) throw new Error('That file has no video stream');
  if (!info.durationSec) throw new Error('Could not read the video duration — the file may be corrupt or still downloading');
  const poster = path.join(paths.clips, `${jobId}.jpg`);
  try {
    await grabFrame(file, Math.min(info.durationSec * 0.1, 60), { width: 640, outFile: poster, signal });
  } catch (e) {
    if (e.canceled) throw e;
  }
  return { ...info, thumb: fs.existsSync(poster) ? `/media/clips/${jobId}.jpg?v=${Date.now()}` : null };
}
