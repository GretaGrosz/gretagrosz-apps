export type Platform = 'youtube' | 'tiktok' | 'instagram';
export const PLATFORMS: Platform[] = ['youtube', 'tiktok', 'instagram'];

export type Layout = 'auto' | 'facecam-split' | 'blur-fill' | 'center-crop';
export type CaptionStyle = 'beast' | 'karaoke' | 'minimal' | 'chaos';

export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface ClipStyle {
  layout: Layout;
  captionStyle: CaptionStyle;
  coldOpen: boolean;
  jumpCuts: boolean;
  progressBar: boolean;
  hookBanner: boolean;
  chaos: boolean;
}

export interface JobOptions extends ClipStyle {
  maxClips: number;
  minSec: number;
  maxSec: number;
  facecam: Rect | null;
}

export type JobStatus =
  | 'queued'
  | 'downloading'
  | 'probing'
  | 'transcribing'
  | 'analyzing'
  | 'rendering'
  | 'done'
  | 'error'
  | 'canceled';

export interface Job {
  id: string;
  createdAt: number;
  updatedAt: number;
  source: { type: 'file' | 'url'; name: string; url?: string };
  status: JobStatus;
  progress: number;
  stage: string;
  error: string | null;
  durationSec?: number;
  width?: number;
  height?: number;
  videoPath?: string;
  options: Partial<JobOptions>;
  clipIds: string[];
  thumb?: string | null;
  analyzer?: 'claude' | 'heuristic';
  autopilotScheduled?: boolean;
}

export type Category = 'funny' | 'rage' | 'wtf' | 'clutch' | 'wholesome' | 'cringe' | 'weird';

export interface ClipPublishState {
  status: PublicationStatus;
  url?: string | null;
  publicationId?: string;
}

export interface Clip {
  id: string;
  jobId: string;
  createdAt: number;
  updatedAt: number;
  rank: number;
  score: number;
  start: number;
  end: number;
  coldOpen: { start: number; end: number } | null;
  hook: string;
  title: string;
  description: string;
  hashtags: string[];
  category: Category | string;
  why: string;
  transcript?: string;
  status: 'pending' | 'rendering' | 'ready' | 'error';
  progress: number;
  error: string | null;
  file: string | null;
  thumb: string | null;
  durationSec?: number;
  style?: Partial<ClipStyle>;
  publish?: Partial<Record<Platform, ClipPublishState>>;
}

export type PublicationStatus = 'scheduled' | 'uploading' | 'processing' | 'published' | 'error' | 'canceled';

export interface Publication {
  id: string;
  clipId: string;
  jobId: string;
  platform: Platform;
  status: PublicationStatus;
  scheduledAt: number;
  publishedAt?: number | null;
  progress?: number;
  remoteId?: string | null;
  url?: string | null;
  error?: string | null;
  title?: string;
  caption?: string;
  createdAt?: number;
  updatedAt?: number;
}

export interface AccountState {
  configured: boolean;
  connected: boolean;
  name?: string | null;
  avatar?: string | null;
  note?: string | null;
  setup?: Array<string | { text?: string; title?: string; url?: string }>;
  redirectUri?: string;
  mode?: 'direct' | 'inbox';
  privacyOptions?: string[] | null;
}
export type Accounts = Partial<Record<Platform, AccountState>>;

export interface SystemInfo {
  ffmpeg: boolean;
  ytdlp: boolean;
  analyzer: 'claude' | 'heuristic';
  transcription: 'local' | 'groq' | 'openai' | string;
  localModelReady: boolean;
}

export interface Settings {
  anthropicApiKey: string;
  claudeModel: string;
  publicBaseUrl: string;
  transcription: {
    provider: 'local' | 'groq' | 'openai';
    localModel: string;
    groqApiKey: string;
    openaiApiKey: string;
  };
  defaults: JobOptions;
  autopilot: {
    enabled: boolean;
    platforms: Platform[];
    minScore: number;
    maxPerJob: number;
    spacingMinutes: number;
  };
  platforms: {
    youtube: { clientId: string; clientSecret: string; privacy: string };
    tiktok: { clientKey: string; clientSecret: string; privacy: string; mode?: 'direct' | 'inbox' };
    instagram: { appId: string; appSecret: string };
  };
}

export type SSEMessage =
  | { type: 'job'; data: Job }
  | { type: 'clip'; data: Clip }
  | { type: 'publication'; data: Publication }
  | { type: 'job:removed'; data: { id: string } | string }
  | { type: 'clip:removed'; data: { id: string } | string }
  | { type: 'publication:removed'; data: { id: string } | string }
  | { type: 'toast'; data: { message?: string; text?: string; level?: string; kind?: string; title?: string } | string };
