// TikTok: Login Kit OAuth v2 + Content Posting API (Direct Post or Inbox/draft), chunked FILE_UPLOAD.
import {
  PublishError, http, readBody, form, isTransientStatus, retryAfter, readChunk, openFile, sleep,
  pkceChallengeHex, isLocalhostUrl,
} from './util.js';

const AUTH_URL = 'https://www.tiktok.com/v2/auth/authorize/';
const API = 'https://open.tiktokapis.com/v2';
const SCOPES = 'user.info.basic,video.publish,video.upload';
const MB = 1024 * 1024;
const CHUNK = 10 * MB; // TikTok: chunks 5–64 MB, last chunk may be up to 128 MB

const cfg = (s) => s.platforms?.tiktok ?? {};
export const tiktokMode = (s) => (cfg(s).mode === 'inbox' ? 'inbox' : 'direct');

const UNAUDITED_MSG =
  'TikTok app not audited: it can only post privately (privacy "SELF_ONLY"), and TikTok may require your account itself to be set to Private. ' +
  'Set TikTok privacy to "Only me", or switch TikTok mode to Inbox in Settings to finish posting from the TikTok app.';

const ERRORS = {
  unaudited_client_can_only_post_to_private_accounts: UNAUDITED_MSG,
  privacy_level_option_mismatch: 'The TikTok privacy level in Settings is not allowed for this account. ' + UNAUDITED_MSG,
  spam_risk_too_many_posts: 'TikTok says this account reached its daily posting limit. Try again tomorrow.',
  spam_risk_too_many_pending_share: 'TikTok allows at most 5 pending inbox uploads per 24 h. Post or delete the drafts in the TikTok app first.',
  spam_risk_user_banned_from_posting: 'TikTok has blocked this account from posting.',
  reached_active_user_cap: 'This TikTok app reached its daily limit of posting users. Try again tomorrow.',
  access_token_invalid: 'TikTok access expired or was revoked. Reconnect TikTok in Settings.',
  scope_not_authorized: 'TikTok did not grant posting permission. Make sure Content Posting API (with Direct Post) is added to your app, then reconnect and allow all permissions.',
  url_ownership_unverified: 'TikTok requires a verified domain for URL uploads.',
};
const FAIL_REASONS = {
  file_format_check_failed: 'TikTok rejected the video format.',
  duration_check_failed: 'The clip is too long or too short for this TikTok account.',
  frame_rate_check_failed: 'TikTok rejected the video frame rate.',
  picture_size_check_failed: 'TikTok rejected the video resolution.',
  auth_removed: 'TikTok access was removed by the user. Reconnect TikTok.',
  spam_risk_too_many_posts: ERRORS.spam_risk_too_many_posts,
  spam_risk_user_banned_from_posting: ERRORS.spam_risk_user_banned_from_posting,
  spam_risk_text: 'TikTok flagged the caption as spam. Edit the caption and retry.',
  spam_risk: 'TikTok flagged this post as risky and did not publish it.',
  publish_cancelled: 'The TikTok post was canceled.',
};

function apiError(res, body, what) {
  const code = body?.error?.code;
  const msg = body?.error?.message || body?.error_description || body?._raw || `HTTP ${res.status}`;
  return new PublishError(ERRORS[code] ?? `TikTok ${what} failed: ${msg}${code && code !== 'ok' ? ` (${code})` : ''}`, {
    transient: isTransientStatus(res.status) || code === 'rate_limit_exceeded' || code === 'internal_error',
    status: res.status,
    code,
    retryAfterMs: retryAfter(res),
    reconnect: code === 'access_token_invalid' || (code === 'scope_not_authorized'),
  });
}

async function api(path, token, payload, what, signal) {
  const res = await http(`${API}${path}`, {
    label: 'TikTok',
    method: 'POST',
    signal,
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json; charset=UTF-8' },
    body: payload === undefined ? undefined : JSON.stringify(payload),
  });
  const body = await readBody(res);
  if (!res.ok || (body?.error?.code && body.error.code !== 'ok')) throw apiError(res, body, what);
  return body.data ?? {};
}

async function tokenRequest(params) {
  const res = await http(`${API}/oauth/token/`, {
    label: 'TikTok',
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Cache-Control': 'no-cache' },
    body: form(params),
  });
  const body = await readBody(res);
  if (!res.ok || body.error) {
    const desc = body.error_description || body.error?.message || body.error || `HTTP ${res.status}`;
    throw new PublishError(`TikTok sign-in failed: ${desc}`, {
      transient: isTransientStatus(res.status),
      status: res.status,
      reconnect: body.error === 'invalid_grant' || /refresh_token/i.test(String(desc)),
    });
  }
  return body;
}

const toRecord = (t, prev = {}) => ({
  access_token: t.access_token,
  refresh_token: t.refresh_token || prev.refresh_token,
  expires_at: Date.now() + (t.expires_in ?? 86400) * 1000,
  refresh_expires_at: t.refresh_expires_in ? Date.now() + t.refresh_expires_in * 1000 : prev.refresh_expires_at,
  open_id: t.open_id || prev.open_id,
  scope: t.scope || prev.scope,
});

// TikTok chunk rules: <5 MB → single chunk; otherwise chunk_size in [5,64] MB, count = floor(size/chunk),
// remainder folded into the last chunk.
export function planChunks(size) {
  const chunkSize = size < 2 * CHUNK ? size : CHUNK;
  const count = Math.max(1, Math.floor(size / chunkSize));
  const chunks = [];
  for (let i = 0; i < count; i++) {
    const start = i * chunkSize;
    const end = i === count - 1 ? size : start + chunkSize;
    chunks.push({ start, end });
  }
  return { chunkSize, count, chunks };
}

export default {
  id: 'tiktok',
  label: 'TikTok',

  isConfigured: (s) => Boolean(cfg(s).clientKey && cfg(s).clientSecret),

  // Desktop-type apps (http://localhost redirect) must use PKCE with a hex SHA-256 challenge.
  usesPkce: (redirectUri) => isLocalhostUrl(redirectUri),

  authorizeUrl({ settings, redirectUri, state, verifier }) {
    const u = new URL(AUTH_URL);
    const p = form({
      client_key: cfg(settings).clientKey,
      response_type: 'code',
      scope: SCOPES,
      redirect_uri: redirectUri,
      state,
    });
    if (this.usesPkce(redirectUri)) {
      p.set('code_challenge', pkceChallengeHex(verifier));
      p.set('code_challenge_method', 'S256');
    }
    u.search = p.toString();
    return u.toString();
  },

  async exchangeCode({ settings, code, redirectUri, verifier }) {
    const t = await tokenRequest({
      client_key: cfg(settings).clientKey,
      client_secret: cfg(settings).clientSecret,
      code,
      grant_type: 'authorization_code',
      redirect_uri: redirectUri,
      code_verifier: this.usesPkce(redirectUri) ? verifier : undefined,
    });
    return toRecord(t);
  },

  needsRefresh: (rec) => !rec.expires_at || rec.expires_at - Date.now() < 10 * 60 * 1000,

  async refresh(rec, settings) {
    if (!rec.refresh_token) throw new PublishError('TikTok connection has no refresh token. Reconnect TikTok.', { reconnect: true });
    if (rec.refresh_expires_at && rec.refresh_expires_at < Date.now()) {
      throw new PublishError('TikTok connection expired. Reconnect TikTok in Settings.', { reconnect: true });
    }
    const t = await tokenRequest({
      client_key: cfg(settings).clientKey,
      client_secret: cfg(settings).clientSecret,
      grant_type: 'refresh_token',
      refresh_token: rec.refresh_token,
    });
    return toRecord(t, rec);
  },

  async fetchProfile(rec, settings) {
    const res = await http(`${API}/user/info/?fields=open_id,avatar_url,display_name`, {
      label: 'TikTok',
      headers: { Authorization: `Bearer ${rec.access_token}` },
    });
    const body = await readBody(res);
    if (!res.ok || (body?.error?.code && body.error.code !== 'ok')) throw apiError(res, body, 'profile lookup');
    const u = body.data?.user ?? {};
    const profile = { id: u.open_id ?? rec.open_id, name: u.display_name ?? null, avatar: u.avatar_url ?? null };
    if (tiktokMode(settings) === 'direct') {
      // Creator info tells us the username and which privacy levels this account allows.
      try {
        const c = await api('/post/publish/creator_info/query/', rec.access_token, undefined, 'creator info');
        profile.username = c.creator_username ?? null;
        profile.name = c.creator_nickname || profile.name;
        profile.avatar = c.creator_avatar_url || profile.avatar;
        profile.privacyOptions = c.privacy_level_options ?? [];
        profile.maxDurationSec = c.max_video_post_duration_sec ?? null;
      } catch { /* scope may be missing in inbox-only apps */ }
    }
    return profile;
  },

  async revoke(rec, settings) {
    await http(`${API}/oauth/revoke/`, {
      label: 'TikTok',
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: form({ client_key: cfg(settings).clientKey, client_secret: cfg(settings).clientSecret, token: rec.access_token }),
    }).catch(() => {});
  },

  note(settings, rec) {
    const mode = tiktokMode(settings);
    const notes = [];
    if (mode === 'inbox') {
      notes.push('Inbox mode: videos are sent to your TikTok inbox as drafts. Open TikTok, tap the notification and post it yourself. TikTok allows at most 5 pending drafts per 24 h.');
    } else {
      notes.push('Direct Post mode. Until TikTok audits your app, every post is private ("Only me") and TikTok may require your account to be set to Private. Use Inbox mode to post publicly from the TikTok app without an audit.');
      const opts = rec?.profile?.privacyOptions;
      if (opts?.length) notes.push(`Privacy levels this account allows: ${opts.join(', ')}.`);
      const want = cfg(settings).privacy || 'SELF_ONLY';
      if (opts?.length && !opts.includes(want)) notes.push(`Your TikTok privacy setting "${want}" is not allowed and posts will fail. Pick one of the allowed values.`);
    }
    return notes.join(' ');
  },

  setup(redirectUri) {
    return [
      'Go to developers.tiktok.com → log in → Manage apps → Connect an app (an individual developer account is fine).',
      'Fill in the app basics: icon, name, category, description, Terms of Service URL and Privacy Policy URL.',
      'Under Platforms, choose "Desktop". It is the type that accepts an http://localhost redirect, and it uses PKCE, which ClipGoblin handles.',
      'Add products: "Login Kit" and "Content Posting API". In Content Posting API, turn on "Direct Post".',
      'Scopes: user.info.basic, video.upload, video.publish.',
      `Login Kit → Redirect URI: add exactly ${redirectUri}`,
      'To test before review: open the Sandbox tab, create a sandbox, and add your TikTok account under Target Users. Use the sandbox Client key and secret.',
      'Paste the Client key and Client secret into ClipGoblin Settings → TikTok and click Connect.',
      'Until your app passes TikTok\'s audit (submit it for review), Direct Post can only post privately ("Only me"). Inbox mode sends drafts that you publish publicly from the TikTok app.',
    ];
  },

  async publish({ token, filePath, size, meta, settings, clip, onProgress, onStatus, onRemote, signal, pollMs = 5000, pollTimeoutMs = 30 * 60 * 1000 }) {
    const at = token.access_token;
    const mode = tiktokMode(settings);
    const plan = planChunks(size);
    if (plan.count > 1000) throw new PublishError('Video is too large for TikTok (max 4 GB).');
    const source_info = { source: 'FILE_UPLOAD', video_size: size, chunk_size: plan.chunkSize, total_chunk_count: plan.count };

    let init;
    let username = token.profile?.username ?? null;
    if (mode === 'direct') {
      const creator = await api('/post/publish/creator_info/query/', at, undefined, 'creator info', signal);
      username = creator.creator_username ?? username;
      const options = creator.privacy_level_options ?? [];
      const privacy = cfg(settings).privacy || 'SELF_ONLY';
      if (options.length && !options.includes(privacy)) {
        throw new PublishError(
          `TikTok privacy "${privacy}" is not allowed for this account (allowed: ${options.join(', ')}). ` +
            (privacy !== 'SELF_ONLY' ? UNAUDITED_MSG : 'Change the TikTok privacy level in Settings.'),
          { code: 'privacy_level_option_mismatch' },
        );
      }
      const max = creator.max_video_post_duration_sec;
      if (max && clip?.durationSec && clip.durationSec > max) {
        throw new PublishError(`This clip is ${Math.round(clip.durationSec)} s but this TikTok account allows at most ${max} s.`);
      }
      init = await api('/post/publish/video/init/', at, {
        post_info: {
          title: meta.caption,
          privacy_level: privacy,
          disable_duet: Boolean(creator.duet_disabled),
          disable_stitch: Boolean(creator.stitch_disabled),
          disable_comment: Boolean(creator.comment_disabled),
          video_cover_timestamp_ms: 1000,
        },
        source_info,
      }, 'post init', signal);
    } else {
      init = await api('/post/publish/inbox/video/init/', at, { source_info }, 'inbox upload init', signal);
    }
    const publishId = init.publish_id;
    if (!publishId || !init.upload_url) throw new PublishError('TikTok did not return an upload URL.', { transient: true });
    onRemote?.(publishId);

    // Upload chunks in order; 206 = more please, 201 = complete.
    const fd = await openFile(filePath);
    try {
      for (const { start, end } of plan.chunks) {
        const body = await readChunk(fd, start, end - start);
        for (let attempt = 1; ; attempt++) {
          let r;
          try {
            r = await http(init.upload_url, {
              label: 'TikTok',
              method: 'PUT',
              signal,
              headers: {
                'Content-Type': 'video/mp4',
                'Content-Length': String(body.length),
                'Content-Range': `bytes ${start}-${end - 1}/${size}`,
              },
              body,
            });
          } catch (err) {
            if (err instanceof PublishError && err.transient && attempt < 4) { await sleep(1000 * 2 ** attempt, signal); continue; }
            throw err;
          }
          await r.body?.cancel?.();
          if (r.status === 201 || r.status === 206 || r.ok) break;
          if (isTransientStatus(r.status) && attempt < 4) { await sleep(1000 * 2 ** attempt, signal); continue; }
          if (r.status === 403 || r.status === 404) {
            throw new PublishError('TikTok upload URL expired. Will start over.', { transient: true, status: r.status });
          }
          throw new PublishError(`TikTok rejected an upload chunk (HTTP ${r.status}).`, { transient: isTransientStatus(r.status), status: r.status });
        }
        onProgress(end / size);
      }
    } finally {
      await fd.close();
    }

    // Poll until TikTok finishes processing (or drops it into the inbox).
    onStatus('processing');
    const deadline = Date.now() + pollTimeoutMs;
    while (Date.now() < deadline) {
      await sleep(pollMs, signal);
      let st;
      try {
        st = await api('/post/publish/status/fetch/', at, { publish_id: publishId }, 'status check', signal);
      } catch (err) {
        if (err instanceof PublishError && err.transient) continue; // keep polling through 429/5xx
        throw err;
      }
      if (st.status === 'FAILED') {
        const reason = st.fail_reason;
        throw new PublishError(FAIL_REASONS[reason] ?? `TikTok could not publish the video (${reason || 'unknown reason'}).`, {
          transient: reason === 'internal',
          code: reason,
        });
      }
      if (mode === 'inbox' && (st.status === 'SEND_TO_USER_INBOX' || st.status === 'PUBLISH_COMPLETE')) {
        return {
          remoteId: publishId,
          url: null,
          delivery: 'inbox',
          note: 'Sent to your TikTok inbox. Open the TikTok app, tap the notification and post it.',
        };
      }
      if (st.status === 'PUBLISH_COMPLETE') {
        const postId = st.publicaly_available_post_id?.[0];
        const url = postId && username
          ? `https://www.tiktok.com/@${username}/video/${postId}`
          : username ? `https://www.tiktok.com/@${username}` : null;
        const privacy = cfg(settings).privacy || 'SELF_ONLY';
        return {
          remoteId: postId ? String(postId) : publishId,
          url,
          delivery: 'direct',
          note: privacy === 'SELF_ONLY' ? 'Posted to TikTok as private ("Only me"). Change visibility in the TikTok app.' : undefined,
        };
      }
    }
    throw new PublishError('TikTok accepted the upload but is still processing after 30 minutes. Check your TikTok profile before retrying.');
  },
};
