import clsx from 'clsx';
import { motion } from 'framer-motion';
import { Scissors, Sparkles, Timer, Wand2, Zap, Activity, Megaphone, Flame } from 'lucide-react';
import type { ReactNode } from 'react';
import { CAPTION_STYLES, LAYOUTS, STYLE_TOGGLES } from '../lib/meta';
import type { CaptionStyle, JobOptions, Layout } from '../lib/types';
import { NumberStepper, Switch } from './ui';

/* ───────────── Layout diagrams ───────────── */

export function LayoutDiagram({ layout, active }: { layout: Layout; active?: boolean }) {
  const a = active ? '#c6ff3d' : '#71717a';
  const dim = active ? 'rgba(198,255,61,.16)' : 'rgba(255,255,255,.06)';
  const frame = (
    <rect x="0.75" y="0.75" width="25.5" height="44.5" rx="4" fill="#0b0b11" stroke={active ? '#c6ff3d' : '#3b3b4f'} strokeWidth="1.5" />
  );
  return (
    <svg viewBox="0 0 27 46" className="h-[54px] w-[32px]" aria-hidden>
      {frame}
      {layout === 'facecam-split' && (
        <>
          <rect x="3" y="3" width="21" height="14" rx="2" fill={dim} />
          <circle cx="13.5" cy="8.6" r="2.6" fill={a} />
          <path d="M8.5 16.5 q5 -6 10 0" fill={a} />
          <rect x="3" y="19" width="21" height="24" rx="2" fill={dim} />
          <path d="M5 38 l5 -7 l3.5 4 l3 -3 l5 6 z" fill={a} opacity=".85" />
          <circle cx="19" cy="25" r="1.6" fill={a} />
        </>
      )}
      {layout === 'blur-fill' && (
        <>
          <rect x="3" y="3" width="21" height="40" rx="2" fill={dim} opacity=".6" />
          <rect x="3" y="3" width="21" height="12" rx="2" fill={a} opacity=".12" />
          <rect x="3" y="31" width="21" height="12" rx="2" fill={a} opacity=".12" />
          <rect x="2" y="16.5" width="23" height="13" rx="1.5" fill="#0b0b11" stroke={a} strokeWidth="1" />
          <path d="M5 27.5 l4.5 -5 l3 3 l3 -3 l5.5 5 z" fill={a} opacity=".85" />
        </>
      )}
      {layout === 'center-crop' && (
        <>
          <rect x="3" y="3" width="21" height="40" rx="2" fill={dim} />
          <circle cx="13.5" cy="18" r="4" fill={a} />
          <path d="M5.5 35 q8 -14 16 0" fill={a} />
          <path d="M3 9 h3 M3 9 v-3 M24 9 h-3 M24 9 v-3 M3 37 h3 M3 37 v3 M24 37 h-3 M24 37 v3" stroke={a} strokeWidth="1" />
        </>
      )}
      {layout === 'auto' && (
        <>
          <rect x="3" y="3" width="21" height="40" rx="2" fill={dim} />
          <path d="M3 17 h21" stroke={a} strokeDasharray="1.5 1.5" strokeWidth="0.8" />
          <path
            d="M13.5 22 l1.4 3.4 l3.4 1.4 l-3.4 1.4 l-1.4 3.4 l-1.4 -3.4 l-3.4 -1.4 l3.4 -1.4 z"
            fill={a}
          />
          <path d="M19 33 l.6 1.4 l1.4 .6 l-1.4 .6 l-.6 1.4 l-.6 -1.4 l-1.4 -.6 l1.4 -.6 z" fill={a} opacity=".7" />
          <path d="M8 10 l.5 1.1 l1.1 .5 l-1.1 .5 l-.5 1.1 l-.5 -1.1 l-1.1 -.5 l1.1 -.5 z" fill={a} opacity=".7" />
        </>
      )}
    </svg>
  );
}

export function LayoutPicker({ value, onChange, compact }: { value: Layout; onChange: (v: Layout) => void; compact?: boolean }) {
  return (
    <div className={clsx('grid gap-2', compact ? 'grid-cols-2 sm:grid-cols-4' : 'grid-cols-2 sm:grid-cols-4')}>
      {LAYOUTS.map((l) => {
        const active = value === l.id;
        return (
          <button
            key={l.id}
            type="button"
            onClick={() => onChange(l.id)}
            className={clsx(
              'group relative flex items-center gap-3 rounded-xl border p-2.5 text-left transition-all',
              active
                ? 'border-goblin-400/60 bg-goblin-400/[0.06] shadow-[0_0_24px_-10px_rgba(198,255,61,.6)]'
                : 'border-white/[0.07] bg-ink-950/40 hover:border-white/15 hover:bg-white/[0.03]',
            )}
          >
            <LayoutDiagram layout={l.id} active={active} />
            <div className="min-w-0">
              <div className={clsx('text-[13px] font-semibold leading-tight', active ? 'text-white' : 'text-zinc-300')}>{l.label}</div>
              <div className="mt-0.5 text-[11px] leading-snug text-zinc-500">{l.hint}</div>
            </div>
          </button>
        );
      })}
    </div>
  );
}

/* ───────────── Caption previews ───────────── */

function CaptionSample({ style }: { style: CaptionStyle }) {
  if (style === 'beast')
    return (
      <div className="text-center font-display text-[15px] font-extrabold uppercase leading-[0.95] tracking-tight text-white [-webkit-text-stroke:0.6px_#000] [text-shadow:0_2px_0_#000]">
        no <span className="text-[#ffe500]">way</span>
        <br />
        bro
      </div>
    );
  if (style === 'karaoke')
    return (
      <div className="text-center text-[10px] font-bold leading-tight text-white [text-shadow:0_1px_2px_#000]">
        he did <span className="rounded bg-goblin-400 px-0.5 text-ink-950">NOT</span> see
      </div>
    );
  if (style === 'minimal')
    return <div className="text-center text-[8.5px] font-medium leading-tight text-white/90">he did not see that coming</div>;
  return (
    <div className="text-center font-display text-[13px] font-extrabold uppercase leading-[0.95]">
      <span className="inline-block -rotate-6 text-[#ff4fd8] [text-shadow:0_2px_0_#000]">WHAT</span>
      <br />
      <span className="inline-block rotate-3 text-goblin-400 [text-shadow:0_2px_0_#000]">💀 IS</span>
    </div>
  );
}

export function CaptionPicker({ value, onChange }: { value: CaptionStyle; onChange: (v: CaptionStyle) => void }) {
  return (
    <div className="grid grid-cols-4 gap-2">
      {CAPTION_STYLES.map((c) => {
        const active = value === c.id;
        return (
          <button
            key={c.id}
            type="button"
            onClick={() => onChange(c.id)}
            className={clsx(
              'group flex flex-col items-center gap-2 rounded-xl border p-2 transition-all',
              active ? 'border-goblin-400/60 bg-goblin-400/[0.06]' : 'border-white/[0.07] bg-ink-950/40 hover:border-white/15',
            )}
          >
            <div
              className="relative grid aspect-[9/12] w-full max-w-[86px] place-items-center overflow-hidden rounded-lg px-1 ring-1 ring-white/5"
              style={{
                background:
                  'radial-gradient(circle at 25% 15%, rgba(139,92,246,.55), transparent 60%), radial-gradient(circle at 85% 95%, rgba(198,255,61,.28), transparent 55%), #12121b',
              }}
            >
              <div className="absolute inset-0 bg-[linear-gradient(transparent_55%,rgba(0,0,0,.5))]" />
              <div className={clsx('relative transition-transform duration-300', active && 'scale-110', 'group-hover:scale-110')}>
                <CaptionSample style={c.id} />
              </div>
            </div>
            <div className="text-center">
              <div className={clsx('text-[12px] font-semibold', active ? 'text-white' : 'text-zinc-300')}>{c.label}</div>
              <div className="hidden text-[10.5px] leading-tight text-zinc-500 sm:block">{c.hint}</div>
            </div>
          </button>
        );
      })}
    </div>
  );
}

/* ───────────── Toggles ───────────── */

const TOGGLE_ICON: Record<string, ReactNode> = {
  coldOpen: <Zap className="h-4 w-4" />,
  jumpCuts: <Scissors className="h-4 w-4" />,
  progressBar: <Activity className="h-4 w-4" />,
  hookBanner: <Megaphone className="h-4 w-4" />,
  chaos: <Flame className="h-4 w-4" />,
};

export function StyleToggles({
  value,
  onChange,
}: {
  value: Partial<Record<(typeof STYLE_TOGGLES)[number]['key'], boolean>>;
  onChange: (key: (typeof STYLE_TOGGLES)[number]['key'], v: boolean) => void;
}) {
  return (
    <div className="grid gap-2 sm:grid-cols-2">
      {STYLE_TOGGLES.map((t) => {
        const on = !!value[t.key];
        return (
          <div
            key={t.key}
            role="button"
            tabIndex={0}
            onClick={() => onChange(t.key, !on)}
            onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), onChange(t.key, !on))}
            className={clsx(
              'flex cursor-pointer items-center gap-3 rounded-xl border px-3 py-2.5 transition-all',
              on ? 'border-goblin-400/25 bg-goblin-400/[0.04]' : 'border-white/[0.06] bg-ink-950/30 hover:border-white/[0.12]',
              t.key === 'chaos' && on && 'border-fuchsia-400/40 bg-fuchsia-500/[0.06]',
            )}
          >
            <div
              className={clsx(
                'grid h-8 w-8 shrink-0 place-items-center rounded-lg transition-colors',
                on ? (t.key === 'chaos' ? 'bg-fuchsia-500/20 text-fuchsia-300' : 'bg-goblin-400/15 text-goblin-300') : 'bg-white/5 text-zinc-500',
              )}
            >
              {TOGGLE_ICON[t.key]}
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-[13px] font-semibold text-zinc-100">{t.label}</div>
              <div className="truncate text-[11.5px] text-zinc-500">{t.hint}</div>
            </div>
            <Switch size="sm" checked={on} onChange={(v) => onChange(t.key, v)} label={t.label} />
          </div>
        );
      })}
    </div>
  );
}

/* ───────────── Full clip-settings form (job form + settings defaults) ───────────── */

export function ClipSettingsForm({
  value,
  onChange,
  showCounts = true,
}: {
  value: Partial<JobOptions>;
  onChange: (patch: Partial<JobOptions>) => void;
  showCounts?: boolean;
}) {
  return (
    <div className="space-y-6">
      {showCounts && (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <div>
            <span className="label flex items-center gap-1.5">
              <Sparkles className="h-3 w-3" /> Clips
            </span>
            <NumberStepper value={value.maxClips ?? 8} min={1} max={30} onChange={(v) => onChange({ maxClips: v })} />
          </div>
          <div>
            <span className="label flex items-center gap-1.5">
              <Timer className="h-3 w-3" /> Min length
            </span>
            <NumberStepper
              value={value.minSec ?? 15}
              min={5}
              max={Math.max(5, (value.maxSec ?? 59) - 1)}
              suffix="s"
              onChange={(v) => onChange({ minSec: v })}
            />
          </div>
          <div>
            <span className="label flex items-center gap-1.5">
              <Timer className="h-3 w-3" /> Max length
            </span>
            <NumberStepper
              value={value.maxSec ?? 59}
              min={(value.minSec ?? 15) + 1}
              max={180}
              suffix="s"
              onChange={(v) => onChange({ maxSec: v })}
            />
          </div>
        </div>
      )}
      <div>
        <span className="label flex items-center gap-1.5">
          <Wand2 className="h-3 w-3" /> Layout
        </span>
        <LayoutPicker value={(value.layout as Layout) ?? 'auto'} onChange={(layout) => onChange({ layout })} />
      </div>
      <div>
        <span className="label">Captions</span>
        <CaptionPicker value={(value.captionStyle as CaptionStyle) ?? 'beast'} onChange={(captionStyle) => onChange({ captionStyle })} />
      </div>
      <div>
        <span className="label">Retention tricks</span>
        <StyleToggles value={value} onChange={(k, v) => onChange({ [k]: v })} />
      </div>
    </div>
  );
}

export function ChaosSparkles() {
  return (
    <motion.span
      className="inline-block"
      animate={{ rotate: [0, -12, 10, 0] }}
      transition={{ repeat: Infinity, duration: 2.4, ease: 'easeInOut' }}
    >
      ✨
    </motion.span>
  );
}
