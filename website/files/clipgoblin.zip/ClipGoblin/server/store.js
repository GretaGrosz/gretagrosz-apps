// Tiny JSON-file document store. Collections: jobs, clips, publications.
// Every write is persisted (debounced) and broadcast to the browser over SSE.
import fs from 'node:fs';
import { nanoid } from 'nanoid';
import { paths, writeJsonAtomic } from './config.js';
import { emit } from './events.js';

const COLLECTIONS = ['jobs', 'clips', 'publications'];
const TYPE = { jobs: 'job', clips: 'clip', publications: 'publication' };

let db;
try { db = JSON.parse(fs.readFileSync(paths.db, 'utf8')); } catch { db = {}; }
for (const c of COLLECTIONS) db[c] ??= {};

let saveTimer = null;
function persist() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => writeJsonAtomic(paths.db, db), 150);
}
export function flush() {
  clearTimeout(saveTimer);
  writeJsonAtomic(paths.db, db);
}

function coll(name) {
  if (!db[name]) throw new Error(`unknown collection ${name}`);
  return db[name];
}

export const store = {
  newId: (prefix) => `${prefix}_${nanoid(10)}`,

  get(name, id) {
    return coll(name)[id] ?? null;
  },

  // Newest first. Optional filter function.
  list(name, filter) {
    const all = Object.values(coll(name));
    return (filter ? all.filter(filter) : all).sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0));
  },

  insert(name, doc) {
    const now = Date.now();
    const full = { createdAt: now, updatedAt: now, ...doc };
    coll(name)[full.id] = full;
    persist();
    emit({ type: TYPE[name], data: full });
    return full;
  },

  // Shallow-merges patch into the document and broadcasts it.
  update(name, id, patch) {
    const cur = coll(name)[id];
    if (!cur) return null;
    const next = { ...cur, ...patch, updatedAt: Date.now() };
    coll(name)[id] = next;
    persist();
    emit({ type: TYPE[name], data: next });
    return next;
  },

  remove(name, id) {
    const cur = coll(name)[id];
    if (!cur) return false;
    delete coll(name)[id];
    persist();
    emit({ type: `${TYPE[name]}:removed`, data: { id } });
    return true;
  },
};
