import fs from 'node:fs';
import path from 'node:path';
import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';

const API = process.env.CLIPGOBLIN_API || 'http://localhost:4777';

/** Dev-only: serves the placeholder media used by the mock API (VITE_MOCK=1). */
function mockMedia(): Plugin {
  const dir = path.resolve(__dirname, 'src/mocks/media');
  const types: Record<string, string> = { '.mp4': 'video/mp4', '.jpg': 'image/jpeg' };
  return {
    name: 'clipgoblin-mock-media',
    apply: 'serve',
    configureServer(server) {
      server.middlewares.use('/__mock-media', (req, res, next) => {
        const file = path.join(dir, path.basename((req.url || '').split('?')[0]));
        if (!fs.existsSync(file)) return next();
        const stat = fs.statSync(file);
        const type = types[path.extname(file)] || 'application/octet-stream';
        const range = req.headers.range;
        if (range) {
          const [s, e] = range.replace('bytes=', '').split('-');
          const start = Number(s);
          const end = e ? Number(e) : stat.size - 1;
          res.writeHead(206, {
            'Content-Type': type,
            'Content-Range': `bytes ${start}-${end}/${stat.size}`,
            'Accept-Ranges': 'bytes',
            'Content-Length': end - start + 1,
          });
          fs.createReadStream(file, { start, end }).pipe(res);
        } else {
          res.writeHead(200, { 'Content-Type': type, 'Content-Length': stat.size, 'Accept-Ranges': 'bytes' });
          fs.createReadStream(file).pipe(res);
        }
      });
    },
  };
}

export default defineConfig({
  plugins: [react(), mockMedia()],
  server: {
    host: true, // reachable from a phone on the same Wi-Fi
    port: 5173,
    proxy: {
      '/api': { target: API, changeOrigin: true },
      '/media': { target: API, changeOrigin: true },
    },
  },
  build: { outDir: 'dist', emptyOutDir: true, chunkSizeWarningLimit: 900 },
});
