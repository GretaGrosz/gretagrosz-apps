import clsx from 'clsx';
import { motion } from 'framer-motion';
import { AlertTriangle, Check, Clock, Maximize2, Volume2, VolumeX, Lightbulb } from 'lucide-react';
import { useRef, useState } from 'react';
import { fmtDuration } from '../lib/format';
import { categoryMeta, PLATFORM_META, PUB_STATUS } from '../lib/meta';
import type { Clip, Platform } from '../lib/types';
import { PLATFORMS } from '../lib/types';
import { PlatformIcon } from './Brand';
import { Thumb } from './JobCard';
import { ScoreRing } from './ScoreRing';
import { ProgressBar } from './ui';

export function PublishStatusIcons({ clip, size = 'sm' }: { clip: Clip; size?: 'sm' | 'md' }) {
  const entries = PLATFORMS.map((p) => [p, clip.publish?.[p]] as const).filter(([, v]) => !!v);
  if (!entries.length) return <span className="text-[11px] text-zinc-600">Not posted yet</span>;
  return (
    <div className="flex items-center gap-1.5">
      {entries.map(([p, st]) => {
        const meta = PUB_STATUS[st!.status] ?? PUB_STATUS.scheduled;
        const inner = (
          <span
            className={clsx(
              'relative grid place-items-center rounded-lg border border-white/[0.08] bg-white/[0.04]',
              size === 'sm' ? 'h-7 w-7' : 'h-8 w-8',
              st!.status === 'canceled' && 'opacity-40',
            )}
            title={`${PLATFORM_META[p as Platform].short}: ${meta.label}`}
          >
            <PlatformIcon platform={p} className="h-3.5 w-3.5" />
            <span className={clsx('absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full ring-2 ring-ink-850', meta.dot)} />
          </span>
        );
        return st!.url && st!.status === 'published' ? (
          <a key={p} href={st!.url} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()} className="transition hover:scale-110">
            {inner}
          </a>
        ) : (
          <span key={p}>{inner}</span>
        );
      })}
    </div>
  );
}

export function ClipCard({
  clip,
  selected,
  onToggleSelect,
  onOpen,
  index = 0,
}: {
  clip: Clip;
  selected?: boolean;
  onToggleSelect?: () => void;
  onOpen: () => void;
  index?: number;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(true);
  const [progress, setProgress] = useState(0);
  const cat = categoryMeta(clip.category);
  const ready = clip.status === 'ready' && !!clip.file;
  const rendering = clip.status === 'pending' || clip.status === 'rendering';
  const dur = clip.durationSec ?? clip.end - clip.start;

  const play = (withSound: boolean) => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = !withSound;
    setMuted(!withSound);
    void v.play().then(() => setPlaying(true)).catch(() => {});
  };
  const stop = () => {
    const v = videoRef.current;
    if (!v) return;
    v.pause();
    v.currentTime = 0;
    v.muted = true;
    setMuted(true);
    setPlaying(false);
    setProgress(0);
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 16, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ delay: Math.min(index * 0.05, 0.4), type: 'spring', stiffness: 260, damping: 28 }}
      className={clsx(
        'group relative flex flex-col overflow-hidden rounded-2xl border bg-ink-850/90 shadow-card transition-[border-color,box-shadow] duration-300',
        selected
          ? 'border-goblin-400/70 shadow-[0_0_0_1px_rgba(198,255,61,.4),0_20px_60px_-25px_rgba(198,255,61,.45)]'
          : 'border-white/[0.07] hover:border-white/15',
      )}
    >
      {/* media */}
      <div
        className="relative aspect-[9/16] w-full cursor-pointer overflow-hidden bg-ink-950"
        onMouseEnter={() => ready && window.matchMedia('(hover: hover)').matches && play(false)}
        onMouseLeave={() => ready && stop()}
        onClick={() => {
          if (!ready) return onOpen();
          if (!playing) return play(true);
          const v = videoRef.current!;
          v.muted = !v.muted;
          setMuted(v.muted);
        }}
      >
        <Thumb src={clip.thumb} className="!absolute inset-0" />
        {ready && (
          <video
            ref={videoRef}
            src={clip.file!}
            poster={clip.thumb ?? undefined}
            className={clsx('absolute inset-0 h-full w-full object-cover transition-opacity duration-300', playing ? 'opacity-100' : 'opacity-0')}
            muted
            loop
            playsInline
            preload="none"
            onTimeUpdate={(e) => {
              const v = e.currentTarget;
              if (v.duration) setProgress(v.currentTime / v.duration);
            }}
          />
        )}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/70" />

        {/* top row */}
        <div className="absolute inset-x-0 top-0 flex items-start justify-between p-2.5">
          <ScoreRing score={clip.score} size={42} />
          {onToggleSelect && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggleSelect();
              }}
              aria-label={selected ? 'Deselect clip' : 'Select clip'}
              className={clsx(
                'grid h-7 w-7 place-items-center rounded-lg border-2 backdrop-blur-md transition-all',
                selected
                  ? 'scale-100 border-goblin-400 bg-goblin-400 text-ink-950'
                  : 'border-white/50 bg-black/30 text-transparent hover:border-white sm:opacity-0 sm:group-hover:opacity-100',
              )}
            >
              <Check className="h-4 w-4" strokeWidth={3} />
            </button>
          )}
        </div>

        {/* rank */}
        <div className="absolute left-2.5 top-[60px] rounded-md bg-black/50 px-1.5 py-0.5 font-display text-[11px] font-bold text-white/80 backdrop-blur">
          #{clip.rank}
        </div>

        {/* bottom row */}
        <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-2 p-2.5">
          <span className={clsx('chip backdrop-blur-md', cat.cls)}>
            <span>{cat.emoji}</span>
            {cat.label}
          </span>
          <div className="flex items-center gap-1.5">
            {ready && playing && (
              <span className="grid h-6 w-6 place-items-center rounded-md bg-black/60 text-white backdrop-blur">
                {muted ? <VolumeX className="h-3.5 w-3.5" /> : <Volume2 className="h-3.5 w-3.5 text-goblin-300" />}
              </span>
            )}
            <span className="rounded-md bg-black/60 px-1.5 py-0.5 font-mono text-[11px] text-white backdrop-blur">{fmtDuration(dur)}</span>
          </div>
        </div>

        {/* expand */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            stop();
            onOpen();
          }}
          className="absolute right-2.5 top-[52px] grid h-7 w-7 place-items-center rounded-lg bg-black/50 text-white/90 opacity-100 backdrop-blur transition hover:bg-black/70 sm:opacity-0 sm:group-hover:opacity-100"
          aria-label="Open editor"
        >
          <Maximize2 className="h-3.5 w-3.5" />
        </button>

        {ready && playing && (
          <div className="absolute inset-x-0 bottom-0 h-0.5 bg-white/10">
            <div className="h-full bg-goblin-400" style={{ width: `${progress * 100}%` }} />
          </div>
        )}

        {rendering && (
          <div className="absolute inset-0 grid place-items-center bg-ink-950/60 backdrop-blur-[2px]">
            <div className="w-3/4 space-y-2 text-center">
              <div className="text-xs font-semibold text-white">{clip.status === 'pending' ? 'Waiting to render' : 'Rendering'}</div>
              <ProgressBar value={clip.progress} indeterminate={clip.status === 'pending'} />
              {clip.status === 'rendering' && (
                <div className="font-mono text-[11px] text-zinc-400">{Math.round((clip.progress || 0) * 100)}%</div>
              )}
            </div>
          </div>
        )}
        {clip.status === 'error' && (
          <div className="absolute inset-x-2 bottom-12 flex items-start gap-1.5 rounded-lg bg-rose-950/80 p-2 text-[11px] text-rose-200 backdrop-blur">
            <AlertTriangle className="mt-px h-3.5 w-3.5 shrink-0" />
            <span className="line-clamp-3">{clip.error || 'Render failed'}</span>
          </div>
        )}
      </div>

      {/* body */}
      <button type="button" onClick={onOpen} className="flex flex-1 flex-col gap-2 p-3.5 text-left">
        <div className="font-display text-[15px] font-bold leading-snug text-white">{clip.hook || clip.title}</div>
        {clip.title && clip.hook && <div className="line-clamp-2 text-[13px] leading-snug text-zinc-400">{clip.title}</div>}
        {clip.why && (
          <div className="flex items-start gap-1.5 text-[12px] leading-snug text-zinc-500">
            <Lightbulb className="mt-px h-3.5 w-3.5 shrink-0 text-goblin-400/70" />
            <span className="line-clamp-2">{clip.why}</span>
          </div>
        )}
        <div className="mt-auto flex items-center justify-between gap-2 pt-1.5">
          <PublishStatusIcons clip={clip} />
          <span className="flex items-center gap-1 font-mono text-[11px] text-zinc-600">
            <Clock className="h-3 w-3" />
            {fmtDuration(clip.start)}
          </span>
        </div>
      </button>
    </motion.div>
  );
}
