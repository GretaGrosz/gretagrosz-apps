import clsx from 'clsx';
import { CalendarClock, ExternalLink, RotateCcw, Send, X } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { api, errMsg } from '../lib/api';
import { fmtClock, fmtDayLabel, fmtSpacing, fromLocalInput, timeAgo, timeUntil, toLocalInput } from '../lib/format';
import { PLATFORM_META, PUB_STATUS } from '../lib/meta';
import { toast, useStore } from '../lib/store';
import type { Platform, Publication } from '../lib/types';
import { PLATFORMS } from '../lib/types';
import { PlatformIcon } from './Brand';
import { PlatformPicker } from './Pipeline';
import { ProgressBar, Segmented, Spinner } from './ui';

const SPACING_PRESETS = [0, 30, 60, 120, 180, 360, 720, 1440];

function nextRoundHour(offsetH = 1) {
  const d = new Date();
  d.setMinutes(0, 0, 0);
  d.setHours(d.getHours() + offsetH);
  return d.getTime();
}

export function PublishForm({
  clipIds,
  single,
  onDone,
}: {
  clipIds: string[];
  single?: { title?: string; caption?: string; beforeSubmit?: () => Promise<void> };
  onDone?: (pubs: Publication[]) => void;
}) {
  const accounts = useStore((s) => s.accounts);
  const autopilot = useStore((s) => s.settings?.autopilot);
  const connected = PLATFORMS.filter((p) => accounts?.[p]?.connected);
  const [platforms, setPlatforms] = useState<Platform[]>([]);
  const [mode, setMode] = useState<'now' | 'schedule'>('now');
  const [when, setWhen] = useState(() => toLocalInput(nextRoundHour()));
  const [spacing, setSpacing] = useState(autopilot?.spacingMinutes ?? 180);
  const [busy, setBusy] = useState(false);
  const multi = clipIds.length > 1;

  useEffect(() => {
    // Preselect every connected platform the first time accounts load.
    setPlatforms((cur) => (cur.length ? cur : connected));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [accounts]);

  const base = mode === 'now' ? Date.now() : fromLocalInput(when) ?? Date.now();
  const plan = useMemo(() => clipIds.map((_, i) => base + i * spacing * 60_000), [clipIds, base, spacing]);

  const submit = async () => {
    if (!platforms.length) return toast.error('Pick at least one platform');
    if (mode === 'schedule' && base < Date.now() - 60_000) return toast.error('That time is in the past', 'Pick a time in the future.');
    setBusy(true);
    try {
      await single?.beforeSubmit?.();
      const all: Publication[] = [];
      for (let i = 0; i < clipIds.length; i++) {
        const at = plan[i];
        const immediate = mode === 'now' && (i === 0 || spacing === 0);
        const pubs = await api.publish(clipIds[i], {
          platforms,
          scheduleAt: immediate ? undefined : at,
          title: single?.title,
          caption: single?.caption,
        });
        if (Array.isArray(pubs)) all.push(...pubs);
      }
      useStore.getState().upsertPublications(all);
      const n = clipIds.length;
      if (mode === 'now' && (!multi || spacing === 0)) toast.success(`Posting ${n > 1 ? `${n} clips` : 'now'}`, 'Track progress in the Queue.');
      else toast.success(`Scheduled ${n} clip${n > 1 ? 's' : ''}`, `First one ${timeUntil(plan[0]) === 'now' ? 'goes out now' : timeUntil(plan[0])}.`);
      onDone?.(all);
    } catch (err) {
      toast.error('Publishing failed', errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      <PlatformPicker value={platforms} onChange={setPlatforms} className="grid grid-cols-1 gap-2" />
      {connected.length === 0 && accounts && (
        <p className="rounded-xl border border-amber-300/20 bg-amber-300/[0.06] px-3 py-2 text-xs text-amber-200/90">
          No accounts connected yet. Hook one up in Settings → Connections.
        </p>
      )}
      <Segmented
        className="w-full"
        value={mode}
        onChange={setMode}
        options={[
          { value: 'now', label: 'Post now', icon: <Send className="h-3.5 w-3.5" /> },
          { value: 'schedule', label: 'Schedule', icon: <CalendarClock className="h-3.5 w-3.5" /> },
        ]}
      />
      {mode === 'schedule' && (
        <div>
          <span className="label">{multi ? 'First post at' : 'Post at'}</span>
          <input type="datetime-local" className="input" value={when} onChange={(e) => setWhen(e.target.value)} min={toLocalInput(Date.now())} />
        </div>
      )}
      {multi && (
        <div>
          <span className="label">Space them out</span>
          <select className="input" value={spacing} onChange={(e) => setSpacing(Number(e.target.value))}>
            {SPACING_PRESETS.map((m) => (
              <option key={m} value={m}>
                {m === 0 ? 'All at once' : `One every ${fmtSpacing(m)}`}
              </option>
            ))}
          </select>
          {spacing > 0 && (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {plan.slice(0, 6).map((t, i) => (
                <span key={i} className="chip border-white/10 bg-white/[0.03] font-mono font-medium text-zinc-400">
                  {i === 0 && mode === 'now' ? 'now' : `${fmtDayLabel(t) === 'Today' ? '' : fmtDayLabel(t).split(',')[0] + ' '}${fmtClock(t)}`}
                </span>
              ))}
              {plan.length > 6 && <span className="chip border-white/10 text-zinc-500">+{plan.length - 6}</span>}
            </div>
          )}
        </div>
      )}
      <button className="btn btn-lg btn-primary w-full" disabled={busy || !platforms.length} onClick={submit}>
        {busy ? <Spinner /> : mode === 'now' ? <Send className="h-4 w-4" /> : <CalendarClock className="h-4 w-4" />}
        {mode === 'now'
          ? multi
            ? `Publish ${clipIds.length} clips`
            : 'Post now'
          : multi
            ? `Schedule ${clipIds.length} clips`
            : 'Schedule post'}
      </button>
    </div>
  );
}

/** One publication row (used in the editor and the queue). */
export function PublicationRow({ pub, showClip, thumb, clipTitle }: { pub: Publication; showClip?: boolean; thumb?: string | null; clipTitle?: string }) {
  const meta = PUB_STATUS[pub.status] ?? PUB_STATUS.scheduled;
  const [busy, setBusy] = useState(false);
  const active = pub.status === 'uploading' || pub.status === 'processing';

  const cancel = async () => {
    setBusy(true);
    try {
      await api.cancelPublication(pub.id);
      useStore.getState().upsertPublications([{ ...pub, status: 'canceled' }]);
      toast.info('Post canceled');
    } catch (err) {
      toast.error('Could not cancel', errMsg(err));
    } finally {
      setBusy(false);
    }
  };
  const retry = async () => {
    setBusy(true);
    try {
      const p = await api.retryPublication(pub.id);
      if (p && p.id) useStore.getState().upsertPublications([p]);
      toast.success('Retrying', `Sending to ${PLATFORM_META[pub.platform].short} again.`);
    } catch (err) {
      toast.error('Retry failed', errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  const when =
    pub.status === 'published' && pub.publishedAt
      ? `Posted ${timeAgo(pub.publishedAt)}`
      : pub.status === 'scheduled'
        ? `${fmtDayLabel(pub.scheduledAt)} · ${fmtClock(pub.scheduledAt)} · ${timeUntil(pub.scheduledAt)}`
        : pub.updatedAt
          ? timeAgo(pub.updatedAt)
          : timeAgo(pub.scheduledAt);

  return (
    <div className={clsx('flex items-start gap-3 rounded-xl border border-white/[0.06] bg-ink-950/30 p-3', busy && 'opacity-60')}>
      {showClip && (
        <div className="relative h-16 w-9 shrink-0 overflow-hidden rounded-md bg-ink-800 sm:h-[72px] sm:w-[41px]">
          {thumb && <img src={thumb} alt="" className="h-full w-full object-cover" loading="lazy" />}
        </div>
      )}
      <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-white/[0.04]">
        <PlatformIcon platform={pub.platform} className="h-4 w-4" />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
          {showClip ? (
            <span className="truncate text-sm font-semibold text-white">{pub.title || clipTitle || 'Untitled clip'}</span>
          ) : (
            <span className="text-sm font-semibold text-white">{PLATFORM_META[pub.platform].short}</span>
          )}
          <span className={clsx('chip', meta.cls)}>
            <span className={clsx('h-1.5 w-1.5 rounded-full', meta.dot, active && 'animate-pulse')} />
            {meta.label}
          </span>
        </div>
        <div className="mt-0.5 text-xs text-zinc-500">{when}</div>
        {active && <ProgressBar value={pub.progress ?? 0} indeterminate={!pub.progress} tone="sky" thin className="mt-2" />}
        {pub.status === 'error' && pub.error && <div className="mt-1.5 break-words text-xs leading-snug text-rose-300/90">{pub.error}</div>}
      </div>
      <div className="flex shrink-0 items-center gap-1">
        {pub.url && pub.status === 'published' && (
          <a href={pub.url} target="_blank" rel="noreferrer" className="btn btn-sm btn-outline">
            <ExternalLink className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Open</span>
          </a>
        )}
        {(pub.status === 'error' || pub.status === 'canceled') && (
          <button className="btn btn-sm btn-outline" onClick={retry} disabled={busy}>
            <RotateCcw className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Retry</span>
          </button>
        )}
        {pub.status === 'scheduled' && (
          <button className="btn btn-sm btn-ghost text-zinc-400 hover:text-rose-300" onClick={cancel} disabled={busy} title="Cancel">
            <X className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Cancel</span>
          </button>
        )}
      </div>
    </div>
  );
}
