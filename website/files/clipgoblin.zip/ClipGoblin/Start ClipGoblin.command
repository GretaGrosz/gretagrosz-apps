#!/bin/bash
# Double-click to start ClipGoblin. First run installs everything (a few minutes).
cd "$(dirname "$0")"
export PATH="/usr/local/bin:/opt/homebrew/bin:$HOME/.local/node/bin:$PATH"
if ! command -v node >/dev/null 2>&1; then
  echo "ClipGoblin needs Node.js. Opening nodejs.org: install the LTS version, then double-click this file again."
  open "https://nodejs.org/en/download"
  read -n 1 -s -r -p "Press any key to close."
  exit 1
fi
if [ ! -d node_modules ] || [ ! -d web/dist ]; then
  echo "First start: installing ClipGoblin (a few minutes)…"
  npm run setup || { read -n 1 -s -r -p "Install failed. Press any key to close."; exit 1; }
fi
(sleep 3 && open "http://localhost:4777") &
npm start
