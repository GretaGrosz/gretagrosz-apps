# 👺 ClipGoblin

Turn hour-long stream VODs into vertical shorts: hooks, animated captions, cold opens, jump cuts and a progress bar. Post them to YouTube Shorts, TikTok and Instagram Reels yourself, on a schedule, or on autopilot.

## Run it

Easiest on a Mac: install Node.js (LTS) from nodejs.org, then double-click **Start ClipGoblin.command** (first time: right-click → Open). Or from a terminal:

```bash
npm run setup      # once: installs everything and builds the web app
npm start          # → http://localhost:4777
npm run start:lan  # same, but reachable from your phone on the same Wi-Fi
```

Works with no keys: transcription runs on your Mac (Whisper) and a built-in heuristic picks the clips.
Add an **Anthropic API key** in Settings and Claude picks the moments and writes the hooks (much better).

## Auto-posting setup (Settings → Connections)

Each platform needs your own developer app. Settings shows step-by-step instructions and the redirect URI to paste.

- **YouTube:** Google Cloud project with YouTube Data API v3 and an OAuth client. Unaudited projects can only upload as Private.
- **TikTok:** an app on developers.tiktok.com with Login Kit and the Content Posting API. Until TikTok audits the app, posts are private only. "Inbox" mode sends drafts to your TikTok app instead.
- **Instagram:** a Business or Creator account and a Meta app with Instagram Login. Meta requires an HTTPS redirect, so run a tunnel (e.g. `cloudflared tunnel --url http://localhost:4777`) and put its URL in *Public base URL*.

See `ARCHITECTURE.md` for the API and data model.
