import clsx from 'clsx';
import { Crop, ImageOff, MousePointerSquareDashed, Trash2 } from 'lucide-react';
import { useEffect, useMemo, useRef, useState, type PointerEvent as RPointerEvent } from 'react';
import { api } from '../lib/api';
import { fmtDuration } from '../lib/format';
import { useStore } from '../lib/store';
import type { Rect } from '../lib/types';
import { Spinner } from './ui';

type Handle = 'move' | 'nw' | 'ne' | 'sw' | 'se' | 'draw';
const MIN = 0.04;
const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

export function FacecamPicker({ value, onChange }: { value: Rect | null; onChange: (r: Rect | null) => void }) {
  const jobsMap = useStore((s) => s.jobs);
  const jobs = useMemo(
    () => Object.values(jobsMap).filter((j) => (j.durationSec ?? 0) > 0 && j.status !== 'canceled').sort((a, b) => b.createdAt - a.createdAt),
    [jobsMap],
  );
  const [jobId, setJobId] = useState<string>('');
  const job = jobsMap[jobId] ?? jobs[0];
  const dur = job?.durationSec ?? 0;
  const [t, setT] = useState(0);
  const [debouncedT, setDebouncedT] = useState(0);
  const [imgState, setImgState] = useState<'loading' | 'ok' | 'error'>('loading');
  const [aspect, setAspect] = useState(16 / 9);
  const imgRef = useRef<HTMLImageElement>(null);
  const boxRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drag = useRef<{ handle: Handle; start: { x: number; y: number }; rect: Rect } | null>(null);

  useEffect(() => {
    if (!job) return;
    const start = Math.min(60, dur * 0.25);
    setT(start);
    setDebouncedT(start);
    if (job.width && job.height) setAspect(job.width / job.height);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [job?.id]);

  useEffect(() => {
    const h = setTimeout(() => setDebouncedT(t), 220);
    return () => clearTimeout(h);
  }, [t]);

  const src = job ? api.frameUrl(job.id, debouncedT) : null;
  useEffect(() => setImgState('loading'), [src]);

  // Live 9:16 preview of the facecam-split layout.
  useEffect(() => {
    const c = canvasRef.current;
    const img = imgRef.current;
    if (!c || !img || imgState !== 'ok') return;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    const W = (c.width = 180);
    const H = (c.height = 320);
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, W, H);
    const iw = img.naturalWidth;
    const ih = img.naturalHeight;
    const camH = value ? Math.round(H * 0.4) : 0;
    try {
      if (value) {
        // cover-fit the facecam region into the top band
        const sw = value.w * iw;
        const sh = value.h * ih;
        const scale = Math.max(W / sw, camH / sh);
        const cw = W / scale;
        const ch = camH / scale;
        const cx = value.x * iw + (sw - cw) / 2;
        const cy = value.y * ih + (sh - ch) / 2;
        ctx.drawImage(img, cx, cy, cw, ch, 0, 0, W, camH);
      }
      // gameplay: center crop of the full frame into the rest
      const gh = H - camH;
      const scale = Math.max(W / iw, gh / ih);
      const cw = W / scale;
      const ch = gh / scale;
      ctx.drawImage(img, (iw - cw) / 2, (ih - ch) / 2, cw, ch, 0, camH, W, gh);
      if (value) {
        ctx.fillStyle = 'rgba(198,255,61,.9)';
        ctx.fillRect(0, camH - 1, W, 2);
      }
    } catch {
      /* cross-origin or decode issue: ignore */
    }
  }, [value, imgState, src]);

  const pointFromEvent = (e: RPointerEvent) => {
    const r = boxRef.current!.getBoundingClientRect();
    return { x: clamp01((e.clientX - r.left) / r.width), y: clamp01((e.clientY - r.top) / r.height) };
  };

  const onPointerDown = (e: RPointerEvent, handle: Handle) => {
    e.preventDefault();
    e.stopPropagation();
    (e.currentTarget as Element).setPointerCapture?.(e.pointerId);
    const p = pointFromEvent(e);
    const rect = handle === 'draw' ? { x: p.x, y: p.y, w: 0, h: 0 } : value!;
    drag.current = { handle, start: p, rect };
    if (handle === 'draw') onChange({ x: p.x, y: p.y, w: MIN, h: MIN });
  };

  const onPointerMove = (e: RPointerEvent) => {
    const d = drag.current;
    if (!d) return;
    const p = pointFromEvent(e);
    const dx = p.x - d.start.x;
    const dy = p.y - d.start.y;
    const r = d.rect;
    let next: Rect;
    switch (d.handle) {
      case 'move':
        next = { ...r, x: Math.max(0, Math.min(1 - r.w, r.x + dx)), y: Math.max(0, Math.min(1 - r.h, r.y + dy)) };
        break;
      case 'draw': {
        const x0 = Math.min(d.start.x, p.x);
        const y0 = Math.min(d.start.y, p.y);
        next = { x: x0, y: y0, w: Math.max(MIN, Math.abs(dx)), h: Math.max(MIN, Math.abs(dy)) };
        break;
      }
      default: {
        let x1 = r.x;
        let y1 = r.y;
        let x2 = r.x + r.w;
        let y2 = r.y + r.h;
        if (d.handle.includes('w')) x1 = Math.min(x2 - MIN, clamp01(r.x + dx));
        if (d.handle.includes('e')) x2 = Math.max(x1 + MIN, clamp01(r.x + r.w + dx));
        if (d.handle.includes('n')) y1 = Math.min(y2 - MIN, clamp01(r.y + dy));
        if (d.handle.includes('s')) y2 = Math.max(y1 + MIN, clamp01(r.y + r.h + dy));
        next = { x: x1, y: y1, w: x2 - x1, h: y2 - y1 };
      }
    }
    const round = (v: number) => Math.round(v * 1000) / 1000;
    onChange({ x: round(next.x), y: round(next.y), w: round(Math.min(next.w, 1 - next.x)), h: round(Math.min(next.h, 1 - next.y)) });
  };

  const onPointerUp = () => {
    drag.current = null;
  };

  if (!jobs.length)
    return (
      <div className="flex flex-col items-center rounded-2xl border border-dashed border-white/10 bg-ink-950/30 px-6 py-10 text-center">
        <MousePointerSquareDashed className="h-8 w-8 text-zinc-600" />
        <div className="mt-3 text-sm font-semibold text-zinc-300">No VODs to pick a frame from yet</div>
        <p className="mt-1 max-w-xs text-xs text-zinc-500">Start a job first. Once it's imported you can mark where your facecam sits.</p>
      </div>
    );

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_auto]">
      <div className="min-w-0 space-y-3">
        <div className="flex flex-col gap-2 sm:flex-row">
          <select className="input sm:flex-1" value={job?.id} onChange={(e) => setJobId(e.target.value)}>
            {jobs.map((j) => (
              <option key={j.id} value={j.id}>
                {j.source?.name || j.id} ({fmtDuration(j.durationSec)})
              </option>
            ))}
          </select>
          <button className="btn btn-outline" onClick={() => onChange(null)} disabled={!value}>
            <Trash2 className="h-4 w-4" /> Clear
          </button>
        </div>

        <div
          ref={boxRef}
          className="relative w-full touch-none select-none overflow-hidden rounded-xl bg-ink-950 ring-1 ring-white/10"
          style={{ aspectRatio: String(aspect) }}
          onPointerDown={(e) => imgState === 'ok' && onPointerDown(e, 'draw')}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
          onPointerCancel={onPointerUp}
        >
          {src && (
            <img
              ref={imgRef}
              src={src}
              alt="Frame from the VOD"
              draggable={false}
              className={clsx('absolute inset-0 h-full w-full object-contain transition-opacity duration-300', imgState === 'ok' ? 'opacity-100' : 'opacity-30')}
              onLoad={(e) => {
                const im = e.currentTarget;
                if (im.naturalWidth && im.naturalHeight) setAspect(im.naturalWidth / im.naturalHeight);
                setImgState('ok');
              }}
              onError={() => setImgState('error')}
            />
          )}
          {imgState === 'loading' && (
            <div className="absolute inset-0 grid place-items-center">
              <Spinner className="h-6 w-6 text-zinc-400" />
            </div>
          )}
          {imgState === 'error' && (
            <div className="absolute inset-0 grid place-items-center text-center text-sm text-zinc-500">
              <div>
                <ImageOff className="mx-auto mb-2 h-6 w-6" />
                Couldn't grab a frame here — try another time or VOD.
              </div>
            </div>
          )}
          {value && (
            <>
              {/* dim outside */}
              <div
                className="pointer-events-none absolute inset-0 bg-black/55"
                style={{
                  clipPath: `polygon(0 0,100% 0,100% 100%,0 100%,0 0,${value.x * 100}% ${value.y * 100}%,${value.x * 100}% ${(value.y + value.h) * 100}%,${(value.x + value.w) * 100}% ${(value.y + value.h) * 100}%,${(value.x + value.w) * 100}% ${value.y * 100}%,${value.x * 100}% ${value.y * 100}%)`,
                }}
              />
              <div
                className="absolute cursor-move rounded-md border-2 border-goblin-400 shadow-[0_0_0_1px_rgba(0,0,0,.5),0_0_30px_-4px_rgba(198,255,61,.6)]"
                style={{ left: `${value.x * 100}%`, top: `${value.y * 100}%`, width: `${value.w * 100}%`, height: `${value.h * 100}%` }}
                onPointerDown={(e) => onPointerDown(e, 'move')}
              >
                <span className="pointer-events-none absolute -top-6 left-0 whitespace-nowrap rounded bg-goblin-400 px-1.5 py-0.5 text-[10px] font-bold text-ink-950">
                  FACECAM
                </span>
                {(['nw', 'ne', 'sw', 'se'] as const).map((h) => (
                  <span
                    key={h}
                    onPointerDown={(e) => onPointerDown(e, h)}
                    className={clsx(
                      'absolute h-4 w-4 rounded-full border-2 border-ink-950 bg-goblin-400 sm:h-3.5 sm:w-3.5',
                      h === 'nw' && '-left-2 -top-2 cursor-nwse-resize',
                      h === 'ne' && '-right-2 -top-2 cursor-nesw-resize',
                      h === 'sw' && '-bottom-2 -left-2 cursor-nesw-resize',
                      h === 'se' && '-bottom-2 -right-2 cursor-nwse-resize',
                    )}
                  />
                ))}
              </div>
            </>
          )}
          {!value && imgState === 'ok' && (
            <div className="pointer-events-none absolute inset-x-0 bottom-3 flex justify-center">
              <span className="flex items-center gap-1.5 rounded-full bg-black/70 px-3 py-1.5 text-xs font-medium text-white backdrop-blur">
                <Crop className="h-3.5 w-3.5 text-goblin-400" /> Drag a box around your facecam
              </span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-3">
          <span className="w-14 font-mono text-xs text-zinc-400 tabular">{fmtDuration(t)}</span>
          <input
            type="range"
            className="range flex-1"
            min={0}
            max={Math.max(1, dur - 1)}
            step={1}
            value={t}
            style={{ ['--fill' as string]: `${(t / Math.max(1, dur - 1)) * 100}%` }}
            onChange={(e) => setT(Number(e.target.value))}
            aria-label="Frame time"
          />
          <span className="w-14 text-right font-mono text-xs text-zinc-500 tabular">{fmtDuration(dur)}</span>
        </div>
        <div className="text-xs text-zinc-500">
          {value ? (
            <span className="font-mono">
              x {value.x.toFixed(3)} · y {value.y.toFixed(3)} · w {value.w.toFixed(3)} · h {value.h.toFixed(3)}
            </span>
          ) : (
            'No region set — the goblin will try to auto-detect your facecam.'
          )}
        </div>
      </div>

      <div className="flex flex-col items-center gap-2">
        <span className="label !mb-0">Split preview</span>
        <div className="relative aspect-[9/16] w-[150px] overflow-hidden rounded-xl bg-black ring-1 ring-white/10 sm:w-[180px]">
          <canvas ref={canvasRef} className="h-full w-full" />
          {imgState !== 'ok' && <div className="absolute inset-0 grid place-items-center text-xs text-zinc-600">No frame</div>}
        </div>
        <span className="text-[11px] text-zinc-600">approximate</span>
      </div>
    </div>
  );
}
