// Job orchestration: a single-concurrency job queue (download → probe → audio → transcribe →
// analyze → render), clip renders limited to 2 in parallel, cancellation, resume after restart.
// Every stage is cached in paths.work/<jobId>/ so retries skip finished work.
import fs from 'node:fs';
import path from 'node:path';
import { paths, getSettings } from '../config.js';
import { store } from '../store.js';
import { emit } from '../events.js';
import { downloadUrl, probeAndPoster } from './ingest.js';
import { extractPcm, analyzeEnergy } from './audio.js';
import { transcribe } from './transcribe.js';
import { analyze } from './analyze.js';
import { renderClip } from './render.js';
import { Semaphore, throttle, fmtTime, cleanError, workDir, readJson, writeJson, fileExists, rmrf, CanceledError, throwIfAborted } from './util.js';

const queue = [];
let running = null; // { jobId, controller }
const renderSem = new Semaphore(2);
const clipRenders = new Map(); // clipId -> { controller, promise }

export const ACTIVE_STATUSES = ['queued', 'downloading', 'probing', 'transcribing', 'analyzing', 'rendering'];

export const isJobActive = (id) => running?.jobId === id || queue.includes(id);

export function enqueueJob(id) {
  if (!isJobActive(id)) queue.push(id);
  const pos = queue.indexOf(id);
  if (pos > 0 || running) {
    const j = store.get('jobs', id);
    if (j && j.status === 'queued') store.update('jobs', id, { stage: `Waiting in queue (#${pos + 1 + (running ? 1 : 0)})` });
  }
  setImmediate(pump);
}

async function pump() {
  if (running || !queue.length) return;
  const jobId = queue.shift();
  const controller = new AbortController();
  running = { jobId, controller };
  try {
    await runJob(jobId, controller.signal);
  } catch (e) {
    console.error(`[job ${jobId}]`, e);
  } finally {
    running = null;
    setImmediate(pump);
  }
}

/** Cancel a queued/running job and any of its clip renders. Returns true if something was stopped. */
export function cancelJob(id) {
  let stopped = false;
  const qi = queue.indexOf(id);
  if (qi >= 0) { queue.splice(qi, 1); stopped = true; }
  if (running?.jobId === id) { running.controller.abort(); stopped = true; }
  for (const [clipId, r] of clipRenders) {
    if (store.get('clips', clipId)?.jobId === id) { r.controller.abort(); stopped = true; }
  }
  return stopped;
}

export function cancelClipRender(clipId) {
  const r = clipRenders.get(clipId);
  if (r) { r.controller.abort(); return true; }
  return false;
}

// ------------------------------------------------------------------ helpers

export function loadTranscript(jobId) {
  return readJson(path.join(paths.work, jobId, 'transcript.json'));
}
export function loadEnergy(jobId) {
  return readJson(path.join(paths.work, jobId, 'energy.json'));
}

function clipDocFromSpec(job, spec) {
  const o = job.options;
  return {
    id: store.newId('clip'),
    jobId: job.id,
    rank: spec.rank,
    score: spec.score,
    start: spec.start,
    end: spec.end,
    coldOpen: spec.coldOpen,
    hook: spec.hook,
    title: spec.title,
    description: spec.description,
    hashtags: spec.hashtags,
    category: spec.category,
    why: spec.why,
    transcript: spec.transcript,
    status: 'pending',
    progress: 0,
    error: null,
    file: null,
    thumb: null,
    durationSec: Math.round((spec.end - spec.start) * 100) / 100,
    style: {
      layout: o.layout, captionStyle: o.captionStyle, coldOpen: o.coldOpen, jumpCuts: o.jumpCuts,
      progressBar: o.progressBar, hookBanner: o.hookBanner, chaos: o.chaos,
    },
    publish: {},
  };
}

/**
 * Render one clip document (used by jobs and by standalone re-renders).
 * Updates clip.status / progress / file / thumb in the store.
 */
async function renderClipDoc(clipId, { signal } = {}) {
  return renderSem.run(async () => {
    throwIfAborted(signal);
    let clip = store.get('clips', clipId);
    if (!clip) return null;
    const job = store.get('jobs', clip.jobId);
    if (!job) throw new Error('Parent job is gone');
    const transcript = loadTranscript(job.id);
    const energy = loadEnergy(job.id);
    if (!transcript || !energy) throw new Error('Transcript for this VOD is missing — retry the job');
    if (!job.videoPath || !fileExists(job.videoPath)) throw new Error('Source video is missing — it may have been deleted');
    clip = store.update('clips', clipId, { status: 'rendering', progress: 0, error: null });
    const setProgress = throttle((p) => {
      if (store.get('clips', clipId)?.status === 'rendering') store.update('clips', clipId, { progress: Math.round(p * 1000) / 1000 });
    }, 500);
    try {
      const res = await renderClip({
        job, clip, words: transcript.words, energy,
        src: { width: job.width, height: job.height, hasAudio: job.hasAudio !== false },
        signal,
        onProgress: setProgress,
      });
      setProgress.cancel();
      const v = Date.now();
      return store.update('clips', clipId, {
        status: 'ready', progress: 1, error: null,
        file: `/media/clips/${clipId}.mp4?v=${v}`,
        thumb: `/media/clips/${clipId}.jpg?v=${v}`,
        durationSec: res.durationSec,
        renderedLayout: res.layout,
        renderedAt: v,
      });
    } catch (e) {
      setProgress.cancel();
      if (!store.get('clips', clipId)) return null; // deleted meanwhile
      if (e.canceled || signal?.aborted) {
        const c = store.get('clips', clipId);
        store.update('clips', clipId, { status: c.file ? 'ready' : 'pending', progress: c.file ? 1 : 0, error: null });
        throw new CanceledError();
      }
      console.error(`[render ${clipId}]`, e);
      store.update('clips', clipId, { status: 'error', error: cleanError(e), progress: 0 });
      throw e;
    }
  });
}

/** Standalone (re-)render of a clip outside the job queue. */
export function requestClipRender(clipId) {
  cancelClipRender(clipId);
  const controller = new AbortController();
  store.update('clips', clipId, { status: 'pending', progress: 0, error: null });
  const promise = (async () => {
    // Let a previous render of the same clip unwind first.
    await new Promise((r) => setTimeout(r, 50));
    try {
      await renderClipDoc(clipId, { signal: controller.signal });
    } catch (e) {
      if (!e.canceled) emit({ type: 'toast', data: { level: 'error', message: `Render failed: ${cleanError(e)}` } });
    } finally {
      if (clipRenders.get(clipId)?.controller === controller) clipRenders.delete(clipId);
    }
  })();
  clipRenders.set(clipId, { controller, promise });
  return promise;
}

// ------------------------------------------------------------------ the job

function weightsFor(job) {
  // [start, end] of overall progress for each stage
  return job.source?.type === 'url'
    ? { download: [0, 0.2], probe: [0.2, 0.22], audio: [0.22, 0.27], transcribe: [0.27, 0.66], analyze: [0.66, 0.72], render: [0.72, 1] }
    : { download: [0, 0], probe: [0, 0.02], audio: [0.02, 0.08], transcribe: [0.08, 0.62], analyze: [0.62, 0.7], render: [0.7, 1] };
}

async function runJob(jobId, signal) {
  let job = store.get('jobs', jobId);
  if (!job) return;
  const settings = getSettings();
  const dir = workDir(jobId);
  const W = weightsFor(job);
  const set = (patch) => {
    if (signal.aborted) return job;
    const next = store.update('jobs', jobId, patch);
    if (next) job = next;
    return job;
  };
  const stageProgress = (stage) => throttle((frac, text) => {
    const [a, b] = W[stage];
    const patch = { progress: Math.round((a + (b - a) * Math.min(1, Math.max(0, frac))) * 1000) / 1000 };
    if (text) patch.stage = text;
    set(patch);
  }, 350);

  try {
    set({ error: null, analyzerNote: null });

    // 1. Download (URL jobs)
    if (job.source?.type === 'url' && !(job.videoPath && fileExists(job.videoPath))) {
      set({ status: 'downloading', stage: 'Starting download…', progress: 0 });
      const p = stageProgress('download');
      const { file, title } = await downloadUrl(jobId, job.source.url, { signal, onProgress: p });
      p.cancel();
      set({ videoPath: file, source: { ...job.source, name: title || job.source.name } });
    }
    if (!job.videoPath || !fileExists(job.videoPath)) throw new Error('Source video file is missing');

    // 2. Probe + poster
    set({ status: 'probing', stage: 'Reading video…', progress: W.probe[0] });
    const info = await probeAndPoster(jobId, job.videoPath, { signal });
    set({ durationSec: Math.round(info.durationSec * 100) / 100, width: info.width, height: info.height, hasAudio: info.hasAudio, thumb: info.thumb || job.thumb, sizeBytes: info.sizeBytes });
    if (!info.hasAudio) throw new Error('This video has no audio track — ClipGoblin needs speech/audio to find highlights');

    // 3. Audio → loudness curve → transcript
    set({ status: 'transcribing', stage: 'Extracting audio…', progress: W.audio[0] });
    const pa = stageProgress('audio');
    const pcmPath = await extractPcm(job.videoPath, dir, info.durationSec, { signal, onProgress: (f) => pa(f, `Extracting audio ${Math.round(f * 100)}%`) });
    pa.cancel();
    set({ stage: 'Measuring loudness…' });
    const energy = analyzeEnergy(pcmPath, dir);
    throwIfAborted(signal);
    const pt = stageProgress('transcribe');
    const transcript = await transcribe({ pcmPath, energy, settings, dir, signal, onProgress: pt });
    pt.cancel();
    set({ wordCount: transcript.words.length, transcription: { provider: transcript.provider, model: transcript.model } });

    // 4. Analyze (skipped when clips already exist — e.g. a retry after a render failure)
    const existing = (job.clipIds || []).map((id) => store.get('clips', id)).filter(Boolean);
    if (!existing.length) {
      set({ status: 'analyzing', stage: 'Finding the best moments…', progress: W.analyze[0] });
      const o = job.options;
      const key = [settings.anthropicApiKey ? `claude:${settings.claudeModel}` : 'heuristic', transcript.model, transcript.words.length, o.minSec, o.maxSec, o.maxClips].join('|');
      const cacheFile = path.join(dir, 'analysis.json');
      let result = readJson(cacheFile);
      if (!result || result.key !== key || result.analyzer === 'heuristic' && settings.anthropicApiKey) {
        result = await analyze({
          words: transcript.words, energy, options: o, durationSec: info.durationSec, settings,
          title: job.source?.name, signal,
          onStage: (s) => set({ stage: s }),
        });
        result.key = key;
        writeJson(cacheFile, result);
      }
      throwIfAborted(signal);
      if (!result.clips.length) throw new Error('No usable moments found in this VOD (is there any speech?)');
      const docs = result.clips.map((spec) => store.insert('clips', clipDocFromSpec(job, spec)));
      set({ clipIds: docs.map((d) => d.id), analyzer: result.analyzer, analyzerModel: result.model || null, analyzerNote: result.note || null });
      if (result.note) emit({ type: 'toast', data: { level: 'warning', message: result.note } });
    }

    // 5. Render
    const ids = (job.clipIds || []).filter((id) => store.get('clips', id));
    const todo = ids.filter((id) => {
      const c = store.get('clips', id);
      return c.status !== 'ready' || !fileExists(path.join(paths.clips, `${id}.mp4`));
    });
    set({ status: 'rendering', stage: `Rendering ${todo.length} clip${todo.length === 1 ? '' : 's'}…`, progress: W.render[0] });
    const per = new Map(todo.map((id) => [id, 0]));
    let done = 0;
    const pr = stageProgress('render');
    const onClipProgress = () => {
      const avg = todo.length ? [...per.values()].reduce((a, b) => a + b, 0) / todo.length : 1;
      pr(avg, `Rendering clip ${Math.min(todo.length, done + 1)} of ${todo.length}…`);
    };
    const results = await Promise.allSettled(todo.map(async (id) => {
      // Mirror the clip's own progress into the job's.
      const off = setInterval(() => { const c = store.get('clips', id); if (c) { per.set(id, c.status === 'ready' ? 1 : c.progress || 0); onClipProgress(); } }, 700);
      try {
        await renderClipDoc(id, { signal });
        per.set(id, 1);
        done++;
        onClipProgress();
      } finally {
        clearInterval(off);
      }
    }));
    pr.cancel();
    throwIfAborted(signal);
    const failed = results.filter((r) => r.status === 'rejected');
    const ready = ids.filter((id) => store.get('clips', id)?.status === 'ready').length;
    if (!ready && failed.length) throw failed[0].reason;

    set({
      status: 'done', progress: 1,
      stage: `${ready} clip${ready === 1 ? '' : 's'} ready${failed.length ? ` · ${failed.length} failed` : ''} · ${fmtTime(info.durationSec)} VOD`,
      finishedAt: Date.now(),
    });
    emit({ type: 'toast', data: { level: 'success', message: `${ready} clips ready from “${job.source?.name || 'your VOD'}”` } });
    // The raw PCM is big (≈230 MB/hour) and only needed for transcription: free it.
    rmrf(path.join(dir, 'audio.f32'));
    rmrf(path.join(dir, 'audio.done'));
  } catch (e) {
    if (!store.get('jobs', jobId)) return; // deleted while running
    if (e?.canceled || signal.aborted) {
      store.update('jobs', jobId, { status: 'canceled', stage: 'Canceled' });
      for (const id of store.get('jobs', jobId).clipIds || []) {
        const c = store.get('clips', id);
        if (c && (c.status === 'rendering' || c.status === 'pending')) store.update('clips', id, { status: c.file ? 'ready' : 'pending', progress: c.file ? 1 : 0 });
      }
      return;
    }
    console.error(`[job ${jobId}] failed:`, e);
    store.update('jobs', jobId, { status: 'error', error: cleanError(e), stage: 'Failed' });
    emit({ type: 'toast', data: { level: 'error', message: `Job failed: ${cleanError(e)}` } });
  }
}

/** Remove a job, its clips, rendered files, work dir and uploaded source. */
export function deleteJobData(job) {
  cancelJob(job.id);
  for (const c of store.list('clips', (c) => c.jobId === job.id)) deleteClipData(c);
  rmrf(path.join(paths.work, job.id));
  rmrf(path.join(paths.clips, `${job.id}.jpg`));
  if (job.videoPath && path.resolve(job.videoPath).startsWith(path.resolve(paths.uploads) + path.sep)) rmrf(job.videoPath);
  for (const f of safeReaddir(paths.uploads)) if (f.startsWith(`${job.id}.`)) rmrf(path.join(paths.uploads, f));
  store.remove('jobs', job.id);
}

export function deleteClipData(clip) {
  cancelClipRender(clip.id);
  rmrf(path.join(paths.clips, `${clip.id}.mp4`));
  rmrf(path.join(paths.clips, `${clip.id}.jpg`));
  rmrf(path.join(paths.work, clip.jobId, 'render', `${clip.id}.ass`));
  rmrf(path.join(paths.work, clip.jobId, 'render', `${clip.id}.graph.txt`));
  rmrf(path.join(paths.work, clip.jobId, 'render', `${clip.id}.tmp.mp4`));
  store.remove('clips', clip.id);
  const job = store.get('jobs', clip.jobId);
  if (job?.clipIds?.includes(clip.id)) store.update('jobs', job.id, { clipIds: job.clipIds.filter((id) => id !== clip.id) });
}

function safeReaddir(d) { try { return fs.readdirSync(d); } catch { return []; } }

/** After a restart: re-queue jobs that were mid-flight and re-render interrupted clips. */
export function resumeJobs() {
  const jobs = store.list('jobs').reverse(); // oldest first
  const resumed = new Set();
  for (const j of jobs) {
    if (ACTIVE_STATUSES.includes(j.status)) {
      store.update('jobs', j.id, { status: 'queued', stage: 'Resuming after restart…' });
      enqueueJob(j.id);
      resumed.add(j.id);
    }
  }
  for (const c of store.list('clips')) {
    if ((c.status === 'rendering' || c.status === 'pending') && !resumed.has(c.jobId)) {
      const job = store.get('jobs', c.jobId);
      if (!job) continue;
      if (job.status === 'done') requestClipRender(c.id);
      else store.update('clips', c.id, { status: c.file ? 'ready' : 'pending', progress: c.file ? 1 : 0 });
    }
  }
  if (resumed.size) console.log(`  ↻ resumed ${resumed.size} job(s)`);
}

export function queueSnapshot() {
  return { running: running?.jobId ?? null, queued: [...queue], rendering: [...clipRenders.keys()] };
}

