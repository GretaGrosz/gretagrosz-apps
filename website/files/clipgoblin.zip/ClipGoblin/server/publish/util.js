// Shared helpers for the publishing module: error type, fetch wrapper, PKCE, file chunk reads.
import crypto from 'node:crypto';
import fs from 'node:fs';

// transient = worth retrying later (network, 5xx, 429). Everything else is permanent.
export class PublishError extends Error {
  constructor(message, { transient = false, status, code, retryAfterMs, reconnect = false } = {}) {
    super(message);
    this.name = 'PublishError';
    this.transient = transient;
    this.status = status;
    this.code = code;
    this.retryAfterMs = retryAfterMs;
    this.reconnect = reconnect; // the stored tokens are no longer usable
  }
}

export const sleep = (ms, signal) =>
  new Promise((resolve, reject) => {
    if (signal?.aborted) return reject(abortError());
    const t = setTimeout(resolve, ms);
    signal?.addEventListener('abort', () => { clearTimeout(t); reject(abortError()); }, { once: true });
  });

function abortError() {
  const e = new Error('Canceled');
  e.name = 'AbortError';
  return e;
}

export function isTransientStatus(status) {
  return status === 429 || status === 408 || status >= 500;
}

export function retryAfter(res) {
  const v = res?.headers?.get?.('retry-after');
  if (!v) return undefined;
  const n = Number(v);
  if (Number.isFinite(n)) return n * 1000;
  const d = Date.parse(v);
  return Number.isFinite(d) ? Math.max(0, d - Date.now()) : undefined;
}

// fetch() that turns network failures into transient PublishErrors and leaves aborts alone.
export async function http(url, { label = 'server', ...init } = {}) {
  try {
    return await fetch(url, init);
  } catch (err) {
    if (err?.name === 'AbortError') throw err;
    throw new PublishError(`Network error talking to ${label}: ${err?.cause?.code || err?.message || err}`, {
      transient: true,
    });
  }
}

export async function readBody(res) {
  const text = await res.text().catch(() => '');
  if (!text) return {};
  try { return JSON.parse(text); } catch { return { _raw: text.slice(0, 500) }; }
}

export const form = (obj) => {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(obj)) if (v !== undefined && v !== null) p.set(k, String(v));
  return p;
};

export function randomToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString('base64url');
}

// RFC 7636 verifier: 43-128 chars of [A-Za-z0-9-._~]. base64url output fits.
export function pkceVerifier() {
  return randomToken(48); // 64 chars
}
export function pkceChallengeS256(verifier) {
  return crypto.createHash('sha256').update(verifier).digest('base64url');
}
// TikTok's desktop flow wants the hex digest instead of base64url.
export function pkceChallengeHex(verifier) {
  return crypto.createHash('sha256').update(verifier).digest('hex');
}

export async function readChunk(fd, start, length) {
  const buf = Buffer.alloc(length);
  let off = 0;
  while (off < length) {
    const { bytesRead } = await fd.read(buf, off, length - off, start + off);
    if (!bytesRead) break;
    off += bytesRead;
  }
  return off === length ? buf : buf.subarray(0, off);
}

export async function openFile(filePath) {
  return fs.promises.open(filePath, 'r');
}

export function isLocalhostUrl(u) {
  try {
    const h = new URL(u).hostname;
    return h === 'localhost' || h === '127.0.0.1' || h === '[::1]';
  } catch { return false; }
}
