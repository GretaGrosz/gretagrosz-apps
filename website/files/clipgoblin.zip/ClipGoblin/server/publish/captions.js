// Per-platform title/caption builders. Overrides from the publish request win over clip fields.

const chars = (s) => Array.from(s ?? '');
const clampChars = (s, n) => {
  const a = chars(s);
  return a.length <= n ? s : a.slice(0, Math.max(0, n - 1)).join('').trimEnd() + '…';
};
// TikTok counts UTF-16 code units.
const clampUtf16 = (s, n) => {
  if (s.length <= n) return s;
  let out = s.slice(0, n - 1);
  if (/[\uD800-\uDBFF]$/.test(out)) out = out.slice(0, -1);
  return out.trimEnd() + '…';
};

export function normalizeHashtags(list) {
  const seen = new Set();
  const out = [];
  for (const raw of Array.isArray(list) ? list : String(list ?? '').split(/[\s,]+/)) {
    const tag = String(raw ?? '').replace(/^#+/, '').replace(/[^\p{L}\p{N}_]/gu, '');
    if (!tag) continue;
    const key = tag.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(`#${tag}`);
  }
  return out;
}

// Tags that are not already written inside `text`.
function missingTags(text, tags) {
  const lower = (text || '').toLowerCase();
  return tags.filter((t) => !new RegExp(`${t.toLowerCase()}(?![\\p{L}\\p{N}_])`, 'u').test(lower));
}

function joinParts(...parts) {
  return parts.map((p) => (p ?? '').trim()).filter(Boolean).join('\n\n');
}

// Caption text with hashtags appended, trimmed to `limit` while keeping as many hashtags as fit.
function captionWithTags(body, tags, limit, measure = (s) => s.length, clamp = clampUtf16) {
  let use = missingTags(body, tags);
  for (;;) {
    const tagLine = use.join(' ');
    const room = limit - (tagLine ? measure(tagLine) + 2 : 0);
    if (room >= Math.min(60, measure(body)) || !use.length) {
      return joinParts(room > 0 ? clamp(body, room) : '', tagLine);
    }
    use = use.slice(0, -1);
  }
}

const stripAngle = (s) => (s ?? '').replace(/[<>]/g, '');

export function buildMeta(platform, clip, overrides = {}) {
  const title = (overrides.title ?? clip.title ?? clip.hook ?? 'Clip').trim();
  const description = overrides.caption ?? clip.description ?? '';
  const tags = normalizeHashtags(clip.hashtags);

  if (platform === 'youtube') {
    // YouTube: title ≤100 chars including #Shorts; '<' and '>' are rejected.
    let ytTitle = stripAngle(title).replace(/\s+/g, ' ').trim() || 'Clip';
    const hasShorts = /#shorts\b/i.test(ytTitle);
    if (!hasShorts) ytTitle = `${clampChars(ytTitle, 100 - ' #Shorts'.length)} #Shorts`;
    else ytTitle = clampChars(ytTitle, 100);
    const ytTags = tags.some((t) => t.toLowerCase() === '#shorts') ? tags : [...tags, '#Shorts'];
    const desc = captionWithTags(stripAngle(description), ytTags, 4900, (s) => Buffer.byteLength(s), clampChars);
    return {
      title: ytTitle,
      caption: desc,
      // snippet.tags: plain keywords, ≤500 chars total
      keywords: tags.map((t) => t.slice(1)).reduce((acc, t) => {
        const len = acc.reduce((n, x) => n + x.length + 1, 0);
        return len + t.length <= 480 ? [...acc, t] : acc;
      }, []),
    };
  }

  if (platform === 'tiktok') {
    // TikTok's "title" field is the whole caption: ≤2200 UTF-16 units, hashtags inline.
    const body = overrides.caption != null ? overrides.caption : joinParts(title, description);
    return { title, caption: captionWithTags(body, tags, 2200) };
  }

  if (platform === 'instagram') {
    // Instagram: ≤2200 chars and at most 30 hashtags.
    const body = overrides.caption != null ? overrides.caption : joinParts(title, description);
    const inBody = (body.match(/#[\p{L}\p{N}_]+/gu) || []).length;
    const room = Math.max(0, 30 - inBody);
    return { title, caption: captionWithTags(body, missingTags(body, tags).slice(0, room), 2200, (s) => chars(s).length, clampChars) };
  }

  throw new Error(`unknown platform ${platform}`);
}
