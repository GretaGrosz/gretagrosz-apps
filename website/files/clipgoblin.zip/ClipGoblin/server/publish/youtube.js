// YouTube Shorts: Google OAuth (PKCE + offline refresh) and resumable chunked upload via Data API v3.
import { PublishError, http, readBody, form, isTransientStatus, retryAfter, readChunk, openFile, sleep, pkceChallengeS256 } from './util.js';

const AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth';
const TOKEN_URL = 'https://oauth2.googleapis.com/token';
const REVOKE_URL = 'https://oauth2.googleapis.com/revoke';
const API = 'https://www.googleapis.com/youtube/v3';
const UPLOAD_URL = 'https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status';
const SCOPES = ['https://www.googleapis.com/auth/youtube.upload', 'https://www.googleapis.com/auth/youtube.readonly'];
const CHUNK = 4 * 1024 * 1024; // must be a multiple of 256 KiB

const cfg = (s) => s.platforms?.youtube ?? {};

function apiError(res, body, what) {
  const e = body?.error;
  const reason = e?.errors?.[0]?.reason || (typeof e === 'string' ? e : undefined);
  const msg = e?.message || body?.error_description || body?._raw || `HTTP ${res.status}`;
  const known = {
    quotaExceeded: 'YouTube API daily quota is used up for this Google Cloud project. Try again after midnight Pacific time.',
    uploadLimitExceeded: 'This YouTube channel hit its upload limit. Try again later.',
    youtubeSignupRequired: 'This Google account has no YouTube channel yet. Create one at youtube.com, then reconnect.',
    forbidden: 'YouTube refused the upload (forbidden). Check the channel is in good standing and the API is enabled.',
    invalid_grant: 'YouTube access was revoked or expired. Reconnect YouTube in Settings. (Google OAuth apps in "Testing" mode expire refresh tokens after 7 days; publishing the consent screen avoids this.)',
    accessNotConfigured: 'YouTube Data API v3 is not enabled for this Google Cloud project. Enable it in the API Library.',
  };
  const reconnect = reason === 'invalid_grant' || res.status === 401;
  return new PublishError(known[reason] ?? `YouTube ${what} failed: ${msg}`, {
    transient: isTransientStatus(res.status) && reason !== 'quotaExceeded',
    status: res.status,
    code: reason,
    retryAfterMs: retryAfter(res),
    reconnect,
  });
}

async function tokenRequest(params) {
  const res = await http(TOKEN_URL, { label: 'Google', method: 'POST', body: form(params) });
  const body = await readBody(res);
  if (!res.ok) throw apiError(res, body, 'sign-in');
  return body;
}

export default {
  id: 'youtube',
  label: 'YouTube',

  isConfigured: (s) => Boolean(cfg(s).clientId && cfg(s).clientSecret),

  authorizeUrl({ settings, redirectUri, state, verifier }) {
    const u = new URL(AUTH_URL);
    u.search = form({
      client_id: cfg(settings).clientId,
      redirect_uri: redirectUri,
      response_type: 'code',
      scope: SCOPES.join(' '),
      access_type: 'offline',
      prompt: 'consent',
      include_granted_scopes: 'true',
      state,
      code_challenge: pkceChallengeS256(verifier),
      code_challenge_method: 'S256',
    }).toString();
    return u.toString();
  },

  async exchangeCode({ settings, code, redirectUri, verifier }) {
    const t = await tokenRequest({
      code,
      client_id: cfg(settings).clientId,
      client_secret: cfg(settings).clientSecret,
      redirect_uri: redirectUri,
      grant_type: 'authorization_code',
      code_verifier: verifier,
    });
    if (!t.refresh_token) {
      // prompt=consent should always return one; without it we can't post unattended.
      throw new PublishError('Google did not return a refresh token. Remove ClipGoblin from myaccount.google.com/permissions and connect again.');
    }
    return {
      access_token: t.access_token,
      refresh_token: t.refresh_token,
      expires_at: Date.now() + (t.expires_in ?? 3600) * 1000,
      scope: t.scope,
    };
  },

  needsRefresh: (rec) => !rec.expires_at || rec.expires_at - Date.now() < 5 * 60 * 1000,

  async refresh(rec, settings) {
    if (!rec.refresh_token) throw new PublishError('YouTube connection has no refresh token. Reconnect YouTube.', { reconnect: true });
    const t = await tokenRequest({
      client_id: cfg(settings).clientId,
      client_secret: cfg(settings).clientSecret,
      refresh_token: rec.refresh_token,
      grant_type: 'refresh_token',
    });
    return {
      access_token: t.access_token,
      refresh_token: t.refresh_token || rec.refresh_token,
      expires_at: Date.now() + (t.expires_in ?? 3600) * 1000,
    };
  },

  async fetchProfile(rec) {
    const res = await http(`${API}/channels?part=snippet&mine=true`, {
      label: 'YouTube',
      headers: { Authorization: `Bearer ${rec.access_token}` },
    });
    const body = await readBody(res);
    if (!res.ok) throw apiError(res, body, 'channel lookup');
    const ch = body.items?.[0];
    if (!ch) return { name: null, avatar: null, id: null, warning: 'This Google account has no YouTube channel yet. Create one on youtube.com before publishing.' };
    const th = ch.snippet?.thumbnails ?? {};
    return {
      id: ch.id,
      name: ch.snippet?.title ?? null,
      avatar: (th.default || th.medium || th.high)?.url ?? null,
      url: ch.snippet?.customUrl ? `https://youtube.com/${ch.snippet.customUrl}` : `https://youtube.com/channel/${ch.id}`,
    };
  },

  async revoke(rec) {
    const token = rec.refresh_token || rec.access_token;
    if (token) await http(`${REVOKE_URL}?token=${encodeURIComponent(token)}`, { label: 'Google', method: 'POST' }).catch(() => {});
  },

  note(settings) {
    const notes = [];
    notes.push('Google Cloud projects that have not passed YouTube\'s API audit can only upload as Private, whatever privacy you choose; request an audit (YouTube API Services audit form) to post publicly.');
    notes.push('While the OAuth consent screen is in "Testing", Google expires the connection after 7 days. Reconnect weekly or publish the app.');
    if (cfg(settings).privacy && cfg(settings).privacy !== 'public') notes.push(`Uploads are set to ${cfg(settings).privacy}.`);
    return notes.join(' ');
  },

  setup(redirectUri) {
    return [
      'Open console.cloud.google.com and create (or pick) a project.',
      'APIs & Services → Library → search "YouTube Data API v3" → Enable.',
      'Google Auth Platform (OAuth consent screen) → Get started: app name, your email, Audience "External". Under Audience → Test users, add the Google account that owns your channel.',
      'Data Access → Add or remove scopes → add ".../auth/youtube.upload" and ".../auth/youtube.readonly".',
      'Clients → Create client → Application type "Web application".',
      `Under "Authorized redirect URIs" add exactly: ${redirectUri}`,
      'Create, then paste the Client ID and Client secret into ClipGoblin Settings → YouTube and click Connect.',
      'Optional: to post publicly instead of private-only, submit the YouTube API Services audit form for the project.',
    ];
  },

  // Resumable upload: one session, file streamed from disk in 4 MiB chunks.
  async publish({ token, filePath, size, meta, settings, onProgress, signal }) {
    const auth = { Authorization: `Bearer ${token.access_token}` };
    const privacy = ['public', 'unlisted', 'private'].includes(cfg(settings).privacy) ? cfg(settings).privacy : 'public';
    const res = await http(UPLOAD_URL, {
      label: 'YouTube',
      method: 'POST',
      signal,
      headers: {
        ...auth,
        'Content-Type': 'application/json; charset=UTF-8',
        'X-Upload-Content-Length': String(size),
        'X-Upload-Content-Type': 'video/mp4',
      },
      body: JSON.stringify({
        snippet: { title: meta.title, description: meta.caption, tags: meta.keywords, categoryId: '20' },
        status: { privacyStatus: privacy, selfDeclaredMadeForKids: false, embeddable: true },
      }),
    });
    if (!res.ok) throw apiError(res, await readBody(res), 'upload start');
    const sessionUrl = res.headers.get('location');
    await res.body?.cancel?.();
    if (!sessionUrl) throw new PublishError('YouTube did not return an upload session URL.', { transient: true });

    const finish = (video) => {
      if (!video.id) throw new PublishError('YouTube finished the upload but returned no video id.');
      onProgress(1);
      return {
        remoteId: video.id,
        url: `https://youtube.com/shorts/${video.id}`,
        note: video.status?.privacyStatus && video.status.privacyStatus !== privacy
          ? `YouTube set this video to ${video.status.privacyStatus} (unaudited API projects can only upload private videos).`
          : undefined,
      };
    };

    const fd = await openFile(filePath);
    try {
      let offset = 0;
      let failures = 0;
      for (;;) {
        const len = Math.min(CHUNK, size - offset);
        const chunk = await readChunk(fd, offset, len);
        let r;
        try {
          r = await http(sessionUrl, {
            label: 'YouTube',
            method: 'PUT',
            signal,
            headers: {
              ...auth,
              'Content-Length': String(chunk.length),
              'Content-Type': 'video/mp4',
              'Content-Range': `bytes ${offset}-${offset + chunk.length - 1}/${size}`,
            },
            body: chunk,
          });
        } catch (err) {
          if (!(err instanceof PublishError) || !err.transient || ++failures > 4) throw err;
          await sleep(1000 * 2 ** failures, signal);
          const q = await resume(sessionUrl, auth, size, signal);
          if (q.video) return finish(q.video);
          offset = q.offset;
          continue;
        }
        if (r.status === 200 || r.status === 201) return finish(await readBody(r));
        if (r.status === 308) {
          await r.body?.cancel?.();
          offset = nextOffset(r.headers.get('range'));
          failures = 0;
          onProgress(offset / size);
          continue;
        }
        const body = await readBody(r);
        if (isTransientStatus(r.status) && ++failures <= 4) {
          await sleep(1000 * 2 ** failures, signal);
          const q = await resume(sessionUrl, auth, size, signal);
          if (q.video) return finish(q.video);
          offset = q.offset;
          continue;
        }
        throw apiError(r, body, 'upload');
      }
    } finally {
      await fd.close();
    }
  },
};

function nextOffset(range) {
  // "bytes=0-4194303" → next byte is 4194304; no header = nothing stored yet.
  const m = /bytes=\d+-(\d+)/.exec(range || '');
  return m ? Number(m[1]) + 1 : 0;
}

async function resume(sessionUrl, auth, size, signal) {
  try {
    return { offset: await queryOffset(sessionUrl, auth, size, signal) };
  } catch (err) {
    if (err.video) return { video: err.video };
    throw err;
  }
}

async function queryOffset(sessionUrl, auth, size, signal) {
  const r = await http(sessionUrl, {
    label: 'YouTube',
    method: 'PUT',
    signal,
    headers: { ...auth, 'Content-Length': '0', 'Content-Range': `bytes */${size}` },
  });
  if (r.status === 200 || r.status === 201) {
    // The last chunk actually landed before the connection dropped.
    const video = await readBody(r);
    if (video.id) throw Object.assign(new Error('done'), { video });
  }
  await r.body?.cancel?.();
  if (r.status === 308) return nextOffset(r.headers.get('range'));
  if (r.status === 404 || r.status === 410) {
    throw new PublishError('YouTube upload session expired.', { transient: true, status: r.status });
  }
  throw new PublishError(`YouTube upload status check failed (HTTP ${r.status}).`, { transient: isTransientStatus(r.status), status: r.status });
}
