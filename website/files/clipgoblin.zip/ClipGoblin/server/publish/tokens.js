// OAuth token persistence (paths.tokens), CSRF state bookkeeping and refresh-before-expiry.
import fs from 'node:fs';
import { paths, writeJsonAtomic } from '../config.js';
import { PublishError } from './util.js';

let cache = null;

function load() {
  if (!cache) {
    try { cache = JSON.parse(fs.readFileSync(paths.tokens, 'utf8')) || {}; } catch { cache = {}; }
  }
  return cache;
}

export function getRecord(platform) {
  return load()[platform] ?? null;
}

export function setRecord(platform, record) {
  const all = load();
  if (record) all[platform] = record;
  else delete all[platform];
  writeJsonAtomic(paths.tokens, all);
  return record;
}

export function patchRecord(platform, patch) {
  const cur = getRecord(platform);
  if (!cur) return null;
  return setRecord(platform, { ...cur, ...patch });
}

export function isConnected(platform) {
  const r = getRecord(platform);
  return Boolean(r?.access_token && !r.needsReconnect);
}

// ---- CSRF state (in memory; an OAuth round trip never spans a server restart) ----
const STATE_TTL = 15 * 60 * 1000;
const pending = new Map();

export function rememberState(state, data) {
  const now = Date.now();
  for (const [k, v] of pending) if (now - v.createdAt > STATE_TTL) pending.delete(k);
  pending.set(state, { ...data, createdAt: now });
}

export function consumeState(state) {
  const v = state ? pending.get(state) : null;
  if (!v) return null;
  pending.delete(state);
  return Date.now() - v.createdAt > STATE_TTL ? null : v;
}

// ---- access tokens with automatic refresh ----
const refreshing = new Map();

// Returns a token record whose access_token is valid for at least a few minutes.
export async function getAccessToken(mod, settings, { force = false } = {}) {
  const rec = getRecord(mod.id);
  if (!rec?.access_token) {
    throw new PublishError(`${mod.label} is not connected. Connect it in Settings first.`, { reconnect: true });
  }
  if (rec.needsReconnect) {
    throw new PublishError(`${mod.label} connection expired. Reconnect it in Settings.`, { reconnect: true });
  }
  if (!force && !mod.needsRefresh(rec)) return rec;
  if (!refreshing.has(mod.id)) {
    const p = (async () => {
      try {
        const next = await mod.refresh(rec, settings);
        return setRecord(mod.id, { ...rec, ...next, refreshedAt: Date.now() });
      } catch (err) {
        if (err instanceof PublishError && err.reconnect) {
          setRecord(mod.id, { ...rec, needsReconnect: true, lastError: err.message });
        }
        // A token that is still valid is usable even if the early refresh failed transiently.
        if (!(err instanceof PublishError && err.reconnect) && rec.expires_at && rec.expires_at > Date.now() + 60_000) {
          return rec;
        }
        throw err;
      } finally {
        refreshing.delete(mod.id);
      }
    })();
    refreshing.set(mod.id, p);
  }
  return refreshing.get(mod.id);
}

// Test hook: forget cached file contents.
export function _resetTokenCache() {
  cache = null;
  pending.clear();
}
