/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          950: '#060609',
          900: '#0a0a0f',
          850: '#0f0f16',
          800: '#14141d',
          750: '#1a1a25',
          700: '#21212e',
          600: '#2c2c3c',
          500: '#3b3b4f',
        },
        goblin: { 200: '#e8ffb0', 300: '#d6ff73', 400: '#c6ff3d', 500: '#a6e80b', 600: '#7fb800' },
        hex: { 300: '#c4b5fd', 400: '#a78bfa', 500: '#8b5cf6', 600: '#7c3aed', 700: '#6d28d9' },
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'Segoe UI', 'sans-serif'],
        display: ['"Bricolage Grotesque"', 'Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
      },
      boxShadow: {
        glow: '0 0 0 1px rgba(198,255,61,.25), 0 8px 40px -8px rgba(198,255,61,.35)',
        'glow-hex': '0 0 0 1px rgba(139,92,246,.3), 0 8px 40px -8px rgba(139,92,246,.45)',
        card: '0 1px 0 0 rgba(255,255,255,.04) inset, 0 10px 30px -12px rgba(0,0,0,.6)',
      },
      keyframes: {
        shimmer: { '0%': { transform: 'translateX(-100%)' }, '100%': { transform: 'translateX(100%)' } },
        float: { '0%,100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-6px)' } },
        'pulse-ring': { '0%': { transform: 'scale(.8)', opacity: '.8' }, '100%': { transform: 'scale(2.2)', opacity: '0' } },
        'gradient-x': { '0%,100%': { backgroundPosition: '0% 50%' }, '50%': { backgroundPosition: '100% 50%' } },
        blink: { '0%,92%,100%': { transform: 'scaleY(1)' }, '95%': { transform: 'scaleY(.1)' } },
      },
      animation: {
        shimmer: 'shimmer 1.6s ease-in-out infinite',
        float: 'float 4s ease-in-out infinite',
        'pulse-ring': 'pulse-ring 1.8s cubic-bezier(.2,.6,.4,1) infinite',
        'gradient-x': 'gradient-x 6s ease infinite',
        blink: 'blink 5s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};
