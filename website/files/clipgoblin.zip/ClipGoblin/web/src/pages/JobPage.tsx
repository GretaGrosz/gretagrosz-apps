import clsx from 'clsx';
import { AnimatePresence, motion } from 'framer-motion';
import { AlertTriangle, ArrowLeft, CheckSquare, ExternalLink, RotateCcw, Send, Sparkles, Trash2, X } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { EmptyState, Modal } from '../components/Chrome';
import { ClipCard } from '../components/ClipCard';
import { AnalyzerBadge, SourceIcon, StatusPill, Thumb } from '../components/JobCard';
import { PipelineStepper } from '../components/Pipeline';
import { PublishForm } from '../components/Publish';
import { ProgressBar, Segmented, Skeleton } from '../components/ui';
import { api, errMsg } from '../lib/api';
import { fmtDuration, timeAgo } from '../lib/format';
import { isActive, JOB_STATUS_LABEL } from '../lib/meta';
import { toast, useStore } from '../lib/store';

export default function JobPage() {
  const { id = '' } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const job = useStore((s) => s.jobs[id]);
  const clipsMap = useStore((s) => s.clips);
  const [loading, setLoading] = useState(!job);
  const [notFound, setNotFound] = useState(false);
  const [sort, setSort] = useState<'rank' | 'time'>('rank');
  const [selected, setSelected] = useState<string[]>([]);
  const [publishOpen, setPublishOpen] = useState(false);

  useEffect(() => {
    let alive = true;
    useStore
      .getState()
      .loadJob(id)
      .catch((err) => {
        if (alive && /404|not found/i.test(errMsg(err))) setNotFound(true);
      })
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, [id]);

  // When the job finishes, refetch so we have every clip in its final state.
  const status = job?.status;
  useEffect(() => {
    if (status === 'done') void useStore.getState().loadJob(id).catch(() => {});
  }, [status, id]);

  const clips = useMemo(() => {
    const list = Object.values(clipsMap).filter((c) => c.jobId === id);
    return list.sort((a, b) => (sort === 'rank' ? (a.rank ?? 99) - (b.rank ?? 99) : a.start - b.start));
  }, [clipsMap, id, sort]);

  if (notFound || (!loading && !job))
    return (
      <div className="mx-auto max-w-xl px-4 py-20">
        <EmptyState
          mood="hunt"
          title="This VOD wandered off"
          body="The goblin can't find that job. It may have been deleted."
          action={
            <Link to="/" className="btn btn-primary">
              Back to the hoard
            </Link>
          }
        />
      </div>
    );

  if (!job)
    return (
      <div className="mx-auto max-w-7xl space-y-6 px-4 py-8 sm:px-6">
        <Skeleton className="h-24" />
        <Skeleton className="h-20" />
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {[0, 1, 2, 3].map((i) => (
            <Skeleton key={i} className="aspect-[9/16]" />
          ))}
        </div>
      </div>
    );

  const active = isActive(job);
  const readyIds = clips.filter((c) => c.status === 'ready').map((c) => c.id);
  const allSelected = readyIds.length > 0 && readyIds.every((x) => selected.includes(x));
  const avgScore = clips.length ? Math.round(clips.reduce((a, c) => a + (c.score || 0), 0) / clips.length) : 0;

  const toggle = (cid: string) => setSelected((s) => (s.includes(cid) ? s.filter((x) => x !== cid) : [...s, cid]));
  const openClip = (cid: string) => navigate(`/clips/${cid}`, { state: { backgroundLocation: location } });

  const onDelete = async () => {
    if (!confirm(active ? 'Stop and delete this VOD and all its clips?' : 'Delete this VOD and all its clips?')) return;
    try {
      await api.deleteJob(job.id);
      useStore.getState().removeJob(job.id);
      toast.info('Job deleted');
      navigate('/');
    } catch (err) {
      toast.error('Could not delete', errMsg(err));
    }
  };
  const onCancel = async () => {
    if (!confirm('Stop processing this VOD? Clips rendered so far are kept.')) return;
    try {
      const j = await api.cancelJob(job.id);
      if (j && j.id) useStore.getState().upsertJob(j);
      toast.info('Job canceled');
    } catch (err) {
      toast.error('Could not cancel', errMsg(err));
    }
  };
  const onRetry = async () => {
    try {
      useStore.getState().upsertJob(await api.retryJob(job.id));
      toast.goblin('Back to work', 'Retrying this VOD.');
    } catch (err) {
      toast.error('Retry failed', errMsg(err));
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 pb-32 pt-6 sm:px-6 sm:pt-8">
      <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-zinc-400 transition hover:text-white">
        <ArrowLeft className="h-4 w-4" /> All VODs
      </Link>

      {/* Header */}
      <div className="mt-4 flex flex-col gap-4 sm:flex-row sm:items-center">
        <div className="flex min-w-0 flex-1 items-center gap-4">
          <Thumb src={job.thumb} className="aspect-video w-28 shrink-0 rounded-xl ring-1 ring-white/10 sm:w-44 sm:rounded-2xl" />
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <StatusPill job={job} />
              <AnalyzerBadge analyzer={job.analyzer} />
            </div>
            <h1 className="mt-2 line-clamp-2 break-words font-display text-lg font-extrabold leading-tight tracking-tight text-white sm:text-3xl">
              {job.source?.name || 'Untitled VOD'}
            </h1>
            <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-zinc-500 sm:text-sm">
              <span className="flex items-center gap-1.5">
                <SourceIcon job={job} />
                {job.source?.type === 'url' ? 'Link' : 'Upload'}
              </span>
              {job.durationSec ? <span>{fmtDuration(job.durationSec)} long</span> : null}
              <span>Added {timeAgo(job.createdAt)}</span>
              {job.source?.url && (
                <a href={job.source.url} target="_blank" rel="noreferrer" className="flex items-center gap-1 hover:text-zinc-300">
                  Source <ExternalLink className="h-3 w-3" />
                </a>
              )}
            </div>
          </div>
        </div>
        <div className="flex gap-2 self-end sm:self-auto">
          {(job.status === 'error' || job.status === 'canceled') && (
            <button className="btn btn-sm btn-outline" onClick={onRetry}>
              <RotateCcw className="h-4 w-4" /> Retry
            </button>
          )}
          {active && (
            <button className="btn btn-sm btn-outline" onClick={onCancel}>
              <X className="h-4 w-4" /> Cancel
            </button>
          )}
          <button className="btn btn-sm text-zinc-400 hover:bg-white/[0.06] hover:text-rose-300" onClick={onDelete}>
            <Trash2 className="h-4 w-4" /> Delete
          </button>
        </div>
      </div>

      {/* Pipeline */}
      <section className="mt-6">
        <PipelineStepper job={job} />
        <AnimatePresence initial={false}>
          {active && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <div className="panel mt-3 p-4 sm:p-5">
                <div className="flex items-baseline justify-between gap-4">
                  <div className="min-w-0">
                    <div className="text-xs font-medium uppercase tracking-wider text-hex-300">{JOB_STATUS_LABEL[job.status]}</div>
                    <div className="mt-1 truncate text-[15px] font-medium text-zinc-200">{job.stage || 'Warming up…'}</div>
                  </div>
                  <div className="font-display text-3xl font-extrabold text-white tabular">{Math.round((job.progress || 0) * 100)}%</div>
                </div>
                <ProgressBar value={job.progress} indeterminate={job.status === 'queued'} className="mt-4 !h-2" />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        {job.status === 'error' && (
          <div className="mt-3 flex items-start gap-3 rounded-2xl border border-rose-500/25 bg-rose-500/[0.06] p-4 text-sm text-rose-200">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
            <div className="min-w-0 flex-1">
              <div className="font-semibold">The goblin tripped</div>
              <div className="mt-0.5 break-words text-rose-200/80">{job.error || 'Unknown error'}</div>
            </div>
          </div>
        )}
      </section>

      {/* Clips */}
      <section className="mt-10">
        <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 className="flex items-center gap-2 font-display text-xl font-bold text-white">
              <Sparkles className="h-5 w-5 text-goblin-400" />
              {clips.length ? `${clips.length} clip${clips.length === 1 ? '' : 's'}` : 'Clips'}
            </h2>
            {clips.length > 0 && (
              <p className="mt-0.5 text-sm text-zinc-500">
                Avg score <span className="font-semibold text-zinc-300">{avgScore}</span>
                <span className="hidden sm:inline"> · hover to preview, click to edit</span>
                <span className="sm:hidden"> · tap to play, ⤢ to edit</span>
              </p>
            )}
          </div>
          {clips.length > 0 && (
            <div className="flex items-center gap-2">
              <button
                className={clsx('btn btn-sm', allSelected ? 'btn-outline border-goblin-400/40 text-goblin-300' : 'btn-outline')}
                onClick={() => setSelected(allSelected ? [] : readyIds)}
                disabled={!readyIds.length}
              >
                <CheckSquare className="h-3.5 w-3.5" /> {allSelected ? 'Clear' : 'Select all'}
              </button>
              <Segmented
                size="sm"
                value={sort}
                onChange={setSort}
                options={[
                  { value: 'rank', label: 'Best first' },
                  { value: 'time', label: 'Timeline' },
                ]}
              />
            </div>
          )}
        </div>

        {clips.length === 0 ? (
          active ? (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4 xl:grid-cols-5">
              {[0, 1, 2, 3, 4].map((i) => (
                <div
                  key={i}
                  className={clsx(
                    'relative aspect-[9/16] overflow-hidden rounded-2xl border border-dashed border-white/[0.08] bg-ink-850/40',
                    i === 3 && 'hidden lg:block',
                    i === 4 && 'hidden xl:block',
                  )}
                >
                  <Skeleton className="absolute inset-0 rounded-none bg-transparent" />
                  {i === 0 && (
                    <div className="absolute inset-0 grid place-items-center p-4 text-center text-xs text-zinc-500">
                      Clips appear here as soon as they're found.
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <EmptyState
              mood="hunt"
              title={job.status === 'done' ? 'No clip-worthy moments found' : 'No clips yet'}
              body={
                job.status === 'done'
                  ? 'Try lowering the minimum length or turning on chaos mode, then retry.'
                  : 'Retry the job to have another go.'
              }
            />
          )
        ) : (
          <motion.div layout className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4 xl:grid-cols-5">
            {clips.map((c, i) => (
              <ClipCard
                key={c.id}
                clip={c}
                index={i}
                selected={selected.includes(c.id)}
                onToggleSelect={c.status === 'ready' ? () => toggle(c.id) : undefined}
                onOpen={() => openClip(c.id)}
              />
            ))}
          </motion.div>
        )}
      </section>

      {/* Bulk bar */}
      <AnimatePresence>
        {selected.length > 0 && (
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 400, damping: 34 }}
            className="fixed inset-x-0 bottom-[76px] z-30 flex justify-center px-4 md:bottom-6"
          >
            <div className="flex w-full max-w-lg items-center gap-2 rounded-2xl border border-white/10 bg-ink-800/95 p-2 pl-4 shadow-2xl backdrop-blur-xl">
              <div className="grid h-7 min-w-7 place-items-center rounded-lg bg-goblin-400 px-1.5 font-display text-sm font-extrabold text-ink-950">
                {selected.length}
              </div>
              <span className="flex-1 truncate text-sm font-medium text-zinc-200">selected</span>
              <button className="btn btn-sm btn-ghost" onClick={() => setSelected([])}>
                <X className="h-3.5 w-3.5" /> <span className="hidden sm:inline">Clear</span>
              </button>
              <button className="btn btn-primary" onClick={() => setPublishOpen(true)}>
                <Send className="h-4 w-4" /> Publish…
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <Modal open={publishOpen} onClose={() => setPublishOpen(false)}>
        <div className="p-5 sm:p-6">
          <div className="mb-5 flex items-start justify-between">
            <div>
              <h3 className="font-display text-xl font-bold text-white">
                Publish {selected.length} clip{selected.length === 1 ? '' : 's'}
              </h3>
              <p className="mt-0.5 text-sm text-zinc-400">Each clip posts with its own title, caption and hashtags.</p>
            </div>
            <button className="rounded-lg p-1.5 text-zinc-500 hover:bg-white/5 hover:text-white" onClick={() => setPublishOpen(false)} aria-label="Close">
              <X className="h-5 w-5" />
            </button>
          </div>
          <PublishForm
            clipIds={[...selected].sort((a, b) => (clipsMap[a]?.rank ?? 99) - (clipsMap[b]?.rank ?? 99))}
            onDone={() => {
              setPublishOpen(false);
              setSelected([]);
            }}
          />
        </div>
      </Modal>
    </div>
  );
}
