import clsx from 'clsx';
import { motion } from 'framer-motion';
import { AudioLines, Check, Clapperboard, Download, ScanSearch, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { PIPELINE_STEPS, PLATFORM_META, stepIndex } from '../lib/meta';
import { useStore } from '../lib/store';
import type { Job, Platform } from '../lib/types';
import { PLATFORMS } from '../lib/types';
import { PlatformIcon } from './Brand';

const ICONS = [Download, AudioLines, ScanSearch, Clapperboard];

export function PipelineStepper({ job }: { job: Job }) {
  const current = stepIndex(job.status);
  const failed = job.status === 'error' || job.status === 'canceled';
  // Best guess at where a failed job died, from its stage text.
  const failedAt = failed
    ? Math.max(
        0,
        ['download', 'transcrib', 'moment|analy', 'render'].findIndex((k) => new RegExp(k, 'i').test(job.stage || '')),
      )
    : -1;

  return (
    <div className="grid grid-cols-4 gap-1.5 sm:gap-3">
      {PIPELINE_STEPS.map((s, i) => {
        const Icon = ICONS[i];
        const done = current > i;
        const active = current === i;
        const dead = failed && i === failedAt;
        const label = i === 0 ? (job.source?.type === 'file' ? 'Import' : 'Download') : s.label;
        return (
          <div key={s.key} className="relative">
            <div
              className={clsx(
                'relative flex h-full flex-col items-center gap-2 overflow-hidden rounded-2xl border px-1 py-3 text-center transition-all duration-500 sm:flex-row sm:px-3.5 sm:text-left',
                done && 'border-goblin-400/25 bg-goblin-400/[0.05]',
                active && 'border-hex-400/40 bg-hex-500/[0.08] shadow-glow-hex',
                dead && 'border-rose-500/40 bg-rose-500/[0.07]',
                !done && !active && !dead && 'border-white/[0.06] bg-ink-850/50',
              )}
            >
              {active && (
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-hex-400/10 to-transparent"
                  animate={{ x: ['-100%', '100%'] }}
                  transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut' }}
                />
              )}
              <div
                className={clsx(
                  'relative grid h-9 w-9 shrink-0 place-items-center rounded-xl transition-colors',
                  done && 'bg-goblin-400 text-ink-950',
                  active && 'bg-hex-500 text-white',
                  dead && 'bg-rose-500 text-white',
                  !done && !active && !dead && 'bg-white/5 text-zinc-500',
                )}
              >
                {done ? <Check className="h-4 w-4" strokeWidth={3} /> : dead ? <X className="h-4 w-4" strokeWidth={3} /> : <Icon className="h-4 w-4" />}
                {active && <span className="absolute inset-0 animate-pulse-ring rounded-xl border-2 border-hex-400" />}
              </div>
              <div className="relative min-w-0">
                <div
                  className={clsx(
                    'text-[11px] font-semibold leading-tight sm:text-sm',
                    done ? 'text-goblin-200' : active ? 'text-white' : dead ? 'text-rose-300' : 'text-zinc-500',
                  )}
                >
                  {label}
                </div>
                <div className="hidden text-[11px] text-zinc-500 sm:block">
                  {done ? 'Done' : active ? (job.status === 'queued' ? 'Queued' : 'In progress') : dead ? 'Failed' : 'Waiting'}
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

/** Platform toggle row. Unconnected platforms are disabled with a Connect link. */
export function PlatformPicker({
  value,
  onChange,
  requireConnected = true,
  className,
}: {
  value: Platform[];
  onChange: (v: Platform[]) => void;
  requireConnected?: boolean;
  className?: string;
}) {
  const accounts = useStore((s) => s.accounts);
  return (
    <div className={clsx('grid gap-2', className ?? 'grid-cols-1 sm:grid-cols-3')}>
      {PLATFORMS.map((p) => {
        const acc = accounts?.[p];
        const connected = !!acc?.connected;
        const disabled = requireConnected && !connected;
        const on = value.includes(p) && !disabled;
        return (
          <div
            key={p}
            role="button"
            tabIndex={disabled ? -1 : 0}
            aria-pressed={on}
            onClick={() => !disabled && onChange(on ? value.filter((x) => x !== p) : [...value, p])}
            onKeyDown={(e) => {
              if (!disabled && (e.key === 'Enter' || e.key === ' ')) {
                e.preventDefault();
                onChange(on ? value.filter((x) => x !== p) : [...value, p]);
              }
            }}
            className={clsx(
              'flex items-center gap-2.5 rounded-xl border px-3 py-2.5 transition-all',
              disabled ? 'cursor-default border-white/[0.05] bg-ink-950/30' : 'cursor-pointer',
              on ? 'border-goblin-400/50 bg-goblin-400/[0.06]' : !disabled && 'border-white/[0.08] bg-ink-950/40 hover:border-white/20',
            )}
          >
            <PlatformIcon platform={p} className={clsx('h-5 w-5', disabled && 'opacity-40 grayscale')} />
            <div className="min-w-0 flex-1">
              <div className={clsx('truncate text-[13px] font-semibold', disabled ? 'text-zinc-500' : 'text-zinc-100')}>
                {PLATFORM_META[p].short}
              </div>
              {connected && acc?.name ? (
                <div className="truncate text-[11px] text-zinc-500">{acc.name}</div>
              ) : disabled ? (
                <Link to="/settings#connections" onClick={(e) => e.stopPropagation()} className="text-[11px] font-medium text-goblin-400 hover:underline">
                  Connect →
                </Link>
              ) : null}
            </div>
            {!disabled && (
              <span
                className={clsx(
                  'grid h-5 w-5 shrink-0 place-items-center rounded-md border-2 transition',
                  on ? 'border-goblin-400 bg-goblin-400 text-ink-950' : 'border-white/20',
                )}
              >
                {on && <Check className="h-3 w-3" strokeWidth={3.5} />}
              </span>
            )}
          </div>
        );
      })}
    </div>
  );
}
