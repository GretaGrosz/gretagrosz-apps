import { create } from 'zustand';
import { api, errMsg } from './api';
import type { Accounts, Clip, Job, Publication, Settings, SSEMessage, SystemInfo } from './types';

export type ToastKind = 'success' | 'error' | 'info' | 'goblin';
export interface Toast {
  id: number;
  kind: ToastKind;
  title: string;
  body?: string;
}

export type SseState = 'connecting' | 'live' | 'reconnecting';

interface State {
  jobs: Record<string, Job>;
  clips: Record<string, Clip>;
  publications: Record<string, Publication>;
  settings: Settings | null;
  accounts: Accounts | null;
  system: SystemInfo | null;
  sse: SseState;
  toasts: Toast[];
  loaded: { jobs: boolean; publications: boolean; clips: boolean };

  setSse: (s: SseState) => void;
  apply: (msg: SSEMessage) => void;
  upsertJob: (j: Job) => void;
  upsertClips: (c: Clip[]) => void;
  upsertPublications: (p: Publication[]) => void;
  removeJob: (id: string) => void;

  loadJobs: () => Promise<void>;
  loadJob: (id: string) => Promise<void>;
  loadClips: () => Promise<void>;
  loadPublications: () => Promise<void>;
  loadSettings: () => Promise<void>;
  loadAccounts: () => Promise<void>;
  loadSystem: () => Promise<void>;
  setSettings: (s: Settings) => void;

  toast: (t: Omit<Toast, 'id'>) => void;
  dismiss: (id: number) => void;
}

let toastSeq = 1;
const idOf = (d: { id: string } | string) => (typeof d === 'string' ? d : d.id);
const byId = <T extends { id: string }>(arr: T[]) => Object.fromEntries(arr.map((x) => [x.id, x]));

export const useStore = create<State>((set, get) => ({
  jobs: {},
  clips: {},
  publications: {},
  settings: null,
  accounts: null,
  system: null,
  sse: 'connecting',
  toasts: [],
  loaded: { jobs: false, publications: false, clips: false },

  setSse: (sse) => set({ sse }),

  apply: (msg) => {
    switch (msg.type) {
      case 'job':
        return get().upsertJob(msg.data);
      case 'clip':
        return get().upsertClips([msg.data]);
      case 'publication':
        return get().upsertPublications([msg.data]);
      case 'job:removed':
        return get().removeJob(idOf(msg.data));
      case 'clip:removed': {
        const id = idOf(msg.data);
        return set((s) => {
          const clips = { ...s.clips };
          delete clips[id];
          return { clips };
        });
      }
      case 'publication:removed': {
        const id = idOf(msg.data);
        return set((s) => {
          const publications = { ...s.publications };
          delete publications[id];
          return { publications };
        });
      }
      case 'toast': {
        const d = msg.data;
        if (typeof d === 'string') return get().toast({ kind: 'info', title: d });
        const level = d.level || d.kind || 'info';
        const kind: ToastKind = level === 'error' ? 'error' : level === 'success' ? 'success' : 'info';
        const text = d.message || d.text || '';
        return get().toast({ kind, title: d.title || text, body: d.title ? text : undefined });
      }
    }
  },

  upsertJob: (j) => set((s) => ({ jobs: { ...s.jobs, [j.id]: j } })),
  upsertClips: (c) => set((s) => ({ clips: { ...s.clips, ...byId(c) } })),
  upsertPublications: (p) => set((s) => ({ publications: { ...s.publications, ...byId(p) } })),
  removeJob: (id) =>
    set((s) => {
      const jobs = { ...s.jobs };
      delete jobs[id];
      const clips = Object.fromEntries(Object.entries(s.clips).filter(([, c]) => c.jobId !== id));
      return { jobs, clips };
    }),

  loadJobs: async () => {
    try {
      const jobs = await api.jobs();
      set((s) => ({ jobs: byId(jobs), loaded: { ...s.loaded, jobs: true } }));
    } catch (e) {
      set((s) => ({ loaded: { ...s.loaded, jobs: true } }));
      console.warn('loadJobs', errMsg(e));
    }
  },
  loadJob: async (id) => {
    const { job, clips } = await api.job(id);
    get().upsertJob(job);
    // Replace this job's clips wholesale so deleted ones disappear.
    set((s) => ({
      clips: { ...Object.fromEntries(Object.entries(s.clips).filter(([, c]) => c.jobId !== id)), ...byId(clips) },
    }));
  },
  loadClips: async () => {
    try {
      const clips = await api.clips();
      set((s) => ({ clips: byId(clips), loaded: { ...s.loaded, clips: true } }));
    } catch (e) {
      console.warn('loadClips', errMsg(e));
    }
  },
  loadPublications: async () => {
    try {
      const pubs = await api.publications();
      set((s) => ({ publications: byId(pubs), loaded: { ...s.loaded, publications: true } }));
    } catch (e) {
      set((s) => ({ loaded: { ...s.loaded, publications: true } }));
      console.warn('loadPublications', errMsg(e));
    }
  },
  loadSettings: async () => {
    try {
      set({ settings: await api.settings() });
    } catch (e) {
      console.warn('loadSettings', errMsg(e));
    }
  },
  loadAccounts: async () => {
    try {
      set({ accounts: await api.accounts() });
    } catch (e) {
      console.warn('loadAccounts', errMsg(e));
    }
  },
  loadSystem: async () => {
    try {
      set({ system: await api.system() });
    } catch (e) {
      console.warn('loadSystem', errMsg(e));
    }
  },
  setSettings: (settings) => set({ settings }),

  toast: (t) => {
    const id = toastSeq++;
    set((s) => ({ toasts: [...s.toasts.slice(-3), { ...t, id }] }));
    setTimeout(() => get().dismiss(id), t.kind === 'error' ? 7000 : 4200);
  },
  dismiss: (id) => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),
}));

export const toast = {
  success: (title: string, body?: string) => useStore.getState().toast({ kind: 'success', title, body }),
  error: (title: string, body?: string) => useStore.getState().toast({ kind: 'error', title, body }),
  info: (title: string, body?: string) => useStore.getState().toast({ kind: 'info', title, body }),
  goblin: (title: string, body?: string) => useStore.getState().toast({ kind: 'goblin', title, body }),
};

/** Refresh everything (after an SSE reconnect we may have missed events). */
export function resyncAll() {
  const s = useStore.getState();
  void s.loadJobs();
  void s.loadPublications();
  void s.loadClips();
  void s.loadSystem();
}
