import clsx from 'clsx';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowRight, ChevronDown, FileVideo, Link2, SlidersHorizontal, UploadCloud, X } from 'lucide-react';
import { useEffect, useMemo, useRef, useState, type DragEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { PlatformIcon } from '../components/Brand';
import { EmptyState } from '../components/Chrome';
import { JobCard } from '../components/JobCard';
import { ClipSettingsForm } from '../components/StyleControls';
import { ProgressBar, Skeleton, Spinner } from '../components/ui';
import { api, errMsg, type UploadHandle } from '../lib/api';
import { detectVodPlatform, fmtBytes, fmtDuration } from '../lib/format';
import { CAPTION_STYLES, LAYOUTS } from '../lib/meta';
import { toast, useStore } from '../lib/store';
import type { JobOptions } from '../lib/types';

const FALLBACK_OPTIONS: JobOptions = {
  maxClips: 8,
  minSec: 15,
  maxSec: 59,
  layout: 'auto',
  captionStyle: 'beast',
  facecam: null,
  coldOpen: true,
  jumpCuts: true,
  progressBar: true,
  hookBanner: true,
  chaos: false,
};

interface UploadState {
  file: File;
  loaded: number;
  total: number;
  speed: number; // bytes/s
  handle: UploadHandle;
}

export default function Home() {
  const navigate = useNavigate();
  const settings = useStore((s) => s.settings);
  const jobsMap = useStore((s) => s.jobs);
  const jobsLoaded = useStore((s) => s.loaded.jobs);
  const jobs = useMemo(() => Object.values(jobsMap).sort((a, b) => b.createdAt - a.createdAt), [jobsMap]);

  const [options, setOptions] = useState<JobOptions>(FALLBACK_OPTIONS);
  const [optionsTouched, setOptionsTouched] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [url, setUrl] = useState('');
  const [dragging, setDragging] = useState(false);
  const [upload, setUpload] = useState<UploadState | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const dragDepth = useRef(0);

  // Seed the per-job form from the saved defaults (until the user touches it).
  useEffect(() => {
    if (settings?.defaults && !optionsTouched) setOptions({ ...FALLBACK_OPTIONS, ...settings.defaults });
  }, [settings, optionsTouched]);

  // Warn before closing the tab mid-upload.
  useEffect(() => {
    if (!upload) return;
    const h = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', h);
    return () => window.removeEventListener('beforeunload', h);
  }, [upload]);

  const vodPlatform = detectVodPlatform(url);

  const pickFile = (f: File | undefined | null) => {
    if (!f) return;
    if (!f.type.startsWith('video/') && !/\.(mp4|mov|mkv|webm|flv|ts|m4v|avi)$/i.test(f.name)) {
      toast.error("That doesn't look like a video", f.name);
      return;
    }
    setFile(f);
    setUrl('');
  };

  const onDrop = (e: DragEvent) => {
    e.preventDefault();
    dragDepth.current = 0;
    setDragging(false);
    pickFile(e.dataTransfer.files?.[0]);
  };

  const startUpload = () => {
    if (!file) return;
    let lastT = performance.now();
    let lastLoaded = 0;
    let speed = 0;
    const handle = api.uploadJob(file, options, ({ loaded, total }) => {
      const now = performance.now();
      const dt = (now - lastT) / 1000;
      if (dt > 0.25) {
        const inst = (loaded - lastLoaded) / dt;
        speed = speed ? speed * 0.7 + inst * 0.3 : inst;
        lastT = now;
        lastLoaded = loaded;
      }
      setUpload((u) => (u ? { ...u, loaded, total, speed } : u));
    });
    setUpload({ file, loaded: 0, total: file.size, speed: 0, handle });
    handle.promise
      .then((job) => {
        useStore.getState().upsertJob(job);
        toast.goblin('VOD received', 'The goblin is sharpening its scissors.');
        setFile(null);
        setUpload(null);
        navigate(`/jobs/${job.id}`);
      })
      .catch((err) => {
        setUpload(null);
        if (errMsg(err) !== 'Upload canceled') toast.error('Upload failed', errMsg(err));
      });
  };

  const startUrl = async () => {
    const u = url.trim();
    if (!u) return;
    if (!/^https?:\/\//i.test(u)) {
      toast.error('Paste a full link', 'It should start with https://');
      return;
    }
    setSubmitting(true);
    try {
      const job = await api.createJobFromUrl(u, options);
      useStore.getState().upsertJob(job);
      toast.goblin('On it', 'Fetching the VOD now.');
      setUrl('');
      navigate(`/jobs/${job.id}`);
    } catch (err) {
      toast.error('Could not start job', errMsg(err));
    } finally {
      setSubmitting(false);
    }
  };

  const summary = `${options.maxClips} clips · ${options.minSec}–${options.maxSec}s · ${
    LAYOUTS.find((l) => l.id === options.layout)?.label
  } · ${CAPTION_STYLES.find((c) => c.id === options.captionStyle)?.label} captions${options.chaos ? ' · chaos 🔥' : ''}`;

  const pct = upload ? (upload.total ? upload.loaded / upload.total : 0) : 0;
  const eta = upload && upload.speed > 0 ? (upload.total - upload.loaded) / upload.speed : null;

  return (
    <div className="mx-auto max-w-7xl px-4 pb-16 pt-8 sm:px-6 sm:pt-12">
      {/* Hero */}
      <div className="mx-auto max-w-3xl text-center">
        <motion.h1
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="font-display text-[34px] font-extrabold leading-[1.05] tracking-tight text-white sm:text-5xl"
        >
          Feed the goblin a VOD.
          <br />
          <span className="text-gradient">Get back viral shorts.</span>
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.08 }}
          className="mx-auto mt-4 max-w-xl text-[15px] leading-relaxed text-zinc-400"
        >
          Hour-long stream in, 9:16 bangers out — with hooks, animated captions, cold opens and jump cuts. Posted to Shorts, TikTok and Reels while you sleep.
        </motion.p>
      </div>

      {/* Intake */}
      <motion.section
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.12, type: 'spring', stiffness: 200, damping: 26 }}
        className="relative mx-auto mt-8 max-w-3xl"
      >
        <div className="absolute -inset-3 rounded-[36px] bg-goblin-gradient opacity-[0.12] blur-3xl" />
        <div className="panel relative overflow-hidden rounded-[26px] p-2.5 sm:p-3">
          {/* Dropzone */}
          <AnimatePresence mode="wait" initial={false}>
            {upload ? (
              <motion.div
                key="uploading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="rounded-[20px] border border-hex-400/20 bg-ink-950/60 p-5 sm:p-7"
              >
                <div className="flex items-center gap-4">
                  <div className="relative grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-hex-500/15 text-hex-300">
                    <UploadCloud className="h-6 w-6" />
                    <span className="absolute inset-0 animate-pulse-ring rounded-2xl border border-hex-400/60" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[15px] font-semibold text-white">{upload.file.name}</div>
                    <div className="mt-0.5 text-[13px] text-zinc-400 tabular">
                      {fmtBytes(upload.loaded)} of {fmtBytes(upload.total)}
                      {upload.speed > 0 && <> · {fmtBytes(upload.speed)}/s</>}
                      {eta != null && isFinite(eta) && <> · {fmtDuration(eta)} left</>}
                    </div>
                  </div>
                  <div className="font-display text-3xl font-extrabold text-white tabular">{Math.floor(pct * 100)}%</div>
                </div>
                <ProgressBar value={pct} className="mt-5 !h-2.5" />
                <div className="mt-4 flex items-center justify-between">
                  <span className="text-xs text-zinc-500">{pct >= 1 ? 'Finishing up…' : 'Keep this tab open until the upload completes.'}</span>
                  <button className="btn btn-sm btn-ghost" onClick={() => upload.handle.abort()}>
                    Cancel
                  </button>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="drop"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onDragEnter={(e) => {
                  e.preventDefault();
                  dragDepth.current++;
                  setDragging(true);
                }}
                onDragOver={(e) => e.preventDefault()}
                onDragLeave={() => {
                  dragDepth.current = Math.max(0, dragDepth.current - 1);
                  if (!dragDepth.current) setDragging(false);
                }}
                onDrop={onDrop}
                onClick={() => !file && inputRef.current?.click()}
                className={clsx(
                  'relative flex min-h-[230px] flex-col items-center justify-center overflow-hidden rounded-[20px] border-2 border-dashed px-5 py-8 text-center transition-all duration-300 sm:min-h-[260px]',
                  file ? 'cursor-default border-goblin-400/40 bg-goblin-400/[0.03]' : 'cursor-pointer',
                  dragging
                    ? 'scale-[1.01] border-goblin-400 bg-goblin-400/[0.07]'
                    : !file && 'border-white/10 bg-ink-950/40 hover:border-white/25 hover:bg-ink-950/60',
                )}
              >
                <div className="pointer-events-none absolute inset-0 bg-grid opacity-50 [mask-image:radial-gradient(ellipse_at_center,black_10%,transparent_70%)]" />
                <input
                  ref={inputRef}
                  type="file"
                  accept="video/*,.mkv,.flv,.ts"
                  className="hidden"
                  onChange={(e) => {
                    pickFile(e.target.files?.[0]);
                    e.target.value = '';
                  }}
                />
                {file ? (
                  <div className="relative flex w-full max-w-md items-center gap-3 rounded-2xl border border-white/10 bg-ink-850 p-3 text-left">
                    <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-goblin-400/15 text-goblin-300">
                      <FileVideo className="h-6 w-6" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-semibold text-white">{file.name}</div>
                      <div className="text-xs text-zinc-500">{fmtBytes(file.size)} · ready to summon</div>
                    </div>
                    <button className="rounded-lg p-2 text-zinc-500 hover:bg-white/5 hover:text-white" onClick={() => setFile(null)} aria-label="Remove file">
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ) : (
                  <>
                    <motion.div
                      animate={dragging ? { y: -6, scale: 1.1, rotate: -4 } : { y: 0, scale: 1, rotate: 0 }}
                      className="relative grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-goblin-400/25 to-hex-500/25 text-goblin-300 ring-1 ring-white/10"
                    >
                      <UploadCloud className="h-7 w-7" />
                    </motion.div>
                    <div className="relative mt-4 font-display text-xl font-bold text-white">
                      {dragging ? 'Drop it like it’s hot' : 'Drop a stream VOD here'}
                    </div>
                    <div className="relative mt-1 text-sm text-zinc-400">
                      MP4, MOV, MKV, WEBM — multi-GB is fine. <span className="text-goblin-300 underline-offset-2 hover:underline">Browse files</span>
                    </div>
                  </>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          {/* URL row */}
          {!upload && !file && (
            <div className="mt-2.5 flex flex-col gap-2 sm:flex-row">
              <div className="relative flex-1">
                <div className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2">
                  {vodPlatform && vodPlatform !== 'other' ? (
                    <PlatformIcon platform={vodPlatform} className="h-4 w-4" />
                  ) : (
                    <Link2 className="h-4 w-4 text-zinc-500" />
                  )}
                </div>
                <input
                  className="input h-12 rounded-2xl pl-10 text-[15px]"
                  placeholder="…or paste a Twitch, YouTube or Kick VOD link"
                  value={url}
                  inputMode="url"
                  onChange={(e) => setUrl(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && startUrl()}
                />
              </div>
              <button className="btn btn-lg btn-primary" disabled={!url.trim() || submitting} onClick={startUrl}>
                {submitting ? <Spinner /> : <>Summon clips <ArrowRight className="h-4 w-4" /></>}
              </button>
            </div>
          )}
          {!upload && file && (
            <div className="mt-2.5 flex justify-end">
              <button className="btn btn-lg btn-primary w-full sm:w-auto" onClick={startUpload}>
                Upload & summon clips <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          )}

          {/* Clip settings */}
          {!upload && (
            <div className="mt-2.5 rounded-2xl border border-white/[0.06] bg-ink-950/30">
              <button
                type="button"
                onClick={() => setShowSettings((s) => !s)}
                className="flex w-full items-center gap-3 px-4 py-3 text-left"
                aria-expanded={showSettings}
              >
                <SlidersHorizontal className="h-4 w-4 shrink-0 text-zinc-400" />
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-semibold text-zinc-200">Clip settings</div>
                  <div className="truncate text-xs text-zinc-500">{summary}</div>
                </div>
                <ChevronDown className={clsx('h-4 w-4 shrink-0 text-zinc-500 transition-transform duration-300', showSettings && 'rotate-180')} />
              </button>
              <AnimatePresence initial={false}>
                {showSettings && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ type: 'spring', stiffness: 260, damping: 32 }}
                    className="overflow-hidden"
                  >
                    <div className="border-t border-white/[0.06] p-4">
                      <ClipSettingsForm
                        value={options}
                        onChange={(p) => {
                          setOptionsTouched(true);
                          setOptions((o) => ({ ...o, ...p }));
                        }}
                      />
                      <p className="mt-4 text-xs text-zinc-500">
                        These apply to this VOD only. Change the defaults in{' '}
                        <a href="/settings#style" onClick={(e) => (e.preventDefault(), navigate('/settings#style'))} className="text-goblin-400 hover:underline">
                          Settings
                        </a>
                        .
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}
        </div>
      </motion.section>

      {/* Recent jobs */}
      <section className="mt-14">
        <div className="mb-4 flex items-end justify-between">
          <div>
            <h2 className="font-display text-xl font-bold text-white">Your hoard</h2>
            <p className="text-sm text-zinc-500">Recent VODs and the clips the goblin dug out of them.</p>
          </div>
          {jobs.length > 0 && <span className="text-sm text-zinc-500 tabular">{jobs.length} VOD{jobs.length === 1 ? '' : 's'}</span>}
        </div>
        {!jobsLoaded ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} className="h-72 rounded-2xl" />
            ))}
          </div>
        ) : jobs.length === 0 ? (
          <EmptyState
            mood="sleep"
            title="The hoard is empty"
            body="Drop your first VOD above. The goblin will watch the whole thing so you don't have to."
          />
        ) : (
          <motion.div layout className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <AnimatePresence>
              {jobs.map((j, i) => (
                <JobCard key={j.id} job={j} index={i} />
              ))}
            </AnimatePresence>
          </motion.div>
        )}
      </section>
    </div>
  );
}
