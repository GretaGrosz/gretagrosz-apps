import clsx from 'clsx';
import { motion } from 'framer-motion';
import { AlertTriangle, Brain, Clapperboard, Film, Gauge, Link2, RotateCcw, Sparkles, Trash2 } from 'lucide-react';
import { useState, type MouseEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api, errMsg } from '../lib/api';
import { detectVodPlatform, fmtDuration, timeAgo } from '../lib/format';
import { isActive, JOB_STATUS_LABEL } from '../lib/meta';
import { toast, useStore } from '../lib/store';
import type { Job } from '../lib/types';
import { PlatformIcon } from './Brand';
import { ProgressBar } from './ui';

export function Thumb({ src, alt, className, children }: { src?: string | null; alt?: string; className?: string; children?: React.ReactNode }) {
  const [failed, setFailed] = useState(false);
  return (
    <div className={clsx('relative overflow-hidden bg-ink-800', className)}>
      {src && !failed ? (
        <img src={src} alt={alt ?? ''} loading="lazy" onError={() => setFailed(true)} className="absolute inset-0 h-full w-full object-cover" />
      ) : (
        <div className="absolute inset-0 grid place-items-center bg-[radial-gradient(circle_at_20%_20%,rgba(139,92,246,.35),transparent_55%),radial-gradient(circle_at_80%_80%,rgba(198,255,61,.18),transparent_55%)]">
          <Film className="h-7 w-7 text-white/20" />
        </div>
      )}
      {children}
    </div>
  );
}

export function AnalyzerBadge({ analyzer, short }: { analyzer?: Job['analyzer']; short?: boolean }) {
  if (!analyzer) return null;
  if (analyzer === 'claude')
    return (
      <span className="chip border-hex-400/30 bg-hex-500/10 text-hex-300" title="Moments picked by Claude">
        <Brain className="h-3 w-3" /> Claude
      </span>
    );
  return (
    <Link
      to="/settings#ai"
      onClick={(e) => e.stopPropagation()}
      className="chip border-amber-300/25 bg-amber-300/[0.07] text-amber-200/90 hover:bg-amber-300/15"
      title="Add an Anthropic API key for smarter clips"
    >
      <Gauge className="h-3 w-3" /> Heuristic{!short && <span className="hidden font-normal text-amber-200/60 sm:inline"> — add an API key for smarter clips</span>}
    </Link>
  );
}

export function StatusPill({ job }: { job: Job }) {
  const active = isActive(job);
  return (
    <span
      className={clsx(
        'chip backdrop-blur-md',
        job.status === 'done' && 'border-goblin-400/30 bg-ink-950/70 text-goblin-300',
        job.status === 'error' && 'border-rose-500/30 bg-rose-950/70 text-rose-300',
        job.status === 'canceled' && 'border-white/10 bg-ink-950/70 text-zinc-400',
        active && 'border-hex-400/30 bg-ink-950/70 text-hex-300',
      )}
    >
      {active && (
        <span className="relative flex h-1.5 w-1.5">
          <span className="absolute inset-0 animate-ping rounded-full bg-hex-400" />
          <span className="relative h-1.5 w-1.5 rounded-full bg-hex-400" />
        </span>
      )}
      {JOB_STATUS_LABEL[job.status] ?? job.status}
    </span>
  );
}

export function SourceIcon({ job, className }: { job: Job; className?: string }) {
  if (job.source?.type === 'url') {
    const p = detectVodPlatform(job.source.url || '');
    if (p && p !== 'other') return <PlatformIcon platform={p} className={className ?? 'h-3.5 w-3.5'} />;
    return <Link2 className={clsx('text-zinc-400', className ?? 'h-3.5 w-3.5')} />;
  }
  return <Clapperboard className={clsx('text-zinc-400', className ?? 'h-3.5 w-3.5')} />;
}

export function JobCard({ job, index = 0 }: { job: Job; index?: number }) {
  const navigate = useNavigate();
  const clipsMap = useStore((s) => s.clips);
  const active = isActive(job);
  const readyClips = Object.values(clipsMap).filter((c) => c.jobId === job.id && c.status === 'ready').length;
  const clipCount = Math.max(job.clipIds?.length ?? 0, readyClips);
  const [busy, setBusy] = useState(false);

  const onDelete = async (e: MouseEvent) => {
    e.stopPropagation();
    if (!confirm(active ? 'Cancel and delete this job?' : 'Delete this job and all its clips?')) return;
    setBusy(true);
    try {
      await api.deleteJob(job.id);
      useStore.getState().removeJob(job.id);
      toast.info('Job deleted');
    } catch (err) {
      toast.error('Could not delete', errMsg(err));
    } finally {
      setBusy(false);
    }
  };
  const onRetry = async (e: MouseEvent) => {
    e.stopPropagation();
    try {
      useStore.getState().upsertJob(await api.retryJob(job.id));
      toast.goblin('Back to work', 'The goblin is giving it another go.');
    } catch (err) {
      toast.error('Retry failed', errMsg(err));
    }
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.96 }}
      transition={{ delay: Math.min(index * 0.04, 0.3), type: 'spring', stiffness: 300, damping: 30 }}
      onClick={() => navigate(`/jobs/${job.id}`)}
      className={clsx(
        'group relative cursor-pointer overflow-hidden rounded-2xl border bg-ink-850/80 shadow-card transition-all duration-300',
        'hover:-translate-y-0.5 hover:border-white/15 hover:shadow-[0_20px_50px_-20px_rgba(0,0,0,.8)]',
        active ? 'border-hex-500/25' : 'border-white/[0.07]',
        busy && 'pointer-events-none opacity-50',
      )}
    >
      <Thumb src={job.thumb} className="aspect-video">
        <div className="absolute inset-0 bg-gradient-to-t from-ink-900 via-ink-900/10 to-transparent" />
        {active && <div className="absolute inset-0 bg-gradient-to-br from-hex-500/10 to-transparent" />}
        <div className="absolute left-3 top-3 flex items-center gap-1.5">
          <StatusPill job={job} />
        </div>
        <div className="absolute right-2 top-2 flex gap-1 opacity-100 transition sm:opacity-0 sm:group-hover:opacity-100">
          {(job.status === 'error' || job.status === 'canceled') && (
            <button onClick={onRetry} className="grid h-8 w-8 place-items-center rounded-lg bg-ink-950/70 text-zinc-300 backdrop-blur hover:text-white" title="Retry">
              <RotateCcw className="h-4 w-4" />
            </button>
          )}
          <button onClick={onDelete} className="grid h-8 w-8 place-items-center rounded-lg bg-ink-950/70 text-zinc-300 backdrop-blur hover:text-rose-300" title="Delete">
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
        {job.durationSec ? (
          <span className="absolute bottom-2.5 right-3 rounded-md bg-black/60 px-1.5 py-0.5 font-mono text-[11px] text-white/90 backdrop-blur">
            {fmtDuration(job.durationSec)}
          </span>
        ) : null}
      </Thumb>
      <div className="space-y-3 p-4 pt-3">
        <div>
          <div className="flex items-center gap-2">
            <SourceIcon job={job} />
            <h3 className="truncate text-[15px] font-semibold text-white" title={job.source?.name}>
              {job.source?.name || 'Untitled VOD'}
            </h3>
          </div>
          <div className="mt-1 flex items-center gap-2 text-xs text-zinc-500">
            <span>{timeAgo(job.createdAt)}</span>
            {clipCount > 0 && (
              <>
                <span className="h-0.5 w-0.5 rounded-full bg-zinc-600" />
                <span className="flex items-center gap-1 text-zinc-300">
                  <Sparkles className="h-3 w-3 text-goblin-400" />
                  {clipCount} clip{clipCount === 1 ? '' : 's'}
                </span>
              </>
            )}
          </div>
        </div>

        {active ? (
          <div className="space-y-1.5">
            <ProgressBar value={job.progress} indeterminate={job.status === 'queued'} />
            <div className="flex items-center justify-between gap-3 text-xs">
              <span className="truncate text-zinc-400">{job.stage || JOB_STATUS_LABEL[job.status]}</span>
              <span className="shrink-0 font-mono text-zinc-300 tabular">{Math.round((job.progress || 0) * 100)}%</span>
            </div>
          </div>
        ) : job.status === 'error' ? (
          <div className="flex items-start gap-2 rounded-lg bg-rose-500/[0.07] px-2.5 py-2 text-xs text-rose-300">
            <AlertTriangle className="mt-px h-3.5 w-3.5 shrink-0" />
            <span className="line-clamp-2">{job.error || 'Something went wrong'}</span>
          </div>
        ) : null}

        <div className="flex flex-wrap items-center gap-1.5">
          <AnalyzerBadge analyzer={job.analyzer} short />
          {job.autopilotScheduled && (
            <span className="chip border-goblin-400/25 bg-goblin-400/[0.07] text-goblin-300">Autopiloted</span>
          )}
        </div>
      </div>
    </motion.div>
  );
}
