// ffmpeg / ffprobe wrappers (static binaries from npm), with progress parsing and cancellation.
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import ffmpegStatic from 'ffmpeg-static';
import { paths } from '../config.js';
import { CanceledError } from './util.js';

export const FFMPEG = ffmpegStatic;
export const FONTS_DIR = '/System/Library/Fonts/Supplemental';

/** A dir containing ffmpeg for yt-dlp's --ffmpeg-location (no ffprobe: see probe() below). */
export function ffmpegDir() {
  const dir = path.join(paths.bin, 'ff');
  fs.mkdirSync(dir, { recursive: true });
  for (const [name, target] of [['ffmpeg', FFMPEG]]) {
    const link = path.join(dir, name);
    try {
      if (fs.readlinkSync(link) === target) continue;
      fs.unlinkSync(link);
    } catch { /* missing */ }
    try { fs.symlinkSync(target, link); } catch { /* race */ }
  }
  return dir;
}

/**
 * Spawn a process; resolves {stdout, stderr} or rejects with a readable error.
 * opts.signal aborts (SIGKILL). opts.onStdoutLine / onStderrLine get lines as they arrive.
 * opts.binary=true collects stdout as a Buffer.
 */
export function run(bin, args, opts = {}) {
  return new Promise((resolve, reject) => {
    if (opts.signal?.aborted) return reject(new CanceledError());
    const child = spawn(bin, args, { stdio: ['ignore', 'pipe', 'pipe'], cwd: opts.cwd });
    const out = [];
    let err = '';
    let outBuf = '';
    let errBuf = '';
    const onAbort = () => child.kill('SIGKILL');
    opts.signal?.addEventListener('abort', onAbort, { once: true });
    child.stdout.on('data', (d) => {
      if (opts.binary) out.push(d);
      else if (!opts.onStdoutLine) out.push(d);
      if (opts.onStdoutLine) {
        outBuf += d.toString();
        let i;
        while ((i = outBuf.indexOf('\n')) >= 0) { opts.onStdoutLine(outBuf.slice(0, i).trim()); outBuf = outBuf.slice(i + 1); }
      }
    });
    child.stderr.on('data', (d) => {
      const s = d.toString();
      err += s;
      if (err.length > 200_000) err = err.slice(-100_000);
      if (opts.onStderrLine) {
        errBuf += s;
        let i;
        while ((i = errBuf.search(/[\r\n]/)) >= 0) { const line = errBuf.slice(0, i).trim(); if (line) opts.onStderrLine(line); errBuf = errBuf.slice(i + 1); }
      }
    });
    child.on('error', (e) => {
      opts.signal?.removeEventListener('abort', onAbort);
      reject(e);
    });
    child.on('close', (code, sig) => {
      opts.signal?.removeEventListener('abort', onAbort);
      if (opts.signal?.aborted) return reject(new CanceledError());
      const stdout = opts.binary ? Buffer.concat(out) : Buffer.concat(out).toString();
      if (code === 0) return resolve({ stdout, stderr: err });
      const tail = err.trim().split('\n').filter((l) => !/^\s*(built with|configuration:|lib\w+\s+\d)/.test(l)).slice(-8).join('\n');
      const e = new Error(`${path.basename(bin)} failed (${sig || `exit ${code}`}): ${tail || 'no output'}`);
      e.code = code;
      e.stderr = err;
      reject(e);
    });
  });
}

/** ffmpeg with -progress parsing: onProgress(seconds of output written). */
export function ffmpeg(args, { signal, onProgress } = {}) {
  const full = ['-hide_banner', '-nostdin', '-y', ...(onProgress ? ['-progress', 'pipe:1', '-nostats'] : []), ...args];
  return run(FFMPEG, full, {
    signal,
    onStdoutLine: onProgress ? (line) => {
      const m = /^out_time_(?:us|ms)=(\d+)/.exec(line);
      if (m) onProgress(Number(m[1]) / 1e6);
    } : undefined,
  });
}

// NOTE: ffprobe-static ships an x86_64 binary even under darwin/arm64, which can't run on Apple
// Silicon without Rosetta — so probing parses `ffmpeg -i` output instead (ffmpeg-static is native).
export async function probe(file) {
  if (!fs.existsSync(file)) throw new Error('Video file not found');
  let text = '';
  try {
    await run(FFMPEG, ['-hide_banner', '-nostdin', '-i', file]);
  } catch (e) {
    text = e.stderr || '';
  }
  if (/Invalid data found|could not find codec parameters|moov atom not found/i.test(text) && !/Stream #/.test(text)) {
    throw new Error('Could not read that video — the file looks corrupt or is not a video');
  }
  const dm = /Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(text);
  let durationSec = dm ? Number(dm[1]) * 3600 + Number(dm[2]) * 60 + Number(dm[3]) : 0;
  const vLine = text.split('\n').find((l) => /Stream #.*Video:/.test(l) && !/attached pic/.test(l)) || '';
  const aLine = text.split('\n').find((l) => /Stream #.*Audio:/.test(l));
  const sz = /,\s*(\d{2,5})x(\d{2,5})[\s,]/.exec(vLine);
  let width = sz ? Number(sz[1]) : 0;
  let height = sz ? Number(sz[2]) : 0;
  const rot = /rotation of (-?[\d.]+) degrees/.exec(text) || /rotate\s*:\s*(-?\d+)/.exec(text);
  if (rot && Math.abs(Math.round(Number(rot[1]))) % 180 === 90) [width, height] = [height, width];
  const fpsM = /([\d.]+) fps/.exec(vLine) || /([\d.]+) tbr/.exec(vLine);
  if (!durationSec && vLine) {
    // Some containers (live recordings, .ts) don't store a duration: count it by remuxing to null.
    let last = 0;
    await run(FFMPEG, ['-hide_banner', '-nostdin', '-i', file, '-map', '0:v:0', '-c', 'copy', '-f', 'null', '-'], {
      onStderrLine: (l) => { const m = /time=(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(l); if (m) last = Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]); },
    }).catch(() => {});
    durationSec = last;
  }
  return {
    durationSec,
    sizeBytes: fs.statSync(file).size,
    width,
    height,
    fps: fpsM ? Number(fpsM[1]) : 30,
    hasAudio: !!aLine,
    hasVideo: !!vLine,
  };
}

/** Single JPEG frame at time t (seconds). Returns a Buffer, or writes to outFile. */
export async function grabFrame(file, t, { width = 960, outFile, signal } = {}) {
  const args = ['-hide_banner', '-nostdin', '-loglevel', 'error', '-ss', String(Math.max(0, t)), '-i', file,
    '-frames:v', '1', '-vf', `scale=${width}:-2`, '-q:v', '3'];
  if (outFile) {
    await run(FFMPEG, [...args, '-y', outFile], { signal });
    return outFile;
  }
  const { stdout } = await run(FFMPEG, [...args, '-f', 'image2pipe', '-vcodec', 'mjpeg', 'pipe:1'], { binary: true, signal });
  return stdout;
}
