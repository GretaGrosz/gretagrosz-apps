/**
 * Dev-only fake backend. Enabled with `VITE_MOCK=1 npm run dev` (or `npm run dev:mock`).
 * Replaces the transport layer in src/lib/api.ts with in-memory fixtures and a simulated SSE stream,
 * so every screen can be explored without the real server. Never included in production builds.
 */
import { ApiError, transport, type EventSourceLike } from '../lib/api';
import type { Accounts, Clip, Job, Platform, Publication, Settings, SystemInfo } from '../lib/types';
// Served by the dev-only middleware in vite.config.ts (never bundled).
const M = '/__mock-media';
const clip1Jpg = `${M}/clip1.jpg`;
const clip1Mp4 = `${M}/clip1.mp4`;
const clip2Jpg = `${M}/clip2.jpg`;
const clip2Mp4 = `${M}/clip2.mp4`;
const clip3Jpg = `${M}/clip3.jpg`;
const clip3Mp4 = `${M}/clip3.mp4`;
const vod1 = `${M}/vod1.jpg`;
const vod2 = `${M}/vod2.jpg`;
const vod3 = `${M}/vod3.jpg`;

const MEDIA = [
  { mp4: clip1Mp4, jpg: clip1Jpg },
  { mp4: clip2Mp4, jpg: clip2Jpg },
  { mp4: clip3Mp4, jpg: clip3Jpg },
];
const now = Date.now();
const H = 3600_000;
let seq = 100;
const nid = (p: string) => `${p}_mock${++seq}`;

/* ───────────── fixtures ───────────── */

const settings: Settings = {
  anthropicApiKey: '',
  claudeModel: 'claude-opus-5-5',
  publicBaseUrl: '',
  transcription: { provider: 'local', localModel: 'onnx-community/whisper-base.en', groqApiKey: '', openaiApiKey: '••••3f9a' },
  defaults: {
    maxClips: 8,
    minSec: 15,
    maxSec: 59,
    layout: 'auto',
    captionStyle: 'beast',
    facecam: { x: 0.04, y: 0.6, w: 0.25, h: 0.33 },
    coldOpen: true,
    jumpCuts: true,
    progressBar: true,
    hookBanner: true,
    chaos: false,
  },
  autopilot: { enabled: true, platforms: ['tiktok', 'youtube'], minScore: 70, maxPerJob: 3, spacingMinutes: 180 },
  platforms: {
    youtube: { clientId: '1234-abc.apps.googleusercontent.com', clientSecret: '••••Qx7z', privacy: 'public' },
    tiktok: { clientKey: 'awx9k2l', clientSecret: '••••tT0k', privacy: 'SELF_ONLY', mode: 'direct' },
    instagram: { appId: '', appSecret: '' },
  },
};

const system: SystemInfo = { ffmpeg: true, ytdlp: true, analyzer: 'heuristic', transcription: 'local', localModelReady: true };

const accounts: Accounts = {
  youtube: {
    configured: true,
    connected: true,
    name: 'GoblinMode Gaming',
    avatar: null,
    setup: [
      'Open https://console.cloud.google.com/apis/credentials and create a project.',
      'Enable the "YouTube Data API v3" for the project.',
      'Create an OAuth client ID of type "Web application".',
      'Add this authorized redirect URI: http://localhost:4777/api/auth/youtube/callback',
      'Paste the client ID and secret below, save, then click Connect.',
    ],
  },
  tiktok: {
    configured: true,
    connected: false,
    note: 'Unaudited TikTok apps can only post privately (SELF_ONLY). Submit your app for audit at https://developers.tiktok.com to post publicly.',
    setup: [
      'Create an app at https://developers.tiktok.com/apps',
      'Add the "Login Kit" and "Content Posting API" products.',
      'Set the redirect URI to http://localhost:4777/api/auth/tiktok/callback',
      'Copy the client key + secret below and click Connect.',
    ],
  },
  instagram: {
    configured: false,
    connected: false,
    note: 'Instagram needs a Business or Creator account linked to a Facebook Page, plus a public URL (see Advanced).',
    setup: [
      'Create a Meta app at https://developers.facebook.com/apps (type: Business).',
      'Add "Instagram Graph API" and "Facebook Login".',
      'Valid OAuth redirect URI: http://localhost:4777/api/auth/instagram/callback',
      'Paste the App ID and App secret below.',
    ],
  },
};

const baseOptions = { ...settings.defaults };

const jobs: Record<string, Job> = {};
const clips: Record<string, Clip> = {};
const pubs: Record<string, Publication> = {};

function addJob(j: Partial<Job> & { id: string }) {
  jobs[j.id] = {
    createdAt: now,
    updatedAt: now,
    source: { type: 'file', name: 'stream.mp4' },
    status: 'queued',
    progress: 0,
    stage: '',
    error: null,
    options: baseOptions,
    clipIds: [],
    thumb: null,
    analyzer: 'heuristic',
    ...j,
  } as Job;
}

addJob({
  id: 'job_live',
  createdAt: now - 6 * 60_000,
  source: { type: 'url', name: 'Horror night w/ chat (Phasmophobia)', url: 'https://www.twitch.tv/videos/2283745519' },
  status: 'transcribing',
  progress: 0.32,
  stage: 'Transcribing 18:40 / 2:14:08',
  durationSec: 8048,
  width: 1920,
  height: 1080,
  thumb: vod2,
  analyzer: 'heuristic',
});
addJob({
  id: 'job_done',
  createdAt: now - 26 * H,
  source: { type: 'file', name: 'Ranked grind to Diamond — day 14.mp4' },
  status: 'done',
  progress: 1,
  stage: 'Done — 6 clips',
  durationSec: 11234,
  width: 1920,
  height: 1080,
  thumb: vod1,
  analyzer: 'claude',
  autopilotScheduled: true,
});
addJob({
  id: 'job_err',
  createdAt: now - 3 * 24 * H,
  source: { type: 'url', name: 'kick.com/goblinmode/videos/8f2…', url: 'https://kick.com/goblinmode/videos/8f2a1c' },
  status: 'error',
  progress: 0.08,
  stage: 'Downloading 4%',
  error: 'yt-dlp: HTTP Error 403: Forbidden — this VOD may be subscriber-only.',
  thumb: null,
  analyzer: 'heuristic',
});
addJob({
  id: 'job_old',
  createdAt: now - 5 * 24 * H,
  source: { type: 'file', name: 'Just chatting + viewer games.mkv' },
  status: 'done',
  progress: 1,
  stage: 'Done',
  durationSec: 6120,
  width: 1920,
  height: 1080,
  thumb: vod3,
  analyzer: 'claude',
});

const CLIP_FIXTURES: Array<Partial<Clip>> = [
  {
    score: 94,
    category: 'clutch',
    hook: '1 HP. 1v4. no way 💀',
    title: 'I was on 1 HP in a 1v4 and chat started saying goodbye',
    why: 'Impossible odds set up in 2 seconds, payoff lands at 0:19 with a genuine scream.',
    description: 'They really thought it was over 😭',
    hashtags: ['#clutch', '#gaming', '#fyp', '#valorant'],
  },
  {
    score: 88,
    category: 'funny',
    hook: 'he did NOT expect that',
    title: 'My duo walked straight into the trap I warned him about 3 times',
    why: 'Repeated warnings build tension; the fail is instant and the reaction is loud.',
    description: 'I TOLD HIM. three times.',
    hashtags: ['#funny', '#duo', '#fail'],
  },
  {
    score: 81,
    category: 'rage',
    hook: 'the keyboard did nothing wrong',
    title: 'Losing to a bot at 3AM broke something inside me',
    why: 'Escalating rage with a clean punchline line at the end — great rewatch value.',
    description: 'not my proudest moment',
    hashtags: ['#rage', '#streamer', '#3am'],
  },
  {
    score: 73,
    category: 'wtf',
    hook: 'what is THAT doing there',
    title: 'Found something in the map that should not exist',
    why: 'Curiosity gap: viewers stay to see what it is.',
    description: 'devs explain??',
    hashtags: ['#wtf', '#glitch'],
  },
  {
    score: 64,
    category: 'wholesome',
    hook: 'chat made me cry fr',
    title: 'Chat surprised me with 100 gifted subs on my birthday stream',
    why: 'Emotional peak, but slower build — works better for loyal followers.',
    description: 'love you guys 🥹',
    hashtags: ['#wholesome', '#twitch'],
  },
  {
    score: 52,
    category: 'cringe',
    hook: 'I forgot my mic was on',
    title: 'Hot mic moment I will never live down',
    why: 'Relatable embarrassment; hook is strong but the payoff is quiet.',
    description: 'delete this',
    hashtags: ['#cringe', '#hotmic'],
  },
];

CLIP_FIXTURES.forEach((f, i) => {
  const id = `clip_done${i + 1}`;
  const m = MEDIA[i % MEDIA.length];
  const start = 600 + i * 1311;
  const len = 22 + ((i * 7) % 30);
  clips[id] = {
    id,
    jobId: 'job_done',
    createdAt: now - 25 * H,
    updatedAt: now - 25 * H,
    rank: i + 1,
    start,
    end: start + len,
    coldOpen: { start: start + len - 4, end: start + len - 2.8 },
    transcript: '',
    status: 'ready',
    progress: 1,
    error: null,
    file: m.mp4,
    thumb: m.jpg,
    durationSec: len + 1.2,
    style: {},
    publish: {},
    ...f,
  } as Clip;
  jobs.job_done.clipIds.push(id);
});
// a couple of clips on the old job
for (let i = 0; i < 3; i++) {
  const id = `clip_old${i + 1}`;
  const m = MEDIA[(i + 1) % MEDIA.length];
  clips[id] = {
    ...clips[`clip_done${i + 2}`],
    id,
    jobId: 'job_old',
    rank: i + 1,
    file: m.mp4,
    thumb: m.jpg,
    publish: {},
  };
  jobs.job_old.clipIds.push(id);
}

function addPub(p: Partial<Publication> & { clipId: string; platform: Platform; status: Publication['status'] }) {
  const id = nid('pub');
  const clip = clips[p.clipId];
  pubs[id] = {
    id,
    jobId: clip.jobId,
    scheduledAt: now,
    title: clip.title,
    caption: clip.description,
    progress: 0,
    createdAt: now - H,
    updatedAt: now - H,
    ...p,
  } as Publication;
  clip.publish = { ...clip.publish, [p.platform]: { status: pubs[id].status, url: pubs[id].url, publicationId: id } };
  return pubs[id];
}

addPub({ clipId: 'clip_done1', platform: 'youtube', status: 'published', publishedAt: now - 20 * H, url: 'https://youtube.com/shorts/dQw4w9WgXcQ', scheduledAt: now - 20 * H });
addPub({ clipId: 'clip_done1', platform: 'tiktok', status: 'published', publishedAt: now - 20 * H, url: 'https://www.tiktok.com/@goblin/video/1', scheduledAt: now - 20 * H });
addPub({ clipId: 'clip_done2', platform: 'tiktok', status: 'uploading', progress: 0.35, scheduledAt: now - 60_000 });
addPub({ clipId: 'clip_done2', platform: 'youtube', status: 'scheduled', scheduledAt: now + 2.2 * H });
addPub({ clipId: 'clip_done3', platform: 'youtube', status: 'scheduled', scheduledAt: now + 5.2 * H });
addPub({ clipId: 'clip_done3', platform: 'tiktok', status: 'scheduled', scheduledAt: now + 26 * H });
addPub({ clipId: 'clip_done4', platform: 'instagram', status: 'error', error: 'Instagram could not fetch the video: publicBaseUrl is not set, so localhost URLs are unreachable.', scheduledAt: now - 4 * H, updatedAt: now - 4 * H });
addPub({ clipId: 'clip_old1', platform: 'youtube', status: 'published', publishedAt: now - 4 * 24 * H, url: 'https://youtube.com/shorts/abc', scheduledAt: now - 4 * 24 * H });
addPub({ clipId: 'clip_old2', platform: 'tiktok', status: 'canceled', scheduledAt: now - 3 * 24 * H, updatedAt: now - 3 * 24 * H });

/* ───────────── SSE simulation ───────────── */

const listeners = new Set<FakeEventSource>();
function emit(type: string, data: unknown) {
  const ev = new MessageEvent('message', { data: JSON.stringify({ type, data }) });
  for (const l of listeners) l.onmessage?.(ev);
}

class FakeEventSource implements EventSourceLike {
  onopen: ((ev: Event) => void) | null = null;
  onerror: ((ev: Event) => void) | null = null;
  onmessage: ((ev: MessageEvent) => void) | null = null;
  readyState = 0;
  constructor() {
    setTimeout(() => {
      if (this.readyState === 2) return;
      this.readyState = 1;
      listeners.add(this);
      this.onopen?.(new Event('open'));
    }, 350);
  }
  close() {
    this.readyState = 2;
    listeners.delete(this);
  }
}

const clone = <T,>(v: T): T => JSON.parse(JSON.stringify(v));

function updateJob(id: string, patch: Partial<Job>) {
  if (!jobs[id]) return;
  jobs[id] = { ...jobs[id], ...patch, updatedAt: Date.now() };
  emit('job', clone(jobs[id]));
}
function updateClip(id: string, patch: Partial<Clip>) {
  if (!clips[id]) return;
  clips[id] = { ...clips[id], ...patch, updatedAt: Date.now() };
  emit('clip', clone(clips[id]));
}
function updatePub(id: string, patch: Partial<Publication>) {
  if (!pubs[id]) return;
  pubs[id] = { ...pubs[id], ...patch, updatedAt: Date.now() };
  const c = clips[pubs[id].clipId];
  if (c) updateClip(c.id, { publish: { ...c.publish, [pubs[id].platform]: { status: pubs[id].status, url: pubs[id].url, publicationId: id } } });
  emit('publication', clone(pubs[id]));
}

const fmt = (s: number) => `${Math.floor(s / 3600)}:${String(Math.floor((s % 3600) / 60)).padStart(2, '0')}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

/** Drives a job through the pipeline over ~40 s, then spits out clips. */
function simulateJob(id: string, opts: { from?: number } = {}) {
  let p = opts.from ?? 0;
  const dur = jobs[id].durationSec || 7200;
  const timer = setInterval(() => {
    const j = jobs[id];
    if (!j || j.status === 'canceled' || j.status === 'error' || j.status === 'done') return clearInterval(timer);
    p = Math.min(1, p + 0.012);
    let patch: Partial<Job> = { progress: p };
    if (p < 0.12) patch = { ...patch, status: 'downloading', stage: j.source.type === 'file' ? 'Importing video' : `Downloading ${Math.round((p / 0.12) * 100)}%` };
    else if (p < 0.5) patch = { ...patch, status: 'transcribing', stage: `Transcribing ${fmt(((p - 0.12) / 0.38) * dur)} / ${fmt(dur)}` };
    else if (p < 0.62) patch = { ...patch, status: 'analyzing', stage: 'Reading the transcript for bangers…' };
    else if (p < 1) {
      patch = { ...patch, status: 'rendering' };
      const n = Math.min(4, Math.floor((p - 0.62) / 0.08) + 1);
      while (j.clipIds.length < n) {
        const i = j.clipIds.length;
        const cid = nid('clip');
        const m = MEDIA[i % MEDIA.length];
        const f = CLIP_FIXTURES[(i + 2) % CLIP_FIXTURES.length];
        clips[cid] = {
          ...clone(clips[`clip_done${(i % 6) + 1}`]),
          ...f,
          id: cid,
          jobId: id,
          rank: i + 1,
          score: 91 - i * 9,
          status: 'rendering',
          progress: 0,
          file: m.mp4,
          thumb: m.jpg,
          publish: {},
          createdAt: Date.now(),
        };
        j.clipIds = [...j.clipIds, cid];
        emit('clip', clone(clips[cid]));
      }
      patch.stage = `Rendering clip ${n} of 4`;
      for (const cid of j.clipIds) {
        const c = clips[cid];
        if (c.status === 'rendering') {
          const np = Math.min(1, c.progress + 0.12);
          updateClip(cid, np >= 1 ? { progress: 1, status: 'ready' } : { progress: np });
        }
      }
    }
    if (p >= 1) {
      for (const cid of j.clipIds) if (clips[cid].status !== 'ready') updateClip(cid, { status: 'ready', progress: 1 });
      patch = { progress: 1, status: 'done', stage: `Done — ${j.clipIds.length} clips` };
      emit('toast', { level: 'success', title: 'Clips ready', message: `${j.source.name} → ${j.clipIds.length} clips` });
    }
    updateJob(id, patch);
  }, 900);
}

function simulateRender(cid: string) {
  updateClip(cid, { status: 'rendering', progress: 0 });
  const t = setInterval(() => {
    const c = clips[cid];
    if (!c) return clearInterval(t);
    const np = Math.min(1, c.progress + 0.09);
    updateClip(cid, np >= 1 ? { status: 'ready', progress: 1 } : { progress: np });
    if (np >= 1) clearInterval(t);
  }, 500);
}

function simulatePublish(pid: string) {
  const t = setInterval(() => {
    const p = pubs[pid];
    if (!p || (p.status !== 'uploading' && p.status !== 'processing')) return clearInterval(t);
    const np = Math.min(1, (p.progress ?? 0) + 0.08);
    if (np >= 1) {
      updatePub(pid, { status: 'published', progress: 1, publishedAt: Date.now(), url: `https://example.com/${p.platform}/${pid}` });
      emit('toast', { level: 'success', message: `Posted to ${p.platform}` });
      clearInterval(t);
    } else updatePub(pid, { progress: np, status: np > 0.7 ? 'processing' : 'uploading' });
  }, 700);
}

/* ───────────── router ───────────── */

const mask = (v: string) => (v ? (v.startsWith('••••') ? v : `••••${v.slice(-4)}`) : '');
function publicSettings(): Settings {
  const s = clone(settings);
  s.anthropicApiKey = mask(s.anthropicApiKey);
  s.transcription.groqApiKey = mask(s.transcription.groqApiKey);
  s.transcription.openaiApiKey = mask(s.transcription.openaiApiKey);
  s.platforms.youtube.clientSecret = mask(s.platforms.youtube.clientSecret);
  s.platforms.tiktok.clientSecret = mask(s.platforms.tiktok.clientSecret);
  s.platforms.instagram.appSecret = mask(s.platforms.instagram.appSecret);
  return s;
}
function deepMerge(base: Record<string, unknown>, over: Record<string, unknown>) {
  for (const [k, v] of Object.entries(over)) {
    if (typeof v === 'string' && v.startsWith('••••')) continue;
    if (v && typeof v === 'object' && !Array.isArray(v) && base[k] && typeof base[k] === 'object') deepMerge(base[k] as Record<string, unknown>, v as Record<string, unknown>);
    else base[k] = v;
  }
}

type Handler = (params: string[], body: any) => unknown; // eslint-disable-line @typescript-eslint/no-explicit-any
const routes: Array<[string, RegExp, Handler]> = [
  ['GET', /^\/api\/jobs$/, () => Object.values(jobs).sort((a, b) => b.createdAt - a.createdAt)],
  [
    'GET',
    /^\/api\/jobs\/([^/]+)$/,
    ([id]) => {
      if (!jobs[id]) throw new ApiError('Job not found', 404);
      return { job: jobs[id], clips: Object.values(clips).filter((c) => c.jobId === id).sort((a, b) => a.rank - b.rank) };
    },
  ],
  [
    'POST',
    /^\/api\/jobs$/,
    (_, body) => {
      const id = nid('job');
      const name = String(body.url).replace(/^https?:\/\/(www\.)?/, '').slice(0, 48);
      addJob({ id, createdAt: Date.now(), source: { type: 'url', name, url: body.url }, options: body.options, durationSec: 5400, thumb: vod2, width: 1920, height: 1080 });
      emit('job', clone(jobs[id]));
      setTimeout(() => simulateJob(id), 600);
      return jobs[id];
    },
  ],
  [
    'DELETE',
    /^\/api\/jobs\/([^/]+)$/,
    ([id]) => {
      delete jobs[id];
      for (const c of Object.values(clips)) if (c.jobId === id) delete clips[c.id];
      emit('job:removed', { id });
      return { ok: true };
    },
  ],
  [
    'POST',
    /^\/api\/jobs\/([^/]+)\/retry$/,
    ([id]) => {
      jobs[id] = { ...jobs[id], status: 'queued', progress: 0, error: null, stage: 'Queued', thumb: jobs[id].thumb ?? vod3, durationSec: jobs[id].durationSec ?? 4800 };
      setTimeout(() => simulateJob(id), 500);
      return jobs[id];
    },
  ],
  [
    'POST',
    /^\/api\/jobs\/([^/]+)\/cancel$/,
    ([id]) => {
      updateJob(id, { status: 'canceled', stage: 'Canceled' });
      return jobs[id];
    },
  ],
  ['GET', /^\/api\/clips$/, () => Object.values(clips).sort((a, b) => b.createdAt - a.createdAt)],
  [
    'GET',
    /^\/api\/clips\/([^/]+)$/,
    ([id]) => {
      if (!clips[id]) throw new ApiError('Clip not found', 404);
      return clips[id];
    },
  ],
  [
    'PATCH',
    /^\/api\/clips\/([^/]+)$/,
    ([id], body) => {
      clips[id] = { ...clips[id], ...body, durationSec: (body.end ?? clips[id].end) - (body.start ?? clips[id].start), updatedAt: Date.now() };
      emit('clip', clone(clips[id]));
      return clips[id];
    },
  ],
  [
    'POST',
    /^\/api\/clips\/([^/]+)\/render$/,
    ([id]) => {
      setTimeout(() => simulateRender(id), 100);
      return { ...clips[id], status: 'pending', progress: 0 };
    },
  ],
  [
    'DELETE',
    /^\/api\/clips\/([^/]+)$/,
    ([id]) => {
      delete clips[id];
      emit('clip:removed', { id });
      return { ok: true };
    },
  ],
  ['GET', /^\/api\/system$/, () => system],
  ['GET', /^\/api\/settings$/, () => publicSettings()],
  [
    'PUT',
    /^\/api\/settings$/,
    (_, body) => {
      deepMerge(settings as unknown as Record<string, unknown>, body);
      system.analyzer = settings.anthropicApiKey ? 'claude' : 'heuristic';
      system.transcription = settings.transcription.provider;
      return publicSettings();
    },
  ],
  ['GET', /^\/api\/accounts$/, () => accounts],
  [
    'POST',
    /^\/api\/auth\/([^/]+)\/disconnect$/,
    ([p]) => {
      const a = accounts[p as Platform];
      if (a) Object.assign(a, { connected: false, name: null, avatar: null });
      return { ok: true };
    },
  ],
  [
    'POST',
    /^\/api\/clips\/([^/]+)\/publish$/,
    ([id], body) =>
      (body.platforms as Platform[]).map((platform) => {
        const scheduled = body.scheduleAt && body.scheduleAt > Date.now() + 5000;
        const p = addPub({
          clipId: id,
          platform,
          status: scheduled ? 'scheduled' : 'uploading',
          scheduledAt: body.scheduleAt ?? Date.now(),
          title: body.title ?? clips[id].title,
          caption: body.caption ?? clips[id].description,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        });
        emit('publication', clone(p));
        if (!scheduled) setTimeout(() => simulatePublish(p.id), 300);
        return p;
      }),
  ],
  ['GET', /^\/api\/publications$/, () => Object.values(pubs)],
  [
    'DELETE',
    /^\/api\/publications\/([^/]+)$/,
    ([id]) => {
      updatePub(id, { status: 'canceled' });
      return { ok: true };
    },
  ],
  [
    'POST',
    /^\/api\/publications\/([^/]+)\/retry$/,
    ([id]) => {
      updatePub(id, { status: 'uploading', progress: 0, error: null });
      setTimeout(() => simulatePublish(id), 300);
      return pubs[id];
    },
  ],
];

const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));

export function installMocks() {
  console.info('%c👺 ClipGoblin mock API enabled (VITE_MOCK=1)', 'color:#c6ff3d;font-weight:bold');

  transport.request = async <T,>(method: string, url: string, body?: unknown): Promise<T> => {
    await delay(120 + Math.random() * 180);
    const path = url.split('?')[0];
    for (const [m, re, h] of routes) {
      const match = method === m && path.match(re);
      if (match) return clone(h(match.slice(1).map(decodeURIComponent), body ?? {})) as T;
    }
    throw new ApiError(`Mock: no route for ${method} ${path}`, 404);
  };

  transport.upload = (file, options, onProgress) => {
    let aborted = false;
    let reject: (e: unknown) => void = () => {};
    const promise = new Promise<Job>((resolve, rej) => {
      reject = rej;
      const total = file.size || 1;
      let loaded = 0;
      const t = setInterval(() => {
        if (aborted) return clearInterval(t);
        loaded = Math.min(total, loaded + total / 25);
        onProgress({ loaded, total });
        if (loaded >= total) {
          clearInterval(t);
          const id = nid('job');
          addJob({ id, createdAt: Date.now(), source: { type: 'file', name: file.name }, options, durationSec: 6400, thumb: vod1, width: 1920, height: 1080 });
          emit('job', clone(jobs[id]));
          setTimeout(() => simulateJob(id), 600);
          resolve(clone(jobs[id]));
        }
      }, 160);
    });
    return {
      promise,
      abort: () => {
        aborted = true;
        reject(new ApiError('Upload canceled', 0));
      },
    };
  };

  transport.events = () => new FakeEventSource();
  transport.frameUrl = (jobId) => jobs[jobId]?.thumb ?? vod1;
  transport.connectUrl = (p) => {
    const a = accounts[p as Platform];
    if (a) Object.assign(a, { connected: true, configured: true, name: `goblin_${p}` });
    return `/settings?connected=${p}`;
  };

  // Keep the live job moving and the in-flight upload progressing.
  simulateJob('job_live', { from: 0.32 });
  for (const p of Object.values(pubs)) if (p.status === 'uploading') simulatePublish(p.id);
}
