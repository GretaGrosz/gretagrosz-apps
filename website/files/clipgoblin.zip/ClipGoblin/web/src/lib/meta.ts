import type { CaptionStyle, Job, JobStatus, Layout, Platform, PublicationStatus } from './types';

export const CATEGORY: Record<string, { label: string; emoji: string; cls: string }> = {
  funny: { label: 'Funny', emoji: '😂', cls: 'border-amber-400/30 bg-amber-400/10 text-amber-200' },
  rage: { label: 'Rage', emoji: '🤬', cls: 'border-rose-500/30 bg-rose-500/10 text-rose-300' },
  wtf: { label: 'WTF', emoji: '🤯', cls: 'border-fuchsia-400/30 bg-fuchsia-400/10 text-fuchsia-200' },
  clutch: { label: 'Clutch', emoji: '🎯', cls: 'border-sky-400/30 bg-sky-400/10 text-sky-200' },
  wholesome: { label: 'Wholesome', emoji: '🥹', cls: 'border-pink-300/30 bg-pink-300/10 text-pink-200' },
  cringe: { label: 'Cringe', emoji: '😬', cls: 'border-orange-400/30 bg-orange-400/10 text-orange-200' },
  weird: { label: 'Weird', emoji: '👽', cls: 'border-goblin-400/30 bg-goblin-400/10 text-goblin-300' },
};
export const categoryMeta = (c: string) =>
  CATEGORY[c] ?? { label: c || 'Clip', emoji: '✨', cls: 'border-white/15 bg-white/5 text-zinc-300' };

export const PLATFORM_META: Record<Platform, { name: string; short: string; color: string; ring: string }> = {
  youtube: { name: 'YouTube Shorts', short: 'YouTube', color: '#ff3d3d', ring: 'ring-red-500/40' },
  tiktok: { name: 'TikTok', short: 'TikTok', color: '#25f4ee', ring: 'ring-cyan-400/40' },
  instagram: { name: 'Instagram Reels', short: 'Instagram', color: '#e1306c', ring: 'ring-pink-500/40' },
};

export const LAYOUTS: { id: Layout; label: string; hint: string }[] = [
  { id: 'auto', label: 'Auto', hint: 'Goblin picks per clip' },
  { id: 'facecam-split', label: 'Facecam split', hint: 'Cam on top, game below' },
  { id: 'blur-fill', label: 'Blur fill', hint: 'Full frame, blurred bars' },
  { id: 'center-crop', label: 'Center crop', hint: 'Punch into the middle' },
];

export const CAPTION_STYLES: { id: CaptionStyle; label: string; hint: string }[] = [
  { id: 'beast', label: 'Beast', hint: 'Huge bold pops' },
  { id: 'karaoke', label: 'Karaoke', hint: 'Word-by-word highlight' },
  { id: 'minimal', label: 'Minimal', hint: 'Clean & quiet' },
  { id: 'chaos', label: 'Chaos', hint: 'Wobble, color, emoji' },
];

export const STYLE_TOGGLES = [
  { key: 'coldOpen', label: 'Cold open', hint: 'Flash the payoff in the first second' },
  { key: 'jumpCuts', label: 'Jump cuts', hint: 'Snip dead air between words' },
  { key: 'progressBar', label: 'Progress bar', hint: 'Retention bar along the bottom' },
  { key: 'hookBanner', label: 'Hook banner', hint: 'Big hook text for the first 3s' },
  { key: 'chaos', label: 'Chaos mode', hint: 'Punch-ins, shakes, extra weirdness' },
] as const;

export const PIPELINE_STEPS = [
  { key: 'download', label: 'Download', urlLabel: 'Download', fileLabel: 'Import' },
  { key: 'transcribe', label: 'Transcribe' },
  { key: 'analyze', label: 'Find moments' },
  { key: 'render', label: 'Render' },
] as const;

export function stepIndex(status: JobStatus): number {
  switch (status) {
    case 'queued':
    case 'downloading':
    case 'probing':
      return 0;
    case 'transcribing':
      return 1;
    case 'analyzing':
      return 2;
    case 'rendering':
      return 3;
    case 'done':
      return 4;
    default:
      return -1;
  }
}

export const isActive = (j: Job) => !['done', 'error', 'canceled'].includes(j.status);

export const JOB_STATUS_LABEL: Record<JobStatus, string> = {
  queued: 'Queued',
  downloading: 'Downloading',
  probing: 'Inspecting',
  transcribing: 'Transcribing',
  analyzing: 'Finding moments',
  rendering: 'Rendering',
  done: 'Done',
  error: 'Failed',
  canceled: 'Canceled',
};

export const PUB_STATUS: Record<PublicationStatus, { label: string; cls: string; dot: string }> = {
  scheduled: { label: 'Scheduled', cls: 'text-hex-300 bg-hex-500/10 border-hex-500/30', dot: 'bg-hex-400' },
  uploading: { label: 'Uploading', cls: 'text-sky-300 bg-sky-500/10 border-sky-500/30', dot: 'bg-sky-400' },
  processing: { label: 'Processing', cls: 'text-sky-300 bg-sky-500/10 border-sky-500/30', dot: 'bg-sky-400' },
  published: { label: 'Live', cls: 'text-goblin-300 bg-goblin-400/10 border-goblin-400/30', dot: 'bg-goblin-400' },
  error: { label: 'Failed', cls: 'text-rose-300 bg-rose-500/10 border-rose-500/30', dot: 'bg-rose-400' },
  canceled: { label: 'Canceled', cls: 'text-zinc-400 bg-white/5 border-white/10', dot: 'bg-zinc-500' },
};

export function scoreColor(score: number): string {
  if (score >= 85) return '#c6ff3d';
  if (score >= 70) return '#8fe86b';
  if (score >= 55) return '#facc15';
  if (score >= 40) return '#fb923c';
  return '#f87171';
}
