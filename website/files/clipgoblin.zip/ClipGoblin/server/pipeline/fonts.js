// Minimal TrueType metrics reader (cmap format 4 + hmtx) so captions and the hook box can be
// measured exactly the way libass will render them — no text runs off the 1080 px frame.
import fs from 'node:fs';
import path from 'node:path';
import { FONTS_DIR } from './ffmpeg.js';

export const FONTS = {
  Impact: path.join(FONTS_DIR, 'Impact.ttf'),
  'Arial Black': path.join(FONTS_DIR, 'Arial Black.ttf'),
  'Arial Rounded MT Bold': path.join(FONTS_DIR, 'Arial Rounded Bold.ttf'),
};

const cache = new Map();

function parse(file) {
  const b = fs.readFileSync(file);
  let base = 0;
  if (b.toString('latin1', 0, 4) === 'ttcf') base = b.readUInt32BE(12);
  const numTables = b.readUInt16BE(base + 4);
  const tables = {};
  for (let i = 0; i < numTables; i++) {
    const r = base + 12 + i * 16;
    tables[b.toString('latin1', r, r + 4)] = { off: b.readUInt32BE(r + 8), len: b.readUInt32BE(r + 12) };
  }
  const head = tables.head.off;
  const unitsPerEm = b.readUInt16BE(head + 18);
  const hhea = tables.hhea.off;
  const nHM = b.readUInt16BE(hhea + 34);
  let asc = b.readInt16BE(hhea + 4); let desc = -b.readInt16BE(hhea + 6);
  if (tables['OS/2']) {
    const os2 = tables['OS/2'].off;
    asc = b.readUInt16BE(os2 + 74); desc = b.readUInt16BE(os2 + 76); // usWinAscent / usWinDescent (what libass uses)
  }
  const hmtx = tables.hmtx.off;
  const advances = new Uint16Array(nHM);
  for (let i = 0; i < nHM; i++) advances[i] = b.readUInt16BE(hmtx + i * 4);

  // cmap: prefer (3,1) format 4.
  const cmap = tables.cmap.off;
  const nSub = b.readUInt16BE(cmap + 2);
  let sub = null;
  for (let i = 0; i < nSub; i++) {
    const pid = b.readUInt16BE(cmap + 4 + i * 8); const eid = b.readUInt16BE(cmap + 6 + i * 8);
    const off = cmap + b.readUInt32BE(cmap + 8 + i * 8);
    if (b.readUInt16BE(off) === 4 && ((pid === 3 && eid === 1) || pid === 0)) { sub = off; if (pid === 3) break; }
  }
  const glyphCache = new Map();
  const glyphOf = (code) => {
    if (glyphCache.has(code)) return glyphCache.get(code);
    let g = 0;
    if (sub != null && code <= 0xffff) {
      const segX2 = b.readUInt16BE(sub + 6);
      const ends = sub + 14; const starts = ends + segX2 + 2; const deltas = starts + segX2; const ranges = deltas + segX2;
      for (let i = 0; i < segX2 / 2; i++) {
        const end = b.readUInt16BE(ends + i * 2);
        if (code > end) continue;
        const start = b.readUInt16BE(starts + i * 2);
        if (code < start) break;
        const delta = b.readInt16BE(deltas + i * 2);
        const ro = b.readUInt16BE(ranges + i * 2);
        if (ro === 0) g = (code + delta) & 0xffff;
        else {
          const gi = b.readUInt16BE(ranges + i * 2 + ro + (code - start) * 2);
          g = gi ? (gi + delta) & 0xffff : 0;
        }
        break;
      }
    }
    glyphCache.set(code, g);
    return g;
  };
  return { unitsPerEm, asc, desc, advances, glyphOf };
}

function font(name) {
  const file = FONTS[name] || FONTS['Arial Black'];
  if (!cache.has(file)) {
    try { cache.set(file, parse(file)); } catch { cache.set(file, null); }
  }
  return cache.get(file);
}

/**
 * Width in output pixels of `text` rendered by libass at ASS font size `size`
 * (libass scales so that winAscent+winDescent == size). scaleX is \fscx / 100; spacing is \fsp.
 */
export function measure(text, fontName, size, { scaleX = 1, spacing = 0 } = {}) {
  const f = font(fontName);
  const chars = [...String(text)];
  if (!f) return chars.length * size * 0.6 * scaleX;
  let units = 0;
  for (const ch of chars) {
    const g = f.glyphOf(ch.codePointAt(0));
    units += f.advances[Math.min(g, f.advances.length - 1)] ?? f.unitsPerEm * 0.5;
  }
  return (units * size / (f.asc + f.desc) + spacing * chars.length) * scaleX;
}

/** Does the font have a glyph for every character? (Avoids tofu boxes.) */
export function hasGlyphs(text, fontName) {
  const f = font(fontName);
  if (!f) return true;
  return [...String(text)].every((ch) => /\s/.test(ch) || f.glyphOf(ch.codePointAt(0)) !== 0);
}

/** Drop characters the font cannot render. */
export function renderable(text, fontName) {
  const f = font(fontName);
  if (!f) return text;
  return [...String(text)].filter((ch) => /\s/.test(ch) || f.glyphOf(ch.codePointAt(0)) !== 0).join('').replace(/\s{2,}/g, ' ').trim();
}
