// Instagram Reels via the Instagram API with Instagram Login (graph.instagram.com).
// Upload: resumable binary upload to rupload.facebook.com first (no public URL needed); if Instagram
// rejects that and settings.publicBaseUrl is set, fall back to video_url pointing at /media/clips.
import path from 'node:path';
import { PublishError, http, readBody, form, isTransientStatus, retryAfter, sleep, isLocalhostUrl } from './util.js';
import fs from 'node:fs';

export const GRAPH_VERSION = 'v26.0';
const AUTH_URL = 'https://www.instagram.com/oauth/authorize';
const TOKEN_URL = 'https://api.instagram.com/oauth/access_token';
const GRAPH = 'https://graph.instagram.com';
const API = `${GRAPH}/${GRAPH_VERSION}`;
const RUPLOAD = `https://rupload.facebook.com/ig-api-upload/${GRAPH_VERSION}`;
const SCOPES = 'instagram_business_basic,instagram_business_content_publish';
const DAY = 24 * 60 * 60 * 1000;

const cfg = (s) => s.platforms?.instagram ?? {};

function apiError(res, body, what) {
  const e = body?.error ?? {};
  const msg = e.error_user_msg || e.message || body?.error_message || body?.error_description || body?._raw || `HTTP ${res.status}`;
  const code = e.code ?? body?.code;
  const rateLimited = [4, 17, 32, 613].includes(code) || res.status === 429;
  let text = `Instagram ${what} failed: ${msg}`;
  if (code === 190) text = 'Instagram access expired or was revoked. Reconnect Instagram in Settings.';
  else if (code === 10 || code === 200) text = `Instagram denied permission (${msg}). Reconnect Instagram and allow content publishing; the account must be a Business or Creator account.`;
  else if (code === 9 && e.error_subcode === 2207042) text = 'Instagram\'s limit of API posts in 24 hours is reached for this account. Try again later.';
  else if (rateLimited) text = `Instagram rate limit hit (${msg}).`;
  return new PublishError(text, {
    transient: isTransientStatus(res.status) || rateLimited || e.is_transient === true,
    status: res.status,
    code: e.error_subcode ? `${code}/${e.error_subcode}` : code,
    retryAfterMs: retryAfter(res),
    reconnect: code === 190,
  });
}

async function graph(method, url, token, params, what, signal) {
  const u = new URL(url);
  const init = { label: 'Instagram', method, signal, headers: { Authorization: `Bearer ${token}` } };
  if (method === 'GET') { for (const [k, v] of Object.entries(params ?? {})) u.searchParams.set(k, v); }
  else init.body = form(params ?? {});
  const res = await http(u.toString(), init);
  const body = await readBody(res);
  if (!res.ok || body?.error) throw apiError(res, body, what);
  return body;
}

export function isHttpsRedirect(uri) {
  try { return new URL(uri).protocol === 'https:'; } catch { return false; }
}

export default {
  id: 'instagram',
  label: 'Instagram',

  isConfigured: (s) => Boolean(cfg(s).appId && cfg(s).appSecret),

  // Meta only accepts https redirect URIs for Instagram Login.
  checkRedirect(redirectUri) {
    if (!isHttpsRedirect(redirectUri)) {
      return 'Instagram only allows HTTPS redirect URIs. Start an HTTPS tunnel to ClipGoblin (for example cloudflared or ngrok) and put its address in Settings → Public base URL, then connect again.';
    }
    return null;
  },

  authorizeUrl({ settings, redirectUri, state }) {
    const u = new URL(AUTH_URL);
    u.search = form({
      client_id: cfg(settings).appId,
      redirect_uri: redirectUri,
      response_type: 'code',
      scope: SCOPES,
      state,
      enable_fb_login: '0',
      force_reauth: 'true',
    }).toString();
    return u.toString();
  },

  async exchangeCode({ settings, code, redirectUri }) {
    const res = await http(TOKEN_URL, {
      label: 'Instagram',
      method: 'POST',
      body: form({
        client_id: cfg(settings).appId,
        client_secret: cfg(settings).appSecret,
        grant_type: 'authorization_code',
        redirect_uri: redirectUri,
        code: String(code).replace(/#_$/, ''),
      }),
    });
    const body = await readBody(res);
    const short = Array.isArray(body.data) ? body.data[0] : body;
    if (!res.ok || !short?.access_token) {
      throw new PublishError(`Instagram sign-in failed: ${body.error_message || body.error?.message || body._raw || `HTTP ${res.status}`}`, {
        transient: isTransientStatus(res.status),
      });
    }
    // Swap the 1-hour token for a 60-day one.
    const u = new URL(`${GRAPH}/access_token`);
    u.search = form({ grant_type: 'ig_exchange_token', client_secret: cfg(settings).appSecret, access_token: short.access_token }).toString();
    const r2 = await http(u.toString(), { label: 'Instagram' });
    const long = await readBody(r2);
    if (!r2.ok || !long.access_token) throw apiError(r2, long, 'long-lived token exchange');
    return {
      access_token: long.access_token,
      expires_at: Date.now() + (long.expires_in ?? 60 * 86400) * 1000,
      issued_at: Date.now(),
      user_id: String(short.user_id ?? ''),
      permissions: short.permissions,
    };
  },

  // Long-lived tokens can be refreshed once they're ≥24 h old; refresh when <20 days remain.
  needsRefresh: (rec) =>
    Boolean(rec.expires_at) && rec.expires_at - Date.now() < 20 * DAY && Date.now() - (rec.issued_at ?? 0) > DAY,

  async refresh(rec) {
    if (rec.expires_at && rec.expires_at < Date.now()) {
      throw new PublishError('Instagram connection expired (not refreshed within 60 days). Reconnect Instagram.', { reconnect: true });
    }
    const u = new URL(`${GRAPH}/refresh_access_token`);
    u.search = form({ grant_type: 'ig_refresh_token', access_token: rec.access_token }).toString();
    const res = await http(u.toString(), { label: 'Instagram' });
    const body = await readBody(res);
    if (!res.ok || !body.access_token) throw apiError(res, body, 'token refresh');
    return { access_token: body.access_token, expires_at: Date.now() + (body.expires_in ?? 60 * 86400) * 1000, issued_at: Date.now() };
  },

  async fetchProfile(rec) {
    const me = await graph('GET', `${API}/me`, rec.access_token, { fields: 'user_id,username,name,profile_picture_url,account_type' }, 'profile lookup');
    return {
      id: me.user_id ? String(me.user_id) : rec.user_id,
      name: me.username ? `@${me.username}` : me.name ?? null,
      username: me.username ?? null,
      avatar: me.profile_picture_url ?? null,
      accountType: me.account_type ?? null,
    };
  },

  note(settings, rec, redirectUri) {
    const notes = ['Needs an Instagram Business or Creator account (Instagram app → Settings → Account type and tools). Instagram allows up to 100 API posts per 24 h.'];
    if (!isHttpsRedirect(redirectUri)) notes.push('Connecting needs an HTTPS address: set Settings → Public base URL to an HTTPS tunnel that points at this server.');
    if (rec?.profile?.accountType && !['BUSINESS', 'MEDIA_CREATOR', 'CREATOR'].includes(rec.profile.accountType)) {
      notes.push(`This account type (${rec.profile.accountType}) cannot publish via the API.`);
    }
    if (rec?.expires_at) notes.push(`Login is valid until ${new Date(rec.expires_at).toLocaleDateString()} and ClipGoblin renews it automatically.`);
    return notes.join(' ');
  },

  setup(redirectUri) {
    return [
      'Switch your Instagram account to a Professional account (Business or Creator) in the Instagram app.',
      'Go to developers.facebook.com → My Apps → Create app. Pick the use case "Manage messaging & content on Instagram" (app type Business).',
      'In the app: Instagram → "API setup with Instagram login". Copy the Instagram app ID and Instagram app secret shown there (they differ from the Meta App ID).',
      'Step "Set up Instagram business login" → Business login settings → OAuth redirect URIs: add exactly ' +
        `${isHttpsRedirect(redirectUri) ? redirectUri : '<your https Public base URL>/api/auth/instagram/callback'} (Meta only accepts HTTPS).`,
      'Instagram needs an HTTPS address that reaches this computer. Run a tunnel such as "cloudflared tunnel --url http://localhost:4777" or "ngrok http 4777" and paste its https URL into Settings → Public base URL.',
      'While the app is in Development mode: App roles → Roles → add your Instagram account as an Instagram Tester, then accept the invite in Instagram (Settings → Website permissions → Apps and websites → Tester invites).',
      'Paste the Instagram app ID and secret into ClipGoblin Settings → Instagram and click Connect.',
    ];
  },

  async publish({ token, filePath, size, meta, settings, onProgress, onStatus, onRemote, signal, pollMs = 10_000, pollTimeoutMs = 15 * 60 * 1000 }) {
    const at = token.access_token;
    const igId = token.profile?.id || token.user_id || 'me';
    const base = { media_type: 'REELS', caption: meta.caption, share_to_feed: 'true' };
    const publicBase = (settings.publicBaseUrl || '').replace(/\/+$/, '');

    let containerId;
    let resumableError = null;
    try {
      // 1) Resumable container + raw bytes to rupload.
      const c = await graph('POST', `${API}/${igId}/media`, at, { ...base, upload_type: 'resumable' }, 'container create', signal);
      containerId = c.id;
      onRemote?.(containerId);
      onProgress(0.05);
      const bytes = await fs.promises.readFile(filePath);
      const up = await http(c.uri || `${RUPLOAD}/${containerId}`, {
        label: 'Instagram upload',
        method: 'POST',
        signal,
        headers: { Authorization: `OAuth ${at}`, offset: '0', file_size: String(size), 'Content-Type': 'application/octet-stream' },
        body: bytes,
      });
      const ub = await readBody(up);
      if (!up.ok || ub?.success === false || ub?.debug_info) {
        const msg = ub?.debug_info?.message || ub?.error?.message || ub?.message || `HTTP ${up.status}`;
        throw new PublishError(`Instagram upload failed: ${msg}`, { transient: isTransientStatus(up.status), status: up.status, code: 'rupload' });
      }
      onProgress(1);
    } catch (err) {
      if (err?.name === 'AbortError') throw err;
      if (!(err instanceof PublishError) || err.transient || err.reconnect) throw err;
      resumableError = err;
      containerId = null;
    }

    if (!containerId) {
      // 2) Fallback: Instagram fetches the clip from our public URL.
      if (!publicBase || isLocalhostUrl(publicBase)) {
        throw new PublishError(
          `${resumableError.message} Direct upload did not work with this Instagram login. Set Settings → Public base URL to an HTTPS tunnel so Instagram can download the clip.`,
          { code: resumableError.code },
        );
      }
      const videoUrl = `${publicBase}/media/clips/${encodeURIComponent(path.basename(filePath))}`;
      const c = await graph('POST', `${API}/${igId}/media`, at, { ...base, video_url: videoUrl }, 'container create', signal);
      containerId = c.id;
      onRemote?.(containerId);
      onProgress(1);
    }

    // 3) Wait for Instagram to transcode.
    onStatus('processing');
    const deadline = Date.now() + pollTimeoutMs;
    let ready = false;
    while (Date.now() < deadline) {
      await sleep(pollMs, signal);
      let st;
      try {
        st = await graph('GET', `${API}/${containerId}`, at, { fields: 'status_code,status' }, 'status check', signal);
      } catch (err) {
        if (err instanceof PublishError && err.transient) continue;
        throw err;
      }
      if (st.status_code === 'FINISHED' || st.status_code === 'PUBLISHED') { ready = true; break; }
      if (st.status_code === 'ERROR') {
        throw new PublishError(`Instagram could not process the video: ${st.status || 'unknown error'}. Reels must be MP4/H.264, 3 s–15 min, ≤300 MB.`);
      }
      if (st.status_code === 'EXPIRED') throw new PublishError('Instagram upload container expired before publishing.', { transient: true });
    }
    if (!ready) throw new PublishError('Instagram is still processing the video after 15 minutes.', { transient: true });

    // 4) Publish, then look up the permalink.
    const pub = await graph('POST', `${API}/${igId}/media_publish`, at, { creation_id: containerId }, 'publish', signal);
    let url = null;
    try {
      const m = await graph('GET', `${API}/${pub.id}`, at, { fields: 'permalink,shortcode' }, 'permalink lookup', signal);
      url = m.permalink || (m.shortcode ? `https://www.instagram.com/reel/${m.shortcode}/` : null);
    } catch { /* published anyway */ }
    return { remoteId: pub.id, url };
  },
};
