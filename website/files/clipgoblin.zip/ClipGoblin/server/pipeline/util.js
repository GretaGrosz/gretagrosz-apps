// Small shared helpers for the pipeline: time formatting, caching, cancellation, concurrency.
import fs from 'node:fs';
import path from 'node:path';
import { paths, writeJsonAtomic } from '../config.js';

export class CanceledError extends Error {
  constructor(msg = 'Canceled') {
    super(msg);
    this.name = 'CanceledError';
    this.canceled = true;
  }
}

export function throwIfAborted(signal) {
  if (signal?.aborted) throw new CanceledError();
}

/** 3725.4 -> "1:02:05", 75 -> "1:15" */
export function fmtTime(sec) {
  sec = Math.max(0, Math.floor(sec || 0));
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const ss = String(s).padStart(2, '0');
  return h ? `${h}:${String(m).padStart(2, '0')}:${ss}` : `${m}:${ss}`;
}

export const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
export const round = (v, d = 2) => Math.round(v * 10 ** d) / 10 ** d;

export function workDir(jobId) {
  const dir = path.join(paths.work, jobId);
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

export function readJson(file, fallback = null) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}
export function writeJson(file, value) {
  writeJsonAtomic(file, value);
}

export function rmrf(p) {
  try { fs.rmSync(p, { recursive: true, force: true }); } catch { /* ignore */ }
}

export function fileExists(p) {
  try { return fs.statSync(p).size > 0; } catch { return false; }
}

/** Counting semaphore: `await sem.run(fn)` runs fn when a slot is free. */
export class Semaphore {
  constructor(n) { this.n = n; this.active = 0; this.waiters = []; }
  async run(fn) {
    if (this.active >= this.n) await new Promise((r) => this.waiters.push(r));
    this.active++;
    try { return await fn(); } finally {
      this.active--;
      this.waiters.shift()?.();
    }
  }
}

/** Throttle a function so it fires at most once per `ms` (trailing call kept). */
export function throttle(fn, ms) {
  let last = 0; let timer = null; let pending = null;
  const fire = () => { last = Date.now(); timer = null; const a = pending; pending = null; fn(...a); };
  const t = (...args) => {
    pending = args;
    const wait = ms - (Date.now() - last);
    if (wait <= 0) { clearTimeout(timer); fire(); } else if (!timer) timer = setTimeout(fire, wait);
  };
  t.flush = () => { if (pending) { clearTimeout(timer); fire(); } };
  t.cancel = () => { clearTimeout(timer); timer = null; pending = null; };
  return t;
}

// Emoji / pictographs: libass can't render color emoji, so on-screen text strips them (no tofu boxes).
const EMOJI_RE = /(?:\p{Extended_Pictographic}|\p{Regional_Indicator}|[\u{1F3FB}-\u{1F3FF}\u{FE0F}\u{200D}\u{20E3}])/gu;
export function stripEmoji(s) {
  return String(s ?? '').replace(EMOJI_RE, '').replace(/\s{2,}/g, ' ').trim();
}

export function cleanError(err) {
  if (!err) return 'Unknown error';
  const msg = String(err.message || err).trim();
  return msg.length > 600 ? `${msg.slice(0, 600)}…` : msg;
}
