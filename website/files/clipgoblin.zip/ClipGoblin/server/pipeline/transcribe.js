// Transcription with word-level timestamps.
//  local  — on-device Whisper via @huggingface/transformers (onnxruntime-node), free.
//  groq   — whisper-large-v3-turbo over HTTP, very fast.
//  openai — whisper-1 over HTTP.
// Output (cached in <workdir>/transcript.json):
//  { provider, model, wordLevel, words: [{w, s, e}], durationSec }
import fs from 'node:fs';
import path from 'node:path';
import { paths } from '../config.js';
import { ffmpeg } from './ffmpeg.js';
import { readPcm, pcmDuration, quietestPoint, maxDb, SR } from './audio.js';
import { fmtTime, readJson, writeJson, round, throwIfAborted, CanceledError } from './util.js';

// ---------------------------------------------------------------- local whisper

/**
 * Word timestamps in transformers.js need a Whisper export that includes cross-attentions.
 * onnx-community publishes those as "<name>_timestamped"; map the plain names onto them.
 */
export function resolveLocalModel(name) {
  const n = String(name || 'onnx-community/whisper-base.en').trim();
  if (/^onnx-community\/whisper-(tiny|base|small|medium|large-v3-turbo)(\.en)?$/.test(n)) return `${n}_timestamped`;
  return n;
}

function modelCached(model) {
  const dir = path.join(paths.models, ...model.split('/'));
  try {
    const onnx = fs.readdirSync(path.join(dir, 'onnx'));
    return onnx.some((f) => f.startsWith('encoder_model')) && onnx.some((f) => f.startsWith('decoder_model_merged'));
  } catch { return false; }
}
export function localModelReady(settingName) {
  return modelCached(resolveLocalModel(settingName));
}

let asrCache = { model: null, promise: null };
async function getLocalAsr(model, onStage) {
  if (asrCache.model === model && asrCache.promise) return asrCache.promise;
  const promise = (async () => {
    const { pipeline, env } = await import('@huggingface/transformers');
    env.cacheDir = paths.models;
    env.allowRemoteModels = true;
    const files = new Map();
    let lastEmit = 0;
    const cached = modelCached(model);
    onStage?.(cached ? 'Loading speech model…' : `Downloading speech model ${model.split('/').pop()}…`);
    return pipeline('automatic-speech-recognition', model, {
      dtype: 'fp32',
      progress_callback: (p) => {
        if (p.status !== 'progress' || !p.total) return;
        files.set(p.file, { loaded: p.loaded, total: p.total });
        if (Date.now() - lastEmit < 500) return;
        lastEmit = Date.now();
        let loaded = 0; let total = 0;
        for (const f of files.values()) { loaded += f.loaded; total += f.total; }
        onStage?.(`Downloading speech model ${(loaded / 1e6).toFixed(0)} / ${(total / 1e6).toFixed(0)} MB (one-time)`);
      },
    });
  })();
  asrCache = { model, promise };
  promise.catch(() => { if (asrCache.promise === promise) asrCache = { model: null, promise: null }; });
  return promise;
}

/** Number of 100 ms frames in [a, b] loud enough to be speech. */
function speechFrames(energy, a, b) {
  const thr = (energy.speechDb ?? -25) - 10;
  let n = 0;
  for (let i = Math.max(0, Math.floor(a / energy.hop)); i < Math.min(energy.db.length, Math.ceil(b / energy.hop)); i++) if (energy.db[i] > thr) n++;
  return n;
}

const NOISE_RE = /^[[(].*[\])]$|^♪+$/;
const HALLUCINATIONS = new Set(['thank you.', 'thanks for watching!', 'thank you for watching.', 'you', 'bye.', '.', '...']);

function cleanChunkWords(chunks, offset, lo, hi) {
  const out = [];
  for (const c of chunks || []) {
    const text = String(c.text ?? '').trim();
    if (!text || NOISE_RE.test(text)) continue;
    let [s, e] = c.timestamp || [];
    if (s == null) continue;
    if (e == null || e < s) e = s + 0.3;
    s = Math.min(Math.max(s + offset, lo), hi);
    e = Math.min(Math.max(e + offset, s + 0.05), hi + 0.3);
    out.push({ w: text, s: round(s, 2), e: round(e, 2) });
  }
  // Drop pure-hallucination chunks ("Thank you." over silence) and runaway repetitions.
  const joined = out.map((x) => x.w).join(' ').toLowerCase();
  if (out.length <= 3 && HALLUCINATIONS.has(joined)) return [];
  const dedup = [];
  for (const w of out) {
    const n = dedup.length;
    if (n >= 4 && dedup.slice(n - 4).every((x) => x.w.toLowerCase() === w.w.toLowerCase())) continue;
    dedup.push(w);
  }
  return dedup;
}

/** Spread words evenly over a segment when only segment timestamps are available. */
function interpolateWords(text, s, e) {
  const toks = String(text).trim().split(/\s+/).filter(Boolean);
  const total = toks.reduce((a, t) => a + t.length + 1, 0) || 1;
  let t = s;
  return toks.map((w) => {
    const d = (e - s) * (w.length + 1) / total;
    const word = { w, s: round(t, 2), e: round(t + d, 2) };
    t += d;
    return word;
  });
}

async function transcribeLocal({ pcmPath, energy, settings, dir, signal, onProgress }) {
  const requested = settings.transcription.localModel || 'onnx-community/whisper-base.en';
  let model = resolveLocalModel(requested);
  let wordLevel = true;
  let asr;
  try {
    asr = await getLocalAsr(model, (s) => onProgress(0, s));
  } catch (e) {
    if (model === requested) throw new Error(`Could not load speech model ${model}: ${e.message}`);
    // No timestamped export for this model: fall back to segment timestamps.
    model = requested;
    wordLevel = false;
    asr = await getLocalAsr(model, (s) => onProgress(0, s));
  }
  throwIfAborted(signal);

  const dur = pcmDuration(pcmPath);
  const partialFile = path.join(dir, 'transcript.partial.json');
  const partial = readJson(partialFile);
  let words = [];
  let cur = 0;
  if (partial && partial.model === model && partial.wordLevel === wordLevel) {
    words = partial.words;
    cur = partial.cur;
  }
  let lastSave = Date.now();
  const t0 = Date.now();
  const startCur = cur;
  while (cur < dur - 0.25) {
    throwIfAborted(signal);
    let end = Math.min(dur, cur + 29.5);
    if (end < dur - 1) end = quietestPoint(energy, cur + 22, cur + 29.3);
    if (end - cur < 1) end = Math.min(dur, cur + 29.5);
    const elapsed = (Date.now() - t0) / 1000;
    const rate = cur > startCur ? elapsed / (cur - startCur) : 0;
    const eta = rate ? ` · ~${fmtTime(rate * (dur - cur))} left` : '';
    onProgress(cur / dur, `Transcribing ${fmtTime(cur)} / ${fmtTime(dur)}${eta}`);
    if (maxDb(energy, cur, end) > -50) {
      const pcm = readPcm(pcmPath, cur, end);
      let res;
      try {
        res = await asr(pcm, { return_timestamps: wordLevel ? 'word' : true });
      } catch (e) {
        if (wordLevel && /cross attentions/i.test(e.message)) {
          wordLevel = false;
          res = await asr(pcm, { return_timestamps: true });
        } else throw e;
      }
      const got = [];
      if (wordLevel) {
        got.push(...cleanChunkWords(res.chunks, cur, cur, end));
      } else {
        for (const seg of res.chunks || []) {
          const [s, e] = seg.timestamp || [];
          if (s == null || NOISE_RE.test(String(seg.text).trim())) continue;
          got.push(...interpolateWords(seg.text, cur + s, Math.min(end, cur + (e ?? end - cur))));
        }
      }
      words.push(...got);
      // Whisper sometimes stops decoding early inside a window. If there is still speech-level
      // audio after the last decoded word, seek there and decode the rest instead of skipping it.
      const lastE = got.length ? got[got.length - 1].e : null;
      if (lastE != null && end - lastE > 2 && lastE - cur > 1 && speechFrames(energy, lastE + 0.3, end) >= 8) {
        cur = lastE + 0.02;
        continue;
      }
    }
    cur = end;
    if (Date.now() - lastSave > 15000) {
      writeJson(partialFile, { model, wordLevel, cur, words });
      lastSave = Date.now();
    }
  }
  onProgress(1, 'Transcript ready');
  try { fs.rmSync(partialFile, { force: true }); } catch { /* ignore */ }
  return { provider: 'local', model, wordLevel, words };
}

// ---------------------------------------------------------------- cloud whisper (groq / openai)

const CLOUD = {
  groq: { url: 'https://api.groq.com/openai/v1/audio/transcriptions', model: 'whisper-large-v3-turbo', key: (s) => s.transcription.groqApiKey, name: 'Groq' },
  openai: { url: 'https://api.openai.com/v1/audio/transcriptions', model: 'whisper-1', key: (s) => s.transcription.openaiApiKey, name: 'OpenAI' },
};

const norm = (s) => String(s).toLowerCase().replace(/[^\p{L}\p{N}']/gu, '');

/** Cloud word lists lack punctuation; borrow it from the segment text. */
function punctuate(words, segments) {
  let si = 0;
  for (const seg of segments || []) {
    const toks = String(seg.text || '').trim().split(/\s+/).filter(Boolean);
    let ti = 0;
    while (si < words.length && words[si].start < seg.end + 0.05 && ti < toks.length) {
      const w = words[si];
      // Look ahead a few tokens for a match.
      let k = ti;
      while (k < Math.min(toks.length, ti + 3) && norm(toks[k]) !== norm(w.word)) k++;
      if (k < toks.length && norm(toks[k]) === norm(w.word)) { w.word = toks[k]; ti = k + 1; }
      si++;
    }
  }
  return words;
}

async function postAudio(cfg, key, file, signal) {
  for (let attempt = 0; ; attempt++) {
    throwIfAborted(signal);
    const form = new FormData();
    form.append('file', new Blob([fs.readFileSync(file)], { type: 'audio/mpeg' }), path.basename(file));
    form.append('model', cfg.model);
    form.append('response_format', 'verbose_json');
    form.append('timestamp_granularities[]', 'word');
    form.append('timestamp_granularities[]', 'segment');
    form.append('temperature', '0');
    let res;
    try {
      res = await fetch(cfg.url, { method: 'POST', headers: { Authorization: `Bearer ${key}` }, body: form, signal });
    } catch (e) {
      if (signal?.aborted) throw new CanceledError();
      if (attempt < 3) { await new Promise((r) => setTimeout(r, 2000 * (attempt + 1))); continue; }
      throw new Error(`${cfg.name} transcription request failed: ${e.cause?.code || e.message}`);
    }
    if (res.ok) return res.json();
    const body = await res.text().catch(() => '');
    if ((res.status === 429 || res.status >= 500) && attempt < 5) {
      const ra = Number(res.headers.get('retry-after')) || 0;
      await new Promise((r) => setTimeout(r, Math.max(ra * 1000, 3000 * 2 ** attempt)));
      continue;
    }
    let msg = body;
    try { msg = JSON.parse(body).error?.message || body; } catch { /* plain */ }
    if (res.status === 401) throw new Error(`${cfg.name} rejected the API key — check Settings → Transcription`);
    throw new Error(`${cfg.name} transcription failed (HTTP ${res.status}): ${String(msg).slice(0, 300)}`);
  }
}

async function transcribeCloud(provider, { pcmPath, energy, settings, dir, signal, onProgress }) {
  const cfg = CLOUD[provider];
  const key = cfg.key(settings);
  if (!key) throw new Error(`No ${cfg.name} API key set — add one in Settings or switch transcription to "local"`);
  const dur = pcmDuration(pcmPath);
  const partsDir = path.join(dir, 'parts');
  fs.mkdirSync(partsDir, { recursive: true });
  const words = [];
  let cur = 0;
  let idx = 0;
  while (cur < dur - 0.25) {
    throwIfAborted(signal);
    let end = Math.min(dur, cur + 600);
    if (end < dur - 1) end = quietestPoint(energy, cur + 540, cur + 599);
    onProgress(cur / dur, `Transcribing with ${cfg.name} ${fmtTime(cur)} / ${fmtTime(dur)}`);
    const cacheFile = path.join(partsDir, `${provider}-${idx}.json`);
    let json = readJson(cacheFile);
    if (!json || json.cur !== cur) {
      const mp3 = path.join(partsDir, `part-${idx}.mp3`);
      await ffmpeg(['-f', 'f32le', '-ar', String(SR), '-ac', '1', '-ss', String(cur), '-t', String(end - cur), '-i', pcmPath,
        '-c:a', 'libmp3lame', '-b:a', '64k', mp3], { signal });
      const res = await postAudio(cfg, key, mp3, signal);
      fs.rmSync(mp3, { force: true });
      json = { cur, res };
      writeJson(cacheFile, json);
    }
    const res = json.res;
    if (Array.isArray(res.words) && res.words.length) {
      punctuate(res.words, res.segments);
      for (const w of res.words) {
        const text = String(w.word).trim();
        if (!text || NOISE_RE.test(text)) continue;
        words.push({ w: text, s: round(cur + w.start, 2), e: round(cur + Math.max(w.end, w.start + 0.05), 2) });
      }
    } else {
      for (const seg of res.segments || []) words.push(...interpolateWords(seg.text, cur + seg.start, cur + seg.end));
    }
    cur = end;
    idx++;
  }
  onProgress(1, 'Transcript ready');
  return { provider, model: cfg.model, wordLevel: true, words };
}

/**
 * Whisper often stretches the last word before a pause across the silence (and sometimes starts
 * the first word after one too early). Trim word edges that sit in quiet audio so jump cuts,
 * clip snapping and caption timing follow the real speech.
 */
export function tightenWords(words, energy) {
  if (!energy?.db?.length) return words;
  const hop = energy.hop;
  const thr = (energy.speechDb ?? -25) - 14;
  const quiet = (t) => (energy.db[Math.floor(t / hop)] ?? -99) < thr;
  for (const w of words) {
    const natural = Math.max(0.35, 0.12 + 0.085 * w.w.length);
    if (w.e - w.s <= natural * 1.6) continue;
    let e = w.e;
    while (e - hop > w.s + natural * 0.6 && quiet(e - hop / 2)) e -= hop;
    let s = w.s;
    while (s + hop < e - natural * 0.6 && e - s > natural * 1.6 && quiet(s + hop / 2)) s += hop;
    w.s = round(s, 2);
    w.e = round(Math.max(s + 0.08, e + 0.05), 2);
  }
  return words;
}

// ---------------------------------------------------------------- entry

export async function transcribe({ pcmPath, energy, settings, dir, signal, onProgress }) {
  const provider = settings.transcription?.provider || 'local';
  const key = provider === 'local' ? resolveLocalModel(settings.transcription.localModel) : CLOUD[provider]?.model;
  const cacheFile = path.join(dir, 'transcript.json');
  const cached = readJson(cacheFile);
  if (cached && cached.provider === provider && (cached.model === key || provider === 'local' && cached.requested === settings.transcription.localModel)) return cached;

  let t;
  if (provider === 'local') t = await transcribeLocal({ pcmPath, energy, settings, dir, signal, onProgress });
  else if (CLOUD[provider]) t = await transcribeCloud(provider, { pcmPath, energy, settings, dir, signal, onProgress });
  else throw new Error(`Unknown transcription provider "${provider}"`);

  // Enforce monotonic, non-overlapping word times.
  t.words.sort((a, b) => a.s - b.s);
  for (let i = 1; i < t.words.length; i++) {
    const p = t.words[i - 1]; const w = t.words[i];
    if (p.e > w.s) p.e = Math.max(p.s + 0.03, w.s);
  }
  tightenWords(t.words, energy);
  const out = { ...t, requested: provider === 'local' ? settings.transcription.localModel : t.model, durationSec: round(pcmDuration(pcmPath), 2) };
  writeJson(cacheFile, out);
  return out;
}
