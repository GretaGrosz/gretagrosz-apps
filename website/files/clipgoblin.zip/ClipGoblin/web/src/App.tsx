import { AnimatePresence, motion } from 'framer-motion';
import { useEffect } from 'react';
import { Route, Routes, useLocation, type Location } from 'react-router-dom';
import { BottomNav, EmptyState, SystemBanner, Toasts, TopNav } from './components/Chrome';
import { useEventStream } from './lib/sse';
import { useStore } from './lib/store';
import ClipEditor from './pages/ClipEditor';
import Home from './pages/Home';
import JobPage from './pages/JobPage';
import Queue from './pages/Queue';
import Settings from './pages/Settings';

function Page({ children }: { children: React.ReactNode }) {
  return (
    <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.22, ease: 'easeOut' }}>
      {children}
    </motion.div>
  );
}

export default function App() {
  const location = useLocation();
  const background = (location.state as { backgroundLocation?: Location } | null)?.backgroundLocation;

  useEventStream();
  useEffect(() => {
    const s = useStore.getState();
    void s.loadJobs();
    void s.loadSettings();
    void s.loadAccounts();
    void s.loadSystem();
    void s.loadPublications();
  }, []);

  // Scroll to top on real page changes (not when opening the clip modal).
  const pageKey = (background ?? location).pathname;
  useEffect(() => {
    if (!location.hash) window.scrollTo({ top: 0 });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pageKey]);

  return (
    <div className="min-h-dvh pb-24 md:pb-0">
      <TopNav />
      <SystemBanner />
      <main>
        <Routes location={background ?? location}>
          <Route path="/" element={<Page><Home /></Page>} />
          <Route path="/jobs/:id" element={<Page><JobPage /></Page>} />
          <Route path="/clips/:id" element={<Page><ClipEditor /></Page>} />
          <Route path="/queue" element={<Page><Queue /></Page>} />
          <Route path="/settings" element={<Page><Settings /></Page>} />
          <Route
            path="*"
            element={
              <div className="mx-auto max-w-xl px-4 py-20">
                <EmptyState mood="hunt" title="Nothing down this tunnel" body="That page doesn't exist." />
              </div>
            }
          />
        </Routes>
      </main>
      <AnimatePresence>
        {background && (
          <Routes>
            <Route path="/clips/:id" element={<ClipEditor asModal />} />
          </Routes>
        )}
      </AnimatePresence>
      <BottomNav />
      <Toasts />
    </div>
  );
}
