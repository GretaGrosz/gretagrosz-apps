// Vertical 1080×1920 renderer: layout (facecam split / blur fill / center crop), jump cuts,
// cold open, animated captions + hook banner (ASS), chaos punch-ins, retention progress bar,
// −14 LUFS loudness — all in a single ffmpeg filter graph.
import fs from 'node:fs';
import path from 'node:path';
import { paths } from '../config.js';
import { ffmpeg, run, FFMPEG, FONTS_DIR } from './ffmpeg.js';
import { buildAss, hashStr } from './captions.js';
import { meanDb } from './audio.js';
import { round, clamp, workDir } from './util.js';

const W = 1080;
const H = 1920;
const FPS = 30;
const even = (v) => Math.max(2, Math.round(v / 2) * 2);

export function effectiveStyle(job, clip) {
  const s = { ...(job?.options || {}), ...(clip?.style || {}) };
  if (clip?.style?.facecam === undefined) s.facecam = job?.options?.facecam ?? null;
  return s;
}

export function resolveLayout(style, src) {
  let layout = style.layout || 'auto';
  if (layout === 'auto') layout = style.facecam ? 'facecam-split' : 'blur-fill';
  if (layout === 'facecam-split' && !style.facecam) layout = 'blur-fill';
  if (src.height > src.width * 1.2) layout = 'center-crop'; // already vertical: just fill
  return layout;
}

/**
 * Work out what to keep from the source: cold-open slice + main segments with dead air removed.
 * Returns { segments: [{a, b, kind}], outDur, coldOpenDur, cutsAt: [outT], map(srcT) }.
 */
export function planSegments({ clip, words, energy, style }) {
  const start = clip.start; const end = clip.end;
  const ws = words.filter((w) => w.e > start + 0.02 && w.s < end - 0.02);
  let main = [{ a: start, b: end }];
  const speech = energy?.speechDb ?? -25;

  if (style.jumpCuts && ws.length >= 2) {
    const quiet = (a, b) => b - a > 0 && meanDb(energy, a, b) < speech - 6;
    main = [];
    let segA = start;
    // Trim dead air before the first word.
    if (ws[0].s - start > 0.5 && quiet(start, ws[0].s - 0.1)) segA = Math.max(start, ws[0].s - 0.12);
    for (let i = 1; i < ws.length; i++) {
      const p = ws[i - 1]; const w = ws[i];
      const gap = w.s - p.e;
      if (gap > 0.35) {
        const cutA = p.e + 0.08; const cutB = w.s - 0.08;
        // Keep loud gaps: an untranscribed scream/laugh is the best part of the clip.
        if (cutB - cutA > 0.18 && quiet(cutA, cutB)) {
          main.push({ a: segA, b: cutA });
          segA = cutB;
        }
      }
    }
    let segB = end;
    const last = ws[ws.length - 1];
    if (end - last.e > 0.6 && quiet(last.e + 0.25, end)) segB = Math.min(end, last.e + 0.3);
    main.push({ a: segA, b: segB });
    main = main.filter((s) => s.b - s.a > 0.12);
    if (!main.length) main = [{ a: start, b: end }];
  }

  const segments = [];
  let coldOpenDur = 0;
  const co = clip.coldOpen;
  if (style.coldOpen !== false && co && co.end - co.start >= 0.3 && co.start >= start && co.end <= end + 0.01) {
    const coEnd = Math.min(co.end, co.start + 1.5);
    segments.push({ a: co.start, b: coEnd, kind: 'cold' });
    coldOpenDur = coEnd - co.start;
  }
  for (const s of main) segments.push({ ...s, kind: 'main' });

  let t = 0;
  for (const s of segments) { s.outA = t; t += s.b - s.a; }
  const outDur = t;
  const cutsAt = segments.slice(1).map((s) => s.outA);
  const mainSegs = segments.filter((s) => s.kind === 'main');
  const map = (srcT, segs = mainSegs) => {
    for (const s of segs) if (srcT >= s.a - 0.001 && srcT <= s.b + 0.001) return s.outA + (srcT - s.a);
    return null;
  };
  return { segments, outDur, coldOpenDur, cutsAt, map, mainSegs };
}

/** Words re-timed onto the output timeline (cold-open words included), with a loudness flag. */
export function retimeWords({ plan, words, energy }) {
  const out = [];
  const speech = energy?.speechDb ?? -25;
  for (const seg of plan.segments) {
    for (const w of words) {
      if (w.e <= seg.a + 0.03 || w.s >= seg.b - 0.03) continue;
      const s = seg.outA + Math.max(0, w.s - seg.a);
      const e = seg.outA + Math.min(seg.b, w.e) - seg.a;
      if (e - s < 0.03) continue;
      out.push({ w: w.w, s: round(s, 3), e: round(e, 3), loud: meanDb(energy, w.s, w.e) > speech + 5 });
    }
  }
  return out.sort((a, b) => a.s - b.s);
}

function layoutGeometry(layout) {
  // Caption + hook placement per layout (centre y of each), all inside the safe zone.
  if (layout === 'facecam-split') return { captionY: 770, hookY: 300 };
  if (layout === 'blur-fill') return { captionY: 1370, hookY: 380, fgY: 540 };
  return { captionY: 1250, hookY: 330 };
}

function layoutFilter(layout, src, style, inLabel, outLabel) {
  const sw = src.width; const sh = src.height;
  const f = [];
  if (layout === 'facecam-split') {
    const camH = 768; const gameH = H - camH;
    const fc = style.facecam;
    // Facecam: largest crop of the target aspect inside the selected rect (cover).
    let rx = fc.x * sw; let ry = fc.y * sh; let rw = fc.w * sw; let rh = fc.h * sh;
    const A = W / camH;
    if (rw / rh > A) { const nw = rh * A; rx += (rw - nw) / 2; rw = nw; } else { const nh = rw / A; ry += (rh - nh) / 2; rh = nh; }
    const cw = even(clamp(rw, 16, sw)); const ch = even(clamp(rh, 16, sh));
    const cx = even(clamp(rx, 0, sw - cw)); const cy = even(clamp(ry, 0, sh - ch));
    // Gameplay: centre crop of the bottom panel's aspect, full height.
    const gA = W / gameH;
    let gw = even(sh * gA); let gh = even(sh);
    if (gw > sw) { gw = even(sw); gh = even(sw / gA); }
    const gx = even((sw - gw) / 2); const gy = even((sh - gh) / 2);
    f.push(`[${inLabel}]split=2[fc_in][gp_in]`);
    f.push(`[fc_in]crop=${cw}:${ch}:${cx}:${cy},scale=${W}:${camH}:flags=lanczos,setsar=1[fc]`);
    f.push(`[gp_in]crop=${gw}:${gh}:${gx}:${gy},scale=${W}:${gameH}:flags=lanczos,setsar=1[gp]`);
    f.push(`[fc][gp]vstack=inputs=2,drawbox=x=0:y=${camH - 4}:w=${W}:h=8:color=0x0B0B0F@1:t=fill[${outLabel}]`);
  } else if (layout === 'blur-fill') {
    const g = layoutGeometry('blur-fill');
    // Foreground: trim 6% off each side (slight zoom), full width.
    const cw = even(sw * 0.88); const cx = even((sw - cw) / 2);
    const fgH = even(W * sh / cw);
    f.push(`[${inLabel}]split=2[bg_in][fg_in]`);
    f.push(`[bg_in]scale=270:480:force_original_aspect_ratio=increase,crop=270:480,boxblur=10:3,scale=${W}:${H},eq=brightness=-0.13:saturation=1.3,setsar=1[bg]`);
    f.push(`[fg_in]crop=${cw}:${sh}:${cx}:0,scale=${W}:${fgH}:flags=lanczos,setsar=1[fg]`);
    f.push(`[bg][fg]overlay=x=0:y=${g.fgY}[${outLabel}]`);
  } else {
    f.push(`[${inLabel}]scale=${W}:${H}:force_original_aspect_ratio=increase:flags=lanczos,crop=${W}:${H},setsar=1[${outLabel}]`);
  }
  return f;
}

const between = (iv) => iv.map(([a, b]) => `between(t,${a.toFixed(3)},${b.toFixed(3)})`).join('+');

/**
 * Build the complete ffmpeg invocation for a clip.
 * Returns { args, outDur, assPath, graphPath }.
 */
export function buildRender({ job, clip, words, energy, src, outFile, dir }) {
  const style = effectiveStyle(job, clip);
  const layout = resolveLayout(style, src);
  const plan = planSegments({ clip, words, energy, style });
  const geo = layoutGeometry(layout);
  const D = plan.outDur;

  // --- captions + hook (.ass)
  const capWords = retimeWords({ plan, words, energy });
  const hookDuration = style.hookBanner !== false && clip.hook
    ? Math.min(D - 0.3, plan.coldOpenDur ? plan.coldOpenDur + 2.6 : 3.2) : 0;
  const ass = buildAss(capWords, {
    captionStyle: style.captionStyle || 'beast',
    captions: style.captionStyle !== 'none',
    captionY: geo.captionY,
    hook: clip.hook,
    hookY: geo.hookY,
    hookDuration,
    seed: hashStr(clip.id),
  });
  const assPath = path.join(dir, `${clip.id}.ass`);
  fs.writeFileSync(assPath, ass);

  // --- input window (accurate seek; filter times are relative to inStart)
  const inStart = Math.max(0, Math.min(...plan.segments.map((s) => s.a)) - 0.05);
  const inEnd = Math.max(...plan.segments.map((s) => s.b)) + 0.05;
  const rel = (t) => Math.max(0, t - inStart).toFixed(3);

  const g = [];
  const n = plan.segments.length;
  g.push(`[0:v]fps=${FPS},split=${n}${plan.segments.map((_, i) => `[vs${i}]`).join('')}`);
  g.push(`[${src.hasAudio ? '0:a' : '1:a'}]aformat=sample_rates=48000:channel_layouts=stereo,asplit=${n}${plan.segments.map((_, i) => `[as${i}]`).join('')}`);
  plan.segments.forEach((s, i) => {
    const d = s.b - s.a;
    const fd = Math.min(0.015, d / 4).toFixed(3);
    g.push(`[vs${i}]trim=start=${rel(s.a)}:end=${rel(s.b)},setpts=PTS-STARTPTS[v${i}]`);
    g.push(`[as${i}]atrim=start=${rel(s.a)}:end=${rel(s.b)},asetpts=PTS-STARTPTS,afade=t=in:d=${fd},afade=t=out:st=${Math.max(0, d - Number(fd)).toFixed(3)}:d=${fd}[a${i}]`);
  });
  g.push(`${plan.segments.map((_, i) => `[v${i}][a${i}]`).join('')}concat=n=${n}:v=1:a=1[vcat][acat]`);

  // --- layout
  g.push(...layoutFilter(layout, src, style, 'vcat', 'base0'));
  let cur = 'base0';

  // --- punch-in zooms: alternate zoom on jump cuts (hides the cut), chaos punch-ins on loud spikes.
  const cutZoom = [];
  if (style.jumpCuts) {
    // Toggle zoom at each cut (classic jump-cut punch-in), but don't flicker on very short segments.
    let zoomed = false;
    plan.mainSegs.forEach((seg, i) => {
      const prev = plan.mainSegs[i - 1];
      if (prev && prev.b - prev.a > 0.8) zoomed = !zoomed;
      if (zoomed) cutZoom.push([seg.outA, seg.outA + (seg.b - seg.a)]);
    });
  }
  const chaosZoom = [];
  if (style.chaos) {
    const spikes = (energy?.spikes || [])
      .map((sp) => plan.map(sp.peakT))
      .filter((t) => t != null)
      .sort((a, b) => a - b);
    let lastT = -10;
    for (const t of spikes) {
      if (t - lastT < 3) continue;
      chaosZoom.push([Math.max(0, t - 0.1), Math.min(D, t + 0.7)]);
      lastT = t;
    }
    if (capWords.length) { // quick zoom on the last word
      const lw = capWords[capWords.length - 1];
      chaosZoom.push([Math.max(0, lw.s - 0.05), Math.min(D, lw.e + 0.4)]);
    }
  }
  if (plan.coldOpenDur) cutZoom.push([0, plan.coldOpenDur]); // punchy cold open
  const zooms = [];
  if (cutZoom.length) zooms.push({ z: 1.08, iv: cutZoom, shake: 0 });
  if (chaosZoom.length) zooms.push({ z: 1.18, iv: chaosZoom, shake: 9 });
  zooms.forEach((zm, k) => {
    const zw = even(W * zm.z); const zh = even(H * zm.z);
    const sx = zm.shake ? `+${zm.shake}*sin(t*61)` : ''; const sy = zm.shake ? `+${zm.shake}*cos(t*47)` : '';
    g.push(`[${cur}]split=2[zb${k}][zi${k}]`);
    g.push(`[zi${k}]scale=${zw}:${zh},crop=${W}:${H}:x='(iw-ow)/2${sx}':y='(ih-oh)/2${sy}'[zz${k}]`);
    g.push(`[zb${k}][zz${k}]overlay=0:0:enable='${between(zm.iv)}'[zo${k}]`);
    cur = `zo${k}`;
  });

  // --- cold-open "rewind" flash
  if (plan.coldOpenDur) {
    const T = plan.coldOpenDur;
    g.push(`[${cur}]drawbox=x=0:y=0:w=iw:h=ih:color=white@0.9:t=fill:enable='between(t,${(T - 0.04).toFixed(3)},${(T + 0.05).toFixed(3)})',`
      + `drawbox=x=0:y=0:w=iw:h=ih:color=white@0.45:t=fill:enable='between(t,${(T + 0.05).toFixed(3)},${(T + 0.12).toFixed(3)})',`
      + `drawbox=x=0:y=0:w=iw:h=ih:color=white@0.18:t=fill:enable='between(t,${(T + 0.12).toFixed(3)},${(T + 0.2).toFixed(3)})'[flash]`);
    cur = 'flash';
  }

  // --- captions + hook
  g.push(`[${cur}]ass=filename=${path.basename(assPath)}:fontsdir=${FONTS_DIR}[capd]`);
  cur = 'capd';

  // --- progress bar
  if (style.progressBar !== false) {
    const bh = 16;
    g.push(`color=c=0xFFD60A:s=${W}x${bh}:r=${FPS}:d=${(D + 0.5).toFixed(3)}[bar]`);
    g.push(`[${cur}]drawbox=x=0:y=0:w=${W}:h=${bh}:color=black@0.55:t=fill[pbg]`);
    g.push(`[pbg][bar]overlay=x='-w+w*t/${D.toFixed(3)}':y=0:eval=frame:shortest=0:eof_action=pass[pb]`);
    cur = 'pb';
  }
  g.push(`[${cur}]format=yuv420p[vout]`);

  // --- audio: whoosh on the rewind, loudness normalise to −14 LUFS
  let aCur = 'acat';
  if (plan.coldOpenDur) {
    const T = plan.coldOpenDur;
    const delay = Math.max(0, Math.round((T - 0.22) * 1000));
    g.push(`anoisesrc=d=0.4:c=pink:r=48000:a=0.6,highpass=f=900,lowpass=f=7000,afade=t=in:d=0.22,afade=t=out:st=0.22:d=0.18,volume=0.5,aformat=sample_rates=48000:channel_layouts=stereo,adelay=${delay}|${delay}[whoosh]`);
    g.push(`[acat][whoosh]amix=inputs=2:duration=first:normalize=0[amix]`);
    aCur = 'amix';
  }
  g.push(`[${aCur}]loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo[aout]`);

  const graphPath = path.join(dir, `${clip.id}.graph.txt`);
  fs.writeFileSync(graphPath, g.join(';\n'));

  const audioInput = src.hasAudio ? [] : ['-f', 'lavfi', '-t', (inEnd - inStart).toFixed(3), '-i', 'anullsrc=r=48000:cl=stereo'];
  const args = [
    '-ss', inStart.toFixed(3), '-t', (inEnd - inStart).toFixed(3), '-i', job.videoPath,
    ...audioInput,
    '-filter_complex_script', path.basename(graphPath),
    '-map', '[vout]', '-map', '[aout]',
    '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-profile:v', 'high', '-pix_fmt', 'yuv420p',
    '-r', String(FPS), '-g', String(FPS * 2),
    '-c:a', 'aac', '-b:a', '160k', '-ar', '48000',
    '-t', D.toFixed(3),
    '-movflags', '+faststart',
    outFile,
  ];
  return { args, outDur: D, plan, layout, assPath, graphPath };
}

/** Render a clip to paths.clips/<clipId>.mp4 (+ .jpg). onProgress(0..1). */
export async function renderClip({ job, clip, words, energy, src, signal, onProgress }) {
  const dir = path.join(workDir(job.id), 'render');
  fs.mkdirSync(dir, { recursive: true });
  const tmpOut = path.join(dir, `${clip.id}.tmp.mp4`);
  const { args, outDur, layout } = buildRender({ job, clip, words, energy, src, outFile: tmpOut, dir });
  try {
    await ffmpegIn(dir, args, { signal, onProgress: (t) => onProgress?.(clamp(t / outDur, 0, 0.98)) });
  } catch (e) {
    fs.rmSync(tmpOut, { force: true });
    throw e;
  }

  const finalMp4 = path.join(paths.clips, `${clip.id}.mp4`);
  const thumb = path.join(paths.clips, `${clip.id}.jpg`);
  fs.renameSync(tmpOut, finalMp4);
  await ffmpeg(['-ss', String(Math.min(1.2, outDur / 2)), '-i', finalMp4, '-frames:v', '1', '-vf', 'scale=540:-2', '-q:v', '3', thumb], { signal });
  onProgress?.(1);
  return { durationSec: round(outDur, 2), layout, file: finalMp4, thumb };
}

// ffmpeg resolves the .ass / graph script relative to cwd — run inside the render dir.
function ffmpegIn(cwd, args, { signal, onProgress }) {
  return run(FFMPEG, ['-hide_banner', '-nostdin', '-y', '-progress', 'pipe:1', '-nostats', ...args], {
    cwd,
    signal,
    onStdoutLine: (line) => {
      const m = /^out_time_(?:us|ms)=(\d+)/.exec(line);
      if (m) onProgress?.(Number(m[1]) / 1e6);
    },
  });
}
