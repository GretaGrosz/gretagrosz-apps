// Audio: extract 16 kHz mono float PCM, compute a loudness curve and find hype spikes
// (screams, laughter, rage, "NO WAY") — strong highlight signals for the analyzer.
import fs from 'node:fs';
import path from 'node:path';
import { ffmpeg } from './ffmpeg.js';
import { fileExists, readJson, writeJson, round } from './util.js';

export const SR = 16000;
export const HOP = 0.1; // seconds per energy frame

/** Extract mono 16k f32le PCM to <dir>/audio.f32 (cached). */
export async function extractPcm(videoPath, dir, durationSec, { signal, onProgress } = {}) {
  const out = path.join(dir, 'audio.f32');
  if (fileExists(out) && fileExists(path.join(dir, 'audio.done'))) return out;
  await ffmpeg(['-i', videoPath, '-vn', '-sn', '-dn', '-ac', '1', '-ar', String(SR), '-af', 'aresample=async=1',
    '-f', 'f32le', '-c:a', 'pcm_f32le', out], {
    signal,
    onProgress: (t) => onProgress?.(Math.min(1, t / (durationSec || 1))),
  });
  fs.writeFileSync(path.join(dir, 'audio.done'), '1');
  return out;
}

/** Read samples [startSec, endSec) from the PCM file as a Float32Array. */
export function readPcm(pcmPath, startSec, endSec) {
  const fd = fs.openSync(pcmPath, 'r');
  try {
    const total = fs.fstatSync(fd).size / 4;
    const a = Math.max(0, Math.floor(startSec * SR));
    const b = Math.min(total, Math.floor(endSec * SR));
    const n = Math.max(0, b - a);
    const buf = Buffer.alloc(n * 4);
    fs.readSync(fd, buf, 0, n * 4, a * 4);
    return new Float32Array(buf.buffer, buf.byteOffset, n);
  } finally {
    fs.closeSync(fd);
  }
}

export function pcmDuration(pcmPath) {
  return fs.statSync(pcmPath).size / 4 / SR;
}

function median(arr) {
  if (!arr.length) return -60;
  const s = [...arr].sort((a, b) => a - b);
  return s[Math.floor(s.length / 2)];
}
function percentile(arr, p) {
  if (!arr.length) return -60;
  const s = [...arr].sort((a, b) => a - b);
  return s[Math.min(s.length - 1, Math.floor(s.length * p))];
}

/**
 * Loudness analysis (cached in <dir>/energy.json):
 *  db[]      — RMS dBFS per 100 ms frame
 *  sec[]     — per-second loudness (dB)
 *  spikes[]  — {t, end, peakDb, rise} moments that jump well above the local baseline
 *  speechDb  — typical loudness of active speech
 */
export function analyzeEnergy(pcmPath, dir) {
  const cacheFile = path.join(dir, 'energy.json');
  const cached = readJson(cacheFile);
  if (cached?.version === 2) return cached;

  const frame = Math.round(SR * HOP);
  const fd = fs.openSync(pcmPath, 'r');
  const db = [];
  try {
    const chunkFrames = 600; // 60 s per read
    const buf = Buffer.alloc(frame * chunkFrames * 4);
    let pos = 0;
    for (;;) {
      const n = fs.readSync(fd, buf, 0, buf.length, pos);
      if (n <= 0) break;
      pos += n;
      const f = new Float32Array(buf.buffer, buf.byteOffset, Math.floor(n / 4));
      // buf.length is a whole number of frames, so only the final read can end mid-frame.
      for (let i = 0; i < f.length; i += frame) {
        const end = Math.min(f.length, i + frame);
        let sum = 0;
        for (let j = i; j < end; j++) sum += f[j] * f[j];
        const rms = Math.sqrt(sum / Math.max(1, end - i));
        db.push(round(20 * Math.log10(rms + 1e-7), 1));
      }
      if (n < buf.length) break;
    }
  } finally {
    fs.closeSync(fd);
  }

  // Per-second loudness = energy mean (in linear domain) over 10 frames.
  const sec = [];
  for (let i = 0; i < db.length; i += 10) {
    const slice = db.slice(i, i + 10);
    const lin = slice.reduce((a, d) => a + 10 ** (d / 10), 0) / slice.length;
    sec.push(round(10 * Math.log10(lin + 1e-12), 1));
  }

  const active = db.filter((d) => d > -45);
  const speechDb = round(median(active.length ? active : db), 1);
  const loudDb = round(percentile(active.length ? active : db, 0.9), 1);

  // Spikes: 0.5 s smoothed energy vs. rolling 40 s median baseline.
  const smooth = db.map((_, i) => {
    const s = db.slice(Math.max(0, i - 2), i + 3);
    return 10 * Math.log10(s.reduce((a, d) => a + 10 ** (d / 10), 0) / s.length + 1e-12);
  });
  const baseline = sec.map((_, i) => median(sec.slice(Math.max(0, i - 20), i + 20).filter((d) => d > -50)));
  const spikes = [];
  let cur = null;
  for (let i = 0; i < smooth.length; i++) {
    const t = i * HOP;
    const base = baseline[Math.floor(t)] ?? speechDb;
    const rise = smooth[i] - Math.max(base, speechDb - 3);
    const hot = rise > 5 && smooth[i] > -32;
    if (hot) {
      if (!cur || t - cur.end > 0.6) {
        cur = { t, end: t + HOP, peakDb: smooth[i], peakT: t, rise };
        spikes.push(cur);
      } else {
        cur.end = t + HOP;
        if (smooth[i] > cur.peakDb) { cur.peakDb = smooth[i]; cur.peakT = t; }
        cur.rise = Math.max(cur.rise, rise);
      }
    }
  }
  const out = {
    version: 2,
    hop: HOP,
    db,
    sec,
    speechDb,
    loudDb,
    spikes: spikes
      .filter((s) => s.end - s.t >= 0.3)
      .map((s) => ({ t: round(s.t, 1), end: round(s.end, 1), peakT: round(s.peakT, 1), peakDb: round(s.peakDb, 1), rise: round(s.rise, 1) })),
  };
  writeJson(cacheFile, out);
  return out;
}

/** Mean dB of the energy curve over [a, b). */
export function meanDb(energy, a, b) {
  const i0 = Math.max(0, Math.floor(a / energy.hop));
  const i1 = Math.min(energy.db.length, Math.max(i0 + 1, Math.ceil(b / energy.hop)));
  const s = energy.db.slice(i0, i1);
  if (!s.length) return -90;
  return 10 * Math.log10(s.reduce((acc, d) => acc + 10 ** (d / 10), 0) / s.length + 1e-12);
}
export function maxDb(energy, a, b) {
  const i0 = Math.max(0, Math.floor(a / energy.hop));
  const i1 = Math.min(energy.db.length, Math.max(i0 + 1, Math.ceil(b / energy.hop)));
  let m = -120;
  for (let i = i0; i < i1; i++) m = Math.max(m, energy.db[i]);
  return m;
}

/** Quietest 100 ms frame time within [a, b] (used to cut ASR chunks between words). */
export function quietestPoint(energy, a, b) {
  const i0 = Math.max(0, Math.floor(a / energy.hop));
  const i1 = Math.min(energy.db.length - 1, Math.ceil(b / energy.hop));
  let best = i1; let bestV = Infinity;
  for (let i = i0; i <= i1; i++) {
    // Prefer the centre of a quiet stretch: sum over a 300 ms neighbourhood.
    const v = (energy.db[i - 1] ?? 0) + energy.db[i] + (energy.db[i + 1] ?? 0);
    if (v < bestV) { bestV = v; best = i; }
  }
  return best * energy.hop + energy.hop / 2;
}
