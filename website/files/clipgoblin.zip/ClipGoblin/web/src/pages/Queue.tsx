import clsx from 'clsx';
import { AnimatePresence, motion } from 'framer-motion';
import { CalendarClock, CheckCircle2, ExternalLink, Radio, RotateCcw, X, XCircle } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { PlatformIcon } from '../components/Brand';
import { EmptyState } from '../components/Chrome';
import { PublicationRow } from '../components/Publish';
import { ProgressBar, Segmented, Skeleton } from '../components/ui';
import { api, errMsg } from '../lib/api';
import { fmtClock, fmtDayLabel, timeUntil } from '../lib/format';
import { PLATFORM_META, PUB_STATUS } from '../lib/meta';
import { toast, useStore } from '../lib/store';
import type { Publication } from '../lib/types';

const UPCOMING = new Set(['scheduled', 'uploading', 'processing']);

export default function Queue() {
  const pubsMap = useStore((s) => s.publications);
  const clips = useStore((s) => s.clips);
  const loaded = useStore((s) => s.loaded.publications);
  const [tab, setTab] = useState<'upcoming' | 'history'>('upcoming');
  const [, tick] = useState(0);

  useEffect(() => {
    void useStore.getState().loadPublications();
    void useStore.getState().loadClips();
    const t = setInterval(() => tick((n) => n + 1), 30_000); // keep countdowns fresh
    return () => clearInterval(t);
  }, []);

  const pubs = useMemo(() => Object.values(pubsMap), [pubsMap]);
  const upcoming = useMemo(
    () =>
      pubs
        .filter((p) => UPCOMING.has(p.status))
        .sort((a, b) => {
          const ra = a.status === 'scheduled' ? 1 : 0;
          const rb = b.status === 'scheduled' ? 1 : 0;
          return ra - rb || a.scheduledAt - b.scheduledAt;
        }),
    [pubs],
  );
  const history = useMemo(
    () =>
      pubs
        .filter((p) => !UPCOMING.has(p.status))
        .sort((a, b) => (b.publishedAt ?? b.updatedAt ?? b.scheduledAt) - (a.publishedAt ?? a.updatedAt ?? a.scheduledAt)),
    [pubs],
  );
  const stats = {
    scheduled: pubs.filter((p) => p.status === 'scheduled').length,
    live: pubs.filter((p) => p.status === 'published').length,
    failed: pubs.filter((p) => p.status === 'error').length,
  };

  const groups = useMemo(() => {
    const out: { label: string; items: Publication[] }[] = [];
    for (const p of upcoming) {
      const label = p.status === 'scheduled' ? fmtDayLabel(p.scheduledAt) : 'In flight';
      const g = out.find((x) => x.label === label);
      if (g) g.items.push(p);
      else out.push({ label, items: [p] });
    }
    return out;
  }, [upcoming]);

  return (
    <div className="mx-auto max-w-4xl px-4 pb-28 pt-8 sm:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-extrabold tracking-tight text-white">Publishing queue</h1>
          <p className="mt-1 text-sm text-zinc-400">Everything scheduled, in flight, and already out in the wild.</p>
        </div>
        <Segmented
          value={tab}
          onChange={setTab}
          options={[
            { value: 'upcoming', label: `Upcoming${upcoming.length ? ` · ${upcoming.length}` : ''}` },
            { value: 'history', label: 'History' },
          ]}
        />
      </div>

      <div className="mt-6 grid grid-cols-3 gap-2 sm:gap-3">
        <Stat icon={<CalendarClock className="h-4 w-4" />} label="Scheduled" value={stats.scheduled} tone="hex" />
        <Stat icon={<CheckCircle2 className="h-4 w-4" />} label="Live" value={stats.live} tone="goblin" />
        <Stat icon={<XCircle className="h-4 w-4" />} label="Failed" value={stats.failed} tone="rose" />
      </div>

      <div className="mt-8">
        {!loaded ? (
          <div className="space-y-3">
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} className="h-24" />
            ))}
          </div>
        ) : tab === 'upcoming' ? (
          upcoming.length === 0 ? (
            <EmptyState
              mood="sleep"
              title="Nothing scheduled"
              body="The goblin is napping. Select clips on a VOD and hit Publish — or turn on Autopilot and let it post for you."
              action={
                <div className="flex flex-wrap justify-center gap-2">
                  <Link to="/" className="btn btn-primary">
                    Find clips
                  </Link>
                  <Link to="/settings#autopilot" className="btn btn-outline">
                    Set up autopilot
                  </Link>
                </div>
              }
            />
          ) : (
            <div className="space-y-8">
              {groups.map((g) => (
                <div key={g.label}>
                  <div className="mb-3 flex items-center gap-3">
                    <span className={clsx('text-sm font-bold', g.label === 'In flight' ? 'text-sky-300' : 'text-white')}>{g.label}</span>
                    <span className="h-px flex-1 bg-white/[0.06]" />
                    <span className="text-xs text-zinc-500">{g.items.length}</span>
                  </div>
                  <ol className="relative space-y-3 border-l border-dashed border-white/10 pl-5 sm:pl-6">
                    <AnimatePresence initial={false}>
                      {g.items.map((p) => (
                        <TimelineItem key={p.id} pub={p} thumb={clips[p.clipId]?.thumb} clipTitle={clips[p.clipId]?.title} jobId={clips[p.clipId]?.jobId ?? p.jobId} />
                      ))}
                    </AnimatePresence>
                  </ol>
                </div>
              ))}
            </div>
          )
        ) : history.length === 0 ? (
          <EmptyState mood="idle" title="No posts yet" body="Once clips go out, their links and stats land here." />
        ) : (
          <div className="space-y-2">
            {history.map((p) => (
              <PublicationRow key={p.id} pub={p} showClip thumb={clips[p.clipId]?.thumb} clipTitle={clips[p.clipId]?.title} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function Stat({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: number; tone: 'hex' | 'goblin' | 'rose' }) {
  return (
    <div className="panel relative overflow-hidden p-3 sm:p-4">
      <div
        className={clsx(
          'absolute -right-6 -top-6 h-20 w-20 rounded-full blur-2xl',
          tone === 'hex' && 'bg-hex-500/20',
          tone === 'goblin' && 'bg-goblin-400/15',
          tone === 'rose' && 'bg-rose-500/15',
        )}
      />
      <div
        className={clsx(
          'relative flex items-center gap-1.5 text-xs font-medium',
          tone === 'hex' && 'text-hex-300',
          tone === 'goblin' && 'text-goblin-300',
          tone === 'rose' && 'text-rose-300',
        )}
      >
        {icon}
        {label}
      </div>
      <div className="relative mt-1 font-display text-2xl font-extrabold text-white tabular sm:text-3xl">{value}</div>
    </div>
  );
}

function TimelineItem({ pub, thumb, clipTitle, jobId }: { pub: Publication; thumb?: string | null; clipTitle?: string; jobId?: string }) {
  const meta = PUB_STATUS[pub.status];
  const inFlight = pub.status !== 'scheduled';
  const [busy, setBusy] = useState(false);
  const cancel = async () => {
    setBusy(true);
    try {
      await api.cancelPublication(pub.id);
      useStore.getState().upsertPublications([{ ...pub, status: 'canceled' }]);
      toast.info('Post canceled');
    } catch (err) {
      toast.error('Could not cancel', errMsg(err));
    } finally {
      setBusy(false);
    }
  };
  return (
    <motion.li
      layout
      initial={{ opacity: 0, x: -8 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, height: 0, marginTop: 0 }}
      className={clsx('relative', busy && 'opacity-50')}
    >
      <span
        className={clsx(
          'absolute -left-[27px] top-5 h-3 w-3 rounded-full ring-4 ring-ink-900 sm:-left-[31px]',
          inFlight ? 'bg-sky-400' : 'bg-hex-400',
        )}
      >
        {inFlight && <span className="absolute inset-0 animate-ping rounded-full bg-sky-400" />}
      </span>
      <div className="panel flex items-center gap-3 p-3 transition hover:border-white/15 sm:gap-4">
        <div className="w-14 shrink-0 text-center sm:w-16">
          {inFlight ? (
            <Radio className="mx-auto h-5 w-5 animate-pulse text-sky-300" />
          ) : (
            <>
              <div className="font-display text-[15px] font-bold leading-tight text-white tabular sm:text-base">{fmtClock(pub.scheduledAt)}</div>
              <div className="text-[11px] text-zinc-500">{timeUntil(pub.scheduledAt)}</div>
            </>
          )}
        </div>
        <Link to={jobId ? `/clips/${pub.clipId}` : '#'} className="relative h-[72px] w-[41px] shrink-0 overflow-hidden rounded-md bg-ink-800 ring-1 ring-white/10">
          {thumb && <img src={thumb} alt="" className="h-full w-full object-cover" loading="lazy" />}
          <span className="absolute bottom-0.5 right-0.5 rounded bg-black/60 p-0.5">
            <PlatformIcon platform={pub.platform} className="h-3 w-3" />
          </span>
        </Link>
        <div className="min-w-0 flex-1">
          <div className="truncate text-sm font-semibold text-white">{pub.title || clipTitle || 'Untitled clip'}</div>
          <div className="mt-1 flex flex-wrap items-center gap-1.5">
            <span className="flex items-center gap-1 text-xs text-zinc-400">
              <PlatformIcon platform={pub.platform} className="h-3 w-3" /> {PLATFORM_META[pub.platform].short}
            </span>
            <span className={clsx('chip', meta.cls)}>{meta.label}</span>
          </div>
          {inFlight && <ProgressBar value={pub.progress ?? 0} indeterminate={!pub.progress} tone="sky" thin className="mt-2" />}
        </div>
        {pub.status === 'scheduled' && (
          <button onClick={cancel} disabled={busy} className="btn btn-sm btn-ghost shrink-0 px-2 text-zinc-500 hover:text-rose-300" title="Cancel this post">
            <X className="h-4 w-4" />
            <span className="hidden sm:inline">Cancel</span>
          </button>
        )}
        {pub.url && (
          <a href={pub.url} target="_blank" rel="noreferrer" className="btn btn-sm btn-outline shrink-0">
            <ExternalLink className="h-3.5 w-3.5" />
          </a>
        )}
        {pub.status === 'error' && (
          <button className="btn btn-sm btn-outline" onClick={() => api.retryPublication(pub.id)}>
            <RotateCcw className="h-3.5 w-3.5" />
          </button>
        )}
      </div>
    </motion.li>
  );
}
