// Paths, settings persistence, and secret masking shared by every server module.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DATA = process.env.CLIPGOBLIN_DATA || path.join(ROOT, 'data');

export const paths = {
  root: ROOT,
  data: DATA,
  uploads: path.join(DATA, 'uploads'),   // raw VODs (uploaded or downloaded)
  work: path.join(DATA, 'work'),         // per-job scratch: audio, transcript, analysis
  clips: path.join(DATA, 'clips'),       // rendered mp4 + thumbnails, served at /media/clips
  bin: path.join(DATA, 'bin'),           // downloaded helper binaries (yt-dlp)
  models: path.join(DATA, 'models'),     // local whisper model cache
  db: path.join(DATA, 'db.json'),
  settings: path.join(DATA, 'settings.json'),
  tokens: path.join(DATA, 'tokens.json'), // OAuth tokens, owned by server/publish
  webDist: path.join(ROOT, 'web', 'dist'),
};
for (const p of [paths.data, paths.uploads, paths.work, paths.clips, paths.bin, paths.models]) {
  fs.mkdirSync(p, { recursive: true });
}

export const PORT = Number(process.env.PORT || 4777);
export const HOST = process.env.HOST || '127.0.0.1';

export const DEFAULT_SETTINGS = {
  anthropicApiKey: '',
  claudeModel: 'claude-opus-5-5',
  publicBaseUrl: '', // e.g. an https tunnel to this server; needed for some Instagram flows
  transcription: {
    provider: 'local', // 'local' (free, on-device whisper) | 'groq' | 'openai'
    localModel: 'onnx-community/whisper-base.en',
    groqApiKey: '',
    openaiApiKey: '',
  },
  defaults: {
    maxClips: 8,
    minSec: 15,
    maxSec: 59,
    layout: 'auto', // 'auto' | 'facecam-split' | 'blur-fill' | 'center-crop'
    captionStyle: 'beast', // 'beast' | 'karaoke' | 'minimal' | 'chaos'
    facecam: null, // {x,y,w,h} normalized 0..1 of the source frame, or null
    coldOpen: true, // flash the payoff moment in the first second, then rewind
    jumpCuts: true, // remove dead air between words
    progressBar: true,
    hookBanner: true,
    chaos: false, // random punch-in zooms, shakes, extra weirdness
  },
  autopilot: {
    enabled: false, // publish top clips automatically when a job finishes
    platforms: [], // subset of ['youtube','tiktok','instagram']
    minScore: 70,
    maxPerJob: 3,
    spacingMinutes: 180, // stagger posts so they don't cannibalize each other
  },
  platforms: {
    youtube: { clientId: '', clientSecret: '', privacy: 'public' },
    tiktok: { clientKey: '', clientSecret: '', privacy: 'SELF_ONLY', mode: 'direct' }, // mode: 'direct' | 'inbox'
    instagram: { appId: '', appSecret: '' },
  },
};

// Keys whose values are secrets: never sent to the browser in clear text.
const SECRET_KEYS = new Set([
  'anthropicApiKey', 'groqApiKey', 'openaiApiKey', 'clientSecret', 'appSecret',
]);

function deepMerge(base, over) {
  if (Array.isArray(base) || Array.isArray(over)) return over === undefined ? base : over;
  if (base && typeof base === 'object' && over && typeof over === 'object') {
    const out = { ...base };
    for (const [k, v] of Object.entries(over)) out[k] = k in base ? deepMerge(base[k], v) : v;
    return out;
  }
  return over === undefined ? base : over;
}

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}

export function writeJsonAtomic(file, value) {
  const tmp = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(value, null, 2));
  fs.renameSync(tmp, file);
}

let settingsCache = null;

export function getSettings() {
  if (!settingsCache) {
    const s = deepMerge(DEFAULT_SETTINGS, readJson(paths.settings, {}));
    // Environment variables fill in keys the user has not set in the UI.
    if (!s.anthropicApiKey && process.env.ANTHROPIC_API_KEY) s.anthropicApiKey = process.env.ANTHROPIC_API_KEY;
    if (!s.transcription.groqApiKey && process.env.GROQ_API_KEY) s.transcription.groqApiKey = process.env.GROQ_API_KEY;
    if (!s.transcription.openaiApiKey && process.env.OPENAI_API_KEY) s.transcription.openaiApiKey = process.env.OPENAI_API_KEY;
    settingsCache = s;
  }
  return settingsCache;
}

// Masked secrets coming back from the UI ("••••abcd") mean "unchanged".
function stripMasked(patch) {
  if (!patch || typeof patch !== 'object' || Array.isArray(patch)) return patch;
  const out = {};
  for (const [k, v] of Object.entries(patch)) {
    if (SECRET_KEYS.has(k) && typeof v === 'string' && v.startsWith('••••')) continue;
    out[k] = stripMasked(v);
  }
  return out;
}

export function updateSettings(patch) {
  settingsCache = deepMerge(getSettings(), stripMasked(patch));
  writeJsonAtomic(paths.settings, settingsCache);
  return settingsCache;
}

// Settings safe to send to the browser: secrets become "••••last4" (or "").
export function publicSettings(s = getSettings()) {
  const mask = (obj) => {
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return obj;
    const out = {};
    for (const [k, v] of Object.entries(obj)) {
      out[k] = SECRET_KEYS.has(k) ? (v ? `••••${String(v).slice(-4)}` : '') : mask(v);
    }
    return out;
  };
  return mask(s);
}
