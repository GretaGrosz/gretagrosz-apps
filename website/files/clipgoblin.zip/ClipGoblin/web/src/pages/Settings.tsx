import clsx from 'clsx';
import { AnimatePresence, motion } from 'framer-motion';
import {
  AlertTriangle,
  Bot,
  Check,
  ChevronDown,
  Crop,
  ExternalLink,
  Eye,
  EyeOff,
  Globe,
  KeyRound,
  Link2,
  LogOut,
  Mic,
  Palette,
  Plug,
  Rocket,
  Save,
  ShieldCheck,
} from 'lucide-react';
import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { PlatformIcon } from '../components/Brand';
import { FacecamPicker } from '../components/FacecamPicker';
import { PlatformPicker } from '../components/Pipeline';
import { ClipSettingsForm } from '../components/StyleControls';
import { CopyButton, Field, NumberStepper, SectionTitle, Skeleton, Spinner, Switch } from '../components/ui';
import { api, errMsg } from '../lib/api';
import { fmtSpacing, listJoin } from '../lib/format';
import { PLATFORM_META } from '../lib/meta';
import { toast, useStore } from '../lib/store';
import type { AccountState, Platform, Settings as SettingsT } from '../lib/types';
import { PLATFORMS } from '../lib/types';

const SECTIONS = [
  { id: 'ai', label: 'AI', icon: Bot },
  { id: 'connections', label: 'Connections', icon: Plug },
  { id: 'style', label: 'Clip style', icon: Palette },
  { id: 'facecam', label: 'Facecam', icon: Crop },
  { id: 'autopilot', label: 'Autopilot', icon: Rocket },
  { id: 'advanced', label: 'Advanced', icon: Globe },
] as const;

const isMasked = (v?: string) => !!v && v.startsWith('••••');
const clone = <T,>(v: T): T => JSON.parse(JSON.stringify(v));

export default function Settings() {
  const settings = useStore((s) => s.settings);
  const accounts = useStore((s) => s.accounts);
  const location = useLocation();
  const navigate = useNavigate();
  const [draft, setDraft] = useState<SettingsT | null>(null);
  const [saving, setSaving] = useState(false);
  const [activeSection, setActiveSection] = useState<string>('ai');
  const handledQuery = useRef(false);

  useEffect(() => {
    void useStore.getState().loadSettings();
    void useStore.getState().loadAccounts();
    if (!useStore.getState().loaded.jobs) void useStore.getState().loadJobs();
  }, []);

  useEffect(() => {
    if (settings && !draft) setDraft(clone(settings));
  }, [settings, draft]);

  // OAuth round-trip results: /settings?connected=youtube or ?error=...
  useEffect(() => {
    if (handledQuery.current) return;
    const q = new URLSearchParams(location.search);
    const connected = q.get('connected');
    const error = q.get('error');
    if (!connected && !error) return;
    handledQuery.current = true;
    if (connected) {
      const name = PLATFORM_META[connected as Platform]?.short ?? connected;
      toast.success(`${name} connected`, 'The goblin can post there now.');
      void useStore.getState().loadAccounts();
    }
    if (error) toast.error('Connection failed', error);
    navigate({ pathname: '/settings', hash: '#connections' }, { replace: true });
  }, [location.search, navigate]);

  // Scroll to #hash once content exists.
  useEffect(() => {
    if (!draft) return;
    const id = location.hash.replace('#', '');
    if (!id) return;
    const el = document.getElementById(id);
    if (el) setTimeout(() => el.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [!!draft, location.hash]);

  // Scroll-spy for the section nav.
  useEffect(() => {
    if (!draft) return;
    const obs = new IntersectionObserver(
      (entries) => {
        const vis = entries.filter((e) => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (vis[0]) setActiveSection(vis[0].target.id);
      },
      { rootMargin: '-140px 0px -55% 0px' },
    );
    SECTIONS.forEach((s) => {
      const el = document.getElementById(s.id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, [!!draft]);

  // Keep the active chip visible in the horizontal (mobile) section nav.
  const navRef = useRef<HTMLElement>(null);
  useEffect(() => {
    const nav = navRef.current;
    const el = nav?.querySelector<HTMLElement>(`a[href="#${activeSection}"]`);
    if (nav && el && nav.scrollWidth > nav.clientWidth) nav.scrollTo({ left: el.offsetLeft - 16, behavior: 'smooth' });
  }, [activeSection]);

  const dirty = useMemo(() => !!draft && !!settings && JSON.stringify(draft) !== JSON.stringify(settings), [draft, settings]);

  const save = async (quiet = false) => {
    if (!draft) return;
    setSaving(true);
    try {
      const next = await api.saveSettings(draft);
      useStore.getState().setSettings(next);
      setDraft(clone(next));
      void useStore.getState().loadSystem();
      void useStore.getState().loadAccounts();
      if (!quiet) toast.success('Settings saved');
    } catch (err) {
      toast.error('Save failed', errMsg(err));
      throw err;
    } finally {
      setSaving(false);
    }
  };

  if (!draft)
    return (
      <div className="mx-auto max-w-5xl space-y-4 px-4 py-8 sm:px-6">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-64" />
        <Skeleton className="h-64" />
      </div>
    );

  const set = (fn: (d: SettingsT) => void) =>
    setDraft((d) => {
      if (!d) return d;
      const n = clone(d);
      fn(n);
      return n;
    });

  return (
    <div className="mx-auto max-w-6xl px-4 pb-36 pt-8 sm:px-6">
      <h1 className="font-display text-3xl font-extrabold tracking-tight text-white">Settings</h1>
      <p className="mt-1 text-sm text-zinc-400">Keys, connections and the goblin's taste.</p>

      <div className="mt-6 lg:grid lg:grid-cols-[200px_1fr] lg:gap-10">
        {/* Section nav */}
        <nav ref={navRef} className="no-scrollbar sticky top-16 z-20 -mx-4 mb-6 flex gap-1 overflow-x-auto border-b border-white/[0.06] bg-ink-900/85 px-4 py-2 backdrop-blur-xl lg:top-24 lg:mx-0 lg:mb-0 lg:h-fit lg:flex-col lg:border-0 lg:bg-transparent lg:p-0 lg:backdrop-blur-0">
          {SECTIONS.map((s) => (
            <a
              key={s.id}
              href={`#${s.id}`}
              onClick={(e) => {
                e.preventDefault();
                document.getElementById(s.id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                history.replaceState(null, '', `#${s.id}`);
              }}
              className={clsx(
                'relative flex shrink-0 items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                activeSection === s.id ? 'text-white' : 'text-zinc-500 hover:text-zinc-200',
              )}
            >
              {activeSection === s.id && (
                <motion.span layoutId="settings-nav" className="absolute inset-0 rounded-lg bg-white/[0.06] ring-1 ring-white/[0.08]" />
              )}
              <s.icon className={clsx('relative h-4 w-4', activeSection === s.id && 'text-goblin-400')} />
              <span className="relative">{s.label}</span>
            </a>
          ))}
        </nav>

        <div className="min-w-0 space-y-6">
          {/* AI */}
          <Section id="ai">
            <SectionTitle icon={<Bot className="h-4 w-4" />} title="AI brains" subtitle="Claude picks the moments and writes the hooks. Transcription turns speech into captions." />
            <div className="space-y-5">
              <div className="grid gap-4 sm:grid-cols-[1fr_220px]">
                <SecretField
                  label="Anthropic API key"
                  value={draft.anthropicApiKey}
                  onChange={(v) => set((d) => void (d.anthropicApiKey = v))}
                  placeholder="sk-ant-…"
                  hint={
                    <>
                      Without a key, ClipGoblin uses a basic heuristic.{' '}
                      <a href="https://console.anthropic.com/settings/keys" target="_blank" rel="noreferrer" className="text-goblin-400 hover:underline">
                        Get a key ↗
                      </a>
                    </>
                  }
                />
                <Field label="Claude model" hint="Any Claude model ID.">
                  <input className="input font-mono text-[13px]" value={draft.claudeModel} onChange={(e) => set((d) => void (d.claudeModel = e.target.value))} spellCheck={false} />
                </Field>
              </div>

              <div>
                <span className="label flex items-center gap-1.5">
                  <Mic className="h-3 w-3" /> Transcription
                </span>
                <div className="grid gap-2 sm:grid-cols-3">
                  {(
                    [
                      { id: 'local', name: 'Local', tag: 'Free', desc: 'Runs on this machine. Private, slower.' },
                      { id: 'groq', name: 'Groq', tag: 'Fastest', desc: 'Cloud Whisper, very cheap.' },
                      { id: 'openai', name: 'OpenAI', tag: 'Cloud', desc: 'OpenAI Whisper API.' },
                    ] as const
                  ).map((o) => {
                    const on = draft.transcription.provider === o.id;
                    return (
                      <button
                        key={o.id}
                        type="button"
                        onClick={() => set((d) => void (d.transcription.provider = o.id))}
                        className={clsx(
                          'relative rounded-xl border p-3 text-left transition-all',
                          on ? 'border-goblin-400/60 bg-goblin-400/[0.05]' : 'border-white/[0.07] bg-ink-950/40 hover:border-white/15',
                        )}
                      >
                        <div className="flex items-center justify-between">
                          <span className={clsx('text-sm font-semibold', on ? 'text-white' : 'text-zinc-300')}>{o.name}</span>
                          <span className={clsx('chip', on ? 'border-goblin-400/30 bg-goblin-400/10 text-goblin-300' : 'border-white/10 text-zinc-500')}>{o.tag}</span>
                        </div>
                        <div className="mt-1 text-xs text-zinc-500">{o.desc}</div>
                      </button>
                    );
                  })}
                </div>
                <AnimatePresence mode="wait" initial={false}>
                  <motion.div
                    key={draft.transcription.provider}
                    initial={{ opacity: 0, y: -4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    className="mt-3"
                  >
                    {draft.transcription.provider === 'groq' && (
                      <SecretField
                        label="Groq API key"
                        value={draft.transcription.groqApiKey}
                        onChange={(v) => set((d) => void (d.transcription.groqApiKey = v))}
                        placeholder="gsk_…"
                        hint={
                          <a href="https://console.groq.com/keys" target="_blank" rel="noreferrer" className="text-goblin-400 hover:underline">
                            Get a Groq key ↗
                          </a>
                        }
                      />
                    )}
                    {draft.transcription.provider === 'openai' && (
                      <SecretField
                        label="OpenAI API key"
                        value={draft.transcription.openaiApiKey}
                        onChange={(v) => set((d) => void (d.transcription.openaiApiKey = v))}
                        placeholder="sk-…"
                      />
                    )}
                    {draft.transcription.provider === 'local' && (
                      <Field label="Local model" hint="Bigger = more accurate, slower. Downloads once on first use.">
                        <select className="input" value={draft.transcription.localModel} onChange={(e) => set((d) => void (d.transcription.localModel = e.target.value))}>
                          {Array.from(
                            new Set([
                              'onnx-community/whisper-tiny.en',
                              'onnx-community/whisper-base.en',
                              'onnx-community/whisper-small.en',
                              draft.transcription.localModel,
                            ]),
                          ).map((m) => (
                            <option key={m} value={m}>
                              {m.replace('onnx-community/', '')}
                            </option>
                          ))}
                        </select>
                      </Field>
                    )}
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>
          </Section>

          {/* Connections */}
          <Section id="connections">
            <SectionTitle icon={<Plug className="h-4 w-4" />} title="Connections" subtitle="Link the accounts ClipGoblin posts to. Your tokens never leave this machine." />
            {!accounts ? (
              <div className="space-y-3">
                <Skeleton className="h-28" />
                <Skeleton className="h-28" />
              </div>
            ) : (
              <div className="space-y-3">
                {PLATFORMS.map((p) => (
                  <ConnectionCard
                    key={p}
                    platform={p}
                    account={accounts[p]}
                    draft={draft}
                    set={set}
                    dirty={dirty}
                    save={save}
                  />
                ))}
              </div>
            )}
          </Section>

          {/* Style */}
          <Section id="style">
            <SectionTitle icon={<Palette className="h-4 w-4" />} title="Default clip style" subtitle="Used for every new VOD. You can still tweak per job and per clip." />
            <ClipSettingsForm value={draft.defaults} onChange={(p) => set((d) => void Object.assign(d.defaults, p))} />
          </Section>

          {/* Facecam */}
          <Section id="facecam">
            <SectionTitle
              icon={<Crop className="h-4 w-4" />}
              title="Facecam region"
              subtitle="Mark where your webcam sits so facecam-split layouts frame you perfectly."
            />
            <FacecamPicker value={draft.defaults.facecam} onChange={(r) => set((d) => void (d.defaults.facecam = r))} />
          </Section>

          {/* Autopilot */}
          <Section id="autopilot" glow={draft.autopilot.enabled}>
            <SectionTitle
              icon={<Rocket className="h-4 w-4" />}
              title="Autopilot"
              subtitle="Post the best clips automatically when a VOD finishes."
              right={<Switch checked={draft.autopilot.enabled} onChange={(v) => set((d) => void (d.autopilot.enabled = v))} label="Enable autopilot" />}
            />
            <AutopilotSummary s={draft.autopilot} />
            <div className={clsx('mt-5 space-y-5 transition-opacity', !draft.autopilot.enabled && 'opacity-50')}>
              <div>
                <span className="label">Post to</span>
                <PlatformPicker
                  value={draft.autopilot.platforms}
                  requireConnected={false}
                  onChange={(v) => set((d) => void (d.autopilot.platforms = v))}
                />
                {draft.autopilot.platforms.some((p) => accounts && !accounts[p]?.connected) && (
                  <p className="mt-2 flex items-center gap-1.5 text-xs text-amber-300/90">
                    <AlertTriangle className="h-3.5 w-3.5" />
                    {listJoin(draft.autopilot.platforms.filter((p) => !accounts?.[p]?.connected).map((p) => PLATFORM_META[p].short))} isn't connected yet — those posts will fail.
                  </p>
                )}
              </div>
              <div>
                <div className="flex items-baseline justify-between">
                  <span className="label">Minimum score</span>
                  <span className="font-display text-lg font-bold text-goblin-300 tabular">{draft.autopilot.minScore}+</span>
                </div>
                <input
                  type="range"
                  className="range w-full"
                  min={0}
                  max={100}
                  step={5}
                  value={draft.autopilot.minScore}
                  style={{ ['--fill' as string]: `${draft.autopilot.minScore}%` }}
                  onChange={(e) => set((d) => void (d.autopilot.minScore = Number(e.target.value)))}
                />
                <div className="mt-1 flex justify-between text-[11px] text-zinc-600">
                  <span>post anything</span>
                  <span>only bangers</span>
                </div>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Max clips per VOD">
                  <NumberStepper value={draft.autopilot.maxPerJob} min={1} max={20} onChange={(v) => set((d) => void (d.autopilot.maxPerJob = v))} />
                </Field>
                <Field label="Spacing between posts">
                  <NumberStepper
                    value={draft.autopilot.spacingMinutes}
                    min={0}
                    max={2880}
                    step={15}
                    suffix="min"
                    onChange={(v) => set((d) => void (d.autopilot.spacingMinutes = v))}
                  />
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {[30, 60, 180, 360, 720, 1440].map((m) => (
                      <button
                        key={m}
                        type="button"
                        onClick={() => set((d) => void (d.autopilot.spacingMinutes = m))}
                        className={clsx(
                          'chip transition',
                          draft.autopilot.spacingMinutes === m ? 'border-goblin-400/40 bg-goblin-400/10 text-goblin-300' : 'border-white/10 text-zinc-400 hover:text-white',
                        )}
                      >
                        {m < 60 ? `${m}m` : `${m / 60}h`}
                      </button>
                    ))}
                  </div>
                </Field>
              </div>
            </div>
          </Section>

          {/* Advanced */}
          <Section id="advanced">
            <SectionTitle icon={<Globe className="h-4 w-4" />} title="Public URL" subtitle="Optional. Only needed for some platform flows." />
            <Field
              label="Public base URL"
              hint={
                <>
                  Instagram fetches your video from a public URL, so it can't reach <span className="kbd">localhost</span>. Point a tunnel (Cloudflare Tunnel,
                  ngrok, Tailscale Funnel…) at port 4777 and paste its https address here. Leave empty if you don't post to Instagram.
                </>
              }
            >
              <input
                className="input font-mono text-[13px]"
                placeholder="https://goblin.example.com"
                value={draft.publicBaseUrl}
                onChange={(e) => set((d) => void (d.publicBaseUrl = e.target.value.trim()))}
                inputMode="url"
                spellCheck={false}
              />
            </Field>
          </Section>
        </div>
      </div>

      {/* Save bar */}
      <AnimatePresence>
        {dirty && (
          <motion.div
            initial={{ y: 80, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 80, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 420, damping: 34 }}
            className="fixed inset-x-0 bottom-[76px] z-30 flex justify-center px-4 md:bottom-6"
          >
            <div className="flex w-full max-w-md items-center gap-2 rounded-2xl border border-white/10 bg-ink-800/95 p-2 pl-4 shadow-2xl backdrop-blur-xl">
              <span className="relative flex h-2 w-2">
                <span className="absolute inset-0 animate-ping rounded-full bg-goblin-400" />
                <span className="relative h-2 w-2 rounded-full bg-goblin-400" />
              </span>
              <span className="flex-1 text-sm font-medium text-zinc-200">Unsaved changes</span>
              <button className="btn btn-sm btn-ghost" onClick={() => setDraft(clone(settings!))}>
                Discard
              </button>
              <button className="btn btn-primary" onClick={() => save().catch(() => {})} disabled={saving}>
                {saving ? <Spinner /> : <Save className="h-4 w-4" />} Save
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Section({ id, children, glow }: { id: string; children: ReactNode; glow?: boolean }) {
  return (
    <section
      id={id}
      className={clsx('panel scroll-mt-32 p-5 transition-shadow duration-500 sm:p-6 lg:scroll-mt-24', glow && 'border-goblin-400/25 shadow-glow')}
    >
      {children}
    </section>
  );
}

function SecretField({
  label,
  value,
  onChange,
  placeholder,
  hint,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  hint?: ReactNode;
}) {
  const masked = isMasked(value);
  const [show, setShow] = useState(false);
  const typed = masked ? '' : value;
  return (
    <Field label={label} hint={hint}>
      <div className="relative">
        <KeyRound className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
        <input
          type={show ? 'text' : 'password'}
          className={clsx('input pl-9 pr-24 font-mono text-[13px]', masked && 'placeholder:text-zinc-400')}
          value={typed}
          placeholder={masked ? value : placeholder}
          onChange={(e) => onChange(e.target.value)}
          autoComplete="off"
          spellCheck={false}
        />
        <div className="absolute right-1.5 top-1/2 flex -translate-y-1/2 items-center gap-1">
          {masked ? (
            <span className="chip border-goblin-400/30 bg-goblin-400/10 text-goblin-300">
              <Check className="h-3 w-3" /> Saved
            </span>
          ) : typed ? (
            <button type="button" onClick={() => setShow((s) => !s)} className="rounded-md p-1.5 text-zinc-500 hover:text-white" aria-label={show ? 'Hide' : 'Show'}>
              {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          ) : null}
          {masked && (
            <button type="button" onClick={() => onChange('')} className="rounded-md px-1.5 py-1 text-[11px] font-medium text-zinc-500 hover:text-rose-300" title="Remove saved key">
              Clear
            </button>
          )}
        </div>
      </div>
    </Field>
  );
}

const CRED_FIELDS: Record<Platform, { key: string; label: string; secret?: boolean }[]> = {
  youtube: [
    { key: 'clientId', label: 'OAuth client ID' },
    { key: 'clientSecret', label: 'Client secret', secret: true },
  ],
  tiktok: [
    { key: 'clientKey', label: 'Client key' },
    { key: 'clientSecret', label: 'Client secret', secret: true },
  ],
  instagram: [
    { key: 'appId', label: 'App ID' },
    { key: 'appSecret', label: 'App secret', secret: true },
  ],
};

const URL_RE = /(https?:\/\/[^\s)'"<>]+)/g;

function linkify(text: string): ReactNode[] {
  return text.split(URL_RE).map((part, i) =>
    i % 2 === 1 ? (
      <a key={i} href={part} target="_blank" rel="noreferrer" className="break-all text-goblin-400 hover:underline">
        {part}
      </a>
    ) : (
      <span key={i}>{part}</span>
    ),
  );
}

function ConnectionCard({
  platform,
  account,
  draft,
  set,
  dirty,
  save,
}: {
  platform: Platform;
  account?: AccountState;
  draft: SettingsT;
  set: (fn: (d: SettingsT) => void) => void;
  dirty: boolean;
  save: (quiet?: boolean) => Promise<void>;
}) {
  const meta = PLATFORM_META[platform];
  const creds = draft.platforms[platform] as unknown as Record<string, string>;
  const credsFilled = CRED_FIELDS[platform].every((f) => !!creds[f.key]);
  const configured = !!account?.configured || credsFilled;
  const connected = !!account?.connected;
  const [open, setOpen] = useState(!connected);
  const [busy, setBusy] = useState(false);
  const [checked, setChecked] = useState<number[]>(() => {
    try {
      return JSON.parse(localStorage.getItem(`cg-setup-${platform}`) || '[]');
    } catch {
      return [];
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem(`cg-setup-${platform}`, JSON.stringify(checked));
    } catch {
      /* ignore */
    }
  }, [checked, platform]);

  const steps = (account?.setup ?? []).map((s) => (typeof s === 'string' ? s : [s.title, s.text, s.url].filter(Boolean).join(' — ')));
  const redirectUri =
    account?.redirectUri ?? steps.map((s) => s.match(URL_RE)?.find((u) => u.includes('/api/auth/'))).find(Boolean) ?? null;

  const connect = async () => {
    setBusy(true);
    try {
      if (dirty) await save(true);
      window.location.href = api.connectUrl(platform);
    } catch {
      setBusy(false);
    }
  };
  const disconnect = async () => {
    if (!confirm(`Disconnect ${meta.short}? Scheduled posts there will fail until you reconnect.`)) return;
    setBusy(true);
    try {
      await api.disconnect(platform);
      await useStore.getState().loadAccounts();
      toast.info(`${meta.short} disconnected`);
    } catch (err) {
      toast.error('Could not disconnect', errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className={clsx('overflow-hidden rounded-2xl border transition-colors', connected ? 'border-goblin-400/20 bg-goblin-400/[0.025]' : 'border-white/[0.07] bg-ink-950/30')}>
      <div className="flex flex-wrap items-center gap-3 p-4">
        <div className="relative grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-white/[0.04] ring-1 ring-white/[0.08]">
          <PlatformIcon platform={platform} className="h-6 w-6" />
          {connected && <span className="absolute -bottom-1 -right-1 grid h-4 w-4 place-items-center rounded-full bg-goblin-400 ring-2 ring-ink-850"><Check className="h-2.5 w-2.5 text-ink-950" strokeWidth={4} /></span>}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-semibold text-white">{meta.name}</span>
            {connected ? (
              <span className="chip border-goblin-400/30 bg-goblin-400/10 text-goblin-300">Connected</span>
            ) : configured ? (
              <span className="chip border-sky-400/30 bg-sky-400/10 text-sky-300">Ready to connect</span>
            ) : (
              <span className="chip border-white/10 bg-white/[0.03] text-zinc-500">Not set up</span>
            )}
          </div>
          {connected ? (
            <div className="mt-1 flex items-center gap-2 text-sm text-zinc-400">
              {account?.avatar ? (
                <img src={account.avatar} alt="" className="h-5 w-5 rounded-full ring-1 ring-white/10" />
              ) : (
                <span className="grid h-5 w-5 place-items-center rounded-full bg-white/10 text-[10px] font-bold text-white">{(account?.name || '?')[0]}</span>
              )}
              <span className="truncate">{account?.name || 'Connected account'}</span>
            </div>
          ) : (
            <div className="mt-0.5 text-xs text-zinc-500">{configured ? 'Credentials saved — sign in to finish.' : 'Add your app credentials to get started.'}</div>
          )}
        </div>
        <div className="flex w-full items-center gap-2 sm:w-auto">
          {connected ? (
            <button className="btn btn-sm btn-ghost flex-1 text-zinc-400 hover:text-rose-300 sm:flex-none" onClick={disconnect} disabled={busy}>
              <LogOut className="h-3.5 w-3.5" /> Disconnect
            </button>
          ) : (
            <button className="btn btn-sm btn-primary flex-1 sm:flex-none" onClick={connect} disabled={busy || !configured} title={configured ? undefined : 'Add credentials first'}>
              {busy ? <Spinner className="h-3.5 w-3.5" /> : <Link2 className="h-3.5 w-3.5" />} Connect
            </button>
          )}
          <button
            className="btn btn-sm btn-outline px-2"
            onClick={() => setOpen((o) => !o)}
            aria-expanded={open}
            aria-label={open ? 'Collapse' : 'Expand'}
          >
            <ChevronDown className={clsx('h-4 w-4 transition-transform duration-300', open && 'rotate-180')} />
          </button>
        </div>
      </div>

      {account?.note && (
        <div className="mx-4 mb-4 flex items-start gap-2 rounded-xl border border-amber-300/20 bg-amber-300/[0.06] px-3 py-2 text-xs leading-relaxed text-amber-200/90">
          <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          <span>{linkify(account.note)}</span>
        </div>
      )}

      <AnimatePresence initial={false}>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
            <div className="space-y-5 border-t border-white/[0.06] p-4">
              {steps.length > 0 && (
                <div>
                  <div className="mb-2 flex items-center gap-1.5 text-xs font-medium uppercase tracking-wider text-zinc-400">
                    <ShieldCheck className="h-3.5 w-3.5" /> Setup guide
                    <span className="ml-auto font-normal normal-case tracking-normal text-zinc-600">
                      {checked.filter((i) => i < steps.length).length}/{steps.length} done
                    </span>
                  </div>
                  {redirectUri && (
                    <div className="mb-3 flex items-center gap-2 rounded-xl border border-hex-400/20 bg-hex-500/[0.06] p-2 pl-3">
                      <div className="min-w-0 flex-1">
                        <div className="text-[10px] font-semibold uppercase tracking-wider text-hex-300">Redirect URI</div>
                        <div className="truncate font-mono text-xs text-zinc-200" title={redirectUri}>
                          {redirectUri}
                        </div>
                      </div>
                      <CopyButton text={redirectUri} />
                    </div>
                  )}
                  <ol className="space-y-1.5">
                    {steps.map((s, i) => {
                      const done = checked.includes(i);
                      return (
                        <li key={i} className="flex items-start gap-3 rounded-lg px-1 py-1">
                          <button
                            type="button"
                            onClick={() => setChecked((c) => (done ? c.filter((x) => x !== i) : [...c, i]))}
                            className={clsx(
                              'mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full border text-[10px] font-bold transition',
                              done ? 'border-goblin-400 bg-goblin-400 text-ink-950' : 'border-white/20 text-zinc-400 hover:border-white/40',
                            )}
                            aria-label={done ? 'Mark step not done' : 'Mark step done'}
                          >
                            {done ? <Check className="h-3 w-3" strokeWidth={3.5} /> : i + 1}
                          </button>
                          <span className={clsx('min-w-0 break-words text-[13px] leading-relaxed', done ? 'text-zinc-500 line-through decoration-zinc-600' : 'text-zinc-300')}>
                            {linkify(s)}
                          </span>
                        </li>
                      );
                    })}
                  </ol>
                </div>
              )}

              <div className="grid gap-3 sm:grid-cols-2">
                {CRED_FIELDS[platform].map((f) =>
                  f.secret ? (
                    <SecretField
                      key={f.key}
                      label={f.label}
                      value={creds[f.key] ?? ''}
                      onChange={(v) => set((d) => void ((d.platforms[platform] as unknown as Record<string, string>)[f.key] = v))}
                    />
                  ) : (
                    <Field key={f.key} label={f.label}>
                      <input
                        className="input font-mono text-[13px]"
                        value={creds[f.key] ?? ''}
                        onChange={(e) => set((d) => void ((d.platforms[platform] as unknown as Record<string, string>)[f.key] = e.target.value.trim()))}
                        spellCheck={false}
                        autoComplete="off"
                      />
                    </Field>
                  ),
                )}
              </div>

              {platform === 'youtube' && (
                <Field label="Default privacy">
                  <select className="input" value={draft.platforms.youtube.privacy} onChange={(e) => set((d) => void (d.platforms.youtube.privacy = e.target.value))}>
                    <option value="public">Public</option>
                    <option value="unlisted">Unlisted</option>
                    <option value="private">Private</option>
                  </select>
                </Field>
              )}
              {platform === 'tiktok' && (
                <div className="grid gap-3 sm:grid-cols-2">
                  <Field
                    label="Posting mode"
                    hint={
                      (draft.platforms.tiktok.mode ?? 'direct') === 'inbox'
                        ? 'Sends drafts to your TikTok inbox — you finish posting in the app.'
                        : 'Posts straight to your profile.'
                    }
                  >
                    <select
                      className="input"
                      value={draft.platforms.tiktok.mode ?? 'direct'}
                      onChange={(e) => set((d) => void (d.platforms.tiktok.mode = e.target.value as 'direct' | 'inbox'))}
                    >
                      <option value="direct">Direct post</option>
                      <option value="inbox">Send to inbox (drafts)</option>
                    </select>
                  </Field>
                  <Field
                    label="Privacy"
                    hint={
                      account?.privacyOptions?.length
                        ? 'Only the levels your TikTok account allows are enabled.'
                        : 'Unaudited TikTok apps can only post privately.'
                    }
                  >
                    <select className="input" value={draft.platforms.tiktok.privacy} onChange={(e) => set((d) => void (d.platforms.tiktok.privacy = e.target.value))}>
                      {[
                        ['PUBLIC_TO_EVERYONE', 'Everyone'],
                        ['MUTUAL_FOLLOW_FRIENDS', 'Friends'],
                        ['FOLLOWER_OF_CREATOR', 'Followers'],
                        ['SELF_ONLY', 'Only me'],
                      ].map(([v, l]) => {
                        const allowed = !account?.privacyOptions?.length || account.privacyOptions.includes(v);
                        return (
                          <option key={v} value={v} disabled={!allowed && draft.platforms.tiktok.privacy !== v}>
                            {l}
                            {allowed ? '' : ' (not allowed)'}
                          </option>
                        );
                      })}
                    </select>
                  </Field>
                </div>
              )}
              {platform === 'instagram' && !draft.publicBaseUrl && (
                <p className="flex items-start gap-1.5 text-xs text-zinc-500">
                  <ExternalLink className="mt-0.5 h-3 w-3 shrink-0" /> Instagram needs a public URL to fetch videos from — set one under Advanced.
                </p>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function AutopilotSummary({ s }: { s: SettingsT['autopilot'] }) {
  const names = s.platforms.map((p) => PLATFORM_META[p].short);
  const text = !s.enabled ? (
    <>Autopilot is off. Clips wait for you to publish them by hand.</>
  ) : names.length === 0 ? (
    <>Autopilot is on, but no platforms are picked yet — choose where to post below.</>
  ) : (
    <>
      When a VOD finishes, ClipGoblin posts its best <B>{s.maxPerJob}</B> clip{s.maxPerJob === 1 ? '' : 's'} scoring <B>{s.minScore}+</B> to <B>{listJoin(names)}</B>
      {s.maxPerJob > 1 && (
        <>
          , {s.spacingMinutes > 0 ? (
            <>
              one every <B>{fmtSpacing(s.spacingMinutes)}</B>
            </>
          ) : (
            <>all at once</>
          )}
        </>
      )}
      .
    </>
  );
  return (
    <div
      className={clsx(
        'flex items-start gap-3 rounded-xl border p-3.5 text-[14px] leading-relaxed',
        s.enabled ? 'border-goblin-400/20 bg-goblin-400/[0.05] text-zinc-200' : 'border-white/[0.06] bg-ink-950/40 text-zinc-400',
      )}
    >
      <Rocket className={clsx('mt-0.5 h-4 w-4 shrink-0', s.enabled ? 'text-goblin-400' : 'text-zinc-600')} />
      <p>{text}</p>
    </div>
  );
}

const B = ({ children }: { children: ReactNode }) => <b className="font-semibold text-white">{children}</b>;
