// Pipeline REST API: jobs (upload / URL), clips (edit / re-render / delete), source frames, system status.
import fs from 'node:fs';
import path from 'node:path';
import multer from 'multer';
import { paths, getSettings } from '../config.js';
import { store } from '../store.js';
import {
  enqueueJob, cancelJob, isJobActive, deleteJobData, deleteClipData, requestClipRender,
  resumeJobs as resume, loadTranscript, queueSnapshot, ACTIVE_STATUSES,
} from '../pipeline/runner.js';
import { grabFrame, FFMPEG } from '../pipeline/ffmpeg.js';
import { ytdlpInstalled } from '../pipeline/ingest.js';
import { localModelReady } from '../pipeline/transcribe.js';
import { textIn } from '../pipeline/analyze.js';
import { fileExists, rmrf } from '../pipeline/util.js';

const LAYOUTS = ['auto', 'facecam-split', 'blur-fill', 'center-crop'];
const CAPTION_STYLES = ['beast', 'karaoke', 'minimal', 'chaos', 'none'];
const STYLE_BOOLS = ['coldOpen', 'jumpCuts', 'progressBar', 'hookBanner', 'chaos'];

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

function parseMaybeJson(v) {
  if (v == null || v === '') return {};
  if (typeof v === 'object') return v;
  try { return JSON.parse(v); } catch { throw new HttpError(400, '"options" must be valid JSON'); }
}

const num = (v, lo, hi, dflt) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : dflt;
};

function sanitizeFacecam(fc) {
  if (!fc || typeof fc !== 'object') return null;
  const x = num(fc.x, 0, 1, NaN); const y = num(fc.y, 0, 1, NaN);
  let w = num(fc.w, 0.01, 1, NaN); let h = num(fc.h, 0.01, 1, NaN);
  if ([x, y, w, h].some(Number.isNaN)) return null;
  w = Math.min(w, 1 - x); h = Math.min(h, 1 - y);
  if (w < 0.02 || h < 0.02) return null;
  return { x, y, w, h };
}

/** Merge user options over settings.defaults with validation. */
function sanitizeOptions(input, base = getSettings().defaults) {
  const o = { ...base };
  const i = input || {};
  if (i.maxClips != null) o.maxClips = Math.round(num(i.maxClips, 1, 30, base.maxClips));
  if (i.minSec != null) o.minSec = num(i.minSec, 5, 120, base.minSec);
  if (i.maxSec != null) o.maxSec = num(i.maxSec, 10, 180, base.maxSec);
  if (o.maxSec < o.minSec + 5) o.maxSec = o.minSec + 5;
  if (i.layout != null) o.layout = LAYOUTS.includes(i.layout) ? i.layout : base.layout;
  if (i.captionStyle != null) o.captionStyle = CAPTION_STYLES.includes(i.captionStyle) ? i.captionStyle : base.captionStyle;
  if ('facecam' in i) o.facecam = sanitizeFacecam(i.facecam);
  for (const k of STYLE_BOOLS) if (i[k] != null) o[k] = !!i[k];
  return o;
}

function sanitizeStyle(input, current = {}) {
  const s = { ...current };
  if (!input || typeof input !== 'object') return s;
  if (input.layout != null) { if (!LAYOUTS.includes(input.layout)) throw new HttpError(400, `layout must be one of ${LAYOUTS.join(', ')}`); s.layout = input.layout; }
  if (input.captionStyle != null) { if (!CAPTION_STYLES.includes(input.captionStyle)) throw new HttpError(400, `captionStyle must be one of ${CAPTION_STYLES.join(', ')}`); s.captionStyle = input.captionStyle; }
  for (const k of STYLE_BOOLS) if (input[k] != null) s[k] = !!input[k];
  if ('facecam' in input) s.facecam = input.facecam === null ? null : sanitizeFacecam(input.facecam);
  return s;
}

const getJobOr404 = (id) => {
  const j = store.get('jobs', id);
  if (!j) throw new HttpError(404, 'Job not found');
  return j;
};
const getClipOr404 = (id) => {
  const c = store.get('clips', id);
  if (!c) throw new HttpError(404, 'Clip not found');
  return c;
};

const clipsOf = (job) => store.list('clips', (c) => c.jobId === job.id).sort((a, b) => (a.rank ?? 999) - (b.rank ?? 999));

// ------------------------------------------------------------------ uploads

const VIDEO_EXT = /\.(mp4|mov|mkv|webm|flv|ts|m4v|avi|mpg|mpeg|wmv|3gp)$/i;
const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, paths.uploads),
    filename: (req, file, cb) => {
      req.jobId ??= store.newId('job');
      const ext = (path.extname(file.originalname || '').toLowerCase().match(/^\.[a-z0-9]{1,5}$/) || ['.mp4'])[0];
      cb(null, `${req.jobId}${ext}`);
    },
  }),
  limits: { fileSize: 100 * 1024 ** 3, files: 1, fields: 20 },
  fileFilter: (_req, file, cb) => {
    if (/^video\//.test(file.mimetype) || VIDEO_EXT.test(file.originalname || '') || file.mimetype === 'application/octet-stream') cb(null, true);
    else cb(new HttpError(400, `"${file.originalname}" doesn't look like a video file`));
  },
});

function uploadMiddleware(req, res, next) {
  upload.single('file')(req, res, (err) => {
    if (!err) return next();
    if (err instanceof multer.MulterError) return next(new HttpError(400, `Upload failed: ${err.message}`));
    return next(err);
  });
}

// ------------------------------------------------------------------ routes

export function registerJobRoutes(app) {
  // Create a job from an uploaded file or a URL.
  app.post('/api/jobs', uploadMiddleware, (req, res) => {
    const body = req.body || {};
    let options;
    try {
      options = sanitizeOptions(parseMaybeJson(body.options));
    } catch (e) {
      if (req.file) rmrf(req.file.path);
      throw e;
    }
    let job;
    if (req.file) {
      job = {
        id: req.jobId,
        source: { type: 'file', name: req.file.originalname || 'upload.mp4' },
        videoPath: req.file.path,
        sizeBytes: req.file.size,
      };
    } else {
      const url = String(body.url || '').trim();
      if (!url) throw new HttpError(400, 'Send a video file (multipart field "file") or a JSON body with "url"');
      let u;
      try { u = new URL(url); } catch { throw new HttpError(400, 'That URL is not valid'); }
      if (!/^https?:$/.test(u.protocol)) throw new HttpError(400, 'Only http(s) URLs are supported');
      job = { id: store.newId('job'), source: { type: 'url', name: url, url }, videoPath: null };
    }
    const doc = store.insert('jobs', {
      ...job,
      status: 'queued',
      progress: 0,
      stage: 'Queued',
      error: null,
      durationSec: null,
      width: null,
      height: null,
      options,
      clipIds: [],
      thumb: null,
      analyzer: getSettings().anthropicApiKey ? 'claude' : 'heuristic',
    });
    enqueueJob(doc.id);
    res.status(201).json(store.get('jobs', doc.id));
  });

  app.get('/api/jobs', (_req, res) => res.json(store.list('jobs')));

  app.get('/api/jobs/:id', (req, res) => {
    const job = getJobOr404(req.params.id);
    res.json({ job, clips: clipsOf(job) });
  });

  app.delete('/api/jobs/:id', (req, res) => {
    const job = getJobOr404(req.params.id);
    deleteJobData(job);
    res.json({ ok: true });
  });

  // Restart a failed / canceled job (or re-pick clips with {reanalyze: true}).
  app.post('/api/jobs/:id/retry', (req, res) => {
    const job = getJobOr404(req.params.id);
    if (isJobActive(job.id)) throw new HttpError(409, 'Job is already running');
    const patch = { status: 'queued', stage: 'Queued', error: null, progress: 0 };
    if (req.body?.options) patch.options = sanitizeOptions(parseMaybeJson(req.body.options), job.options);
    if (req.body?.reanalyze) {
      for (const c of clipsOf(job)) deleteClipData(c);
      rmrf(path.join(paths.work, job.id, 'analysis.json'));
      patch.clipIds = [];
    }
    if (req.body?.retranscribe) {
      rmrf(path.join(paths.work, job.id, 'transcript.json'));
      rmrf(path.join(paths.work, job.id, 'transcript.partial.json'));
    }
    store.update('jobs', job.id, patch);
    enqueueJob(job.id);
    res.json(store.get('jobs', job.id));
  });

  app.post('/api/jobs/:id/cancel', (req, res) => {
    const job = getJobOr404(req.params.id);
    const stopped = cancelJob(job.id);
    if (stopped && job.status === 'queued') store.update('jobs', job.id, { status: 'canceled', stage: 'Canceled' });
    res.json(store.get('jobs', job.id));
  });

  // A frame of the source video (for the facecam picker).
  app.get('/api/jobs/:id/frame', async (req, res) => {
    const job = getJobOr404(req.params.id);
    if (!job.videoPath || !fileExists(job.videoPath)) throw new HttpError(409, 'The source video is not available yet');
    const dur = job.durationSec || 0;
    let t = Number(req.query.t);
    if (!Number.isFinite(t)) t = dur ? dur * 0.25 : 5;
    if (dur) t = Math.min(Math.max(0, t), Math.max(0, dur - 0.5));
    const width = Math.round(num(req.query.w, 160, 1920, 960));
    const jpg = await grabFrame(job.videoPath, t, { width });
    if (!jpg?.length) throw new HttpError(500, 'Could not grab a frame at that time');
    res.set('Content-Type', 'image/jpeg').set('Cache-Control', 'private, max-age=3600').send(jpg);
  });

  // ---------------------------------------------------------------- clips

  app.get('/api/clips', (req, res) => {
    const jobId = req.query.jobId;
    res.json(store.list('clips', jobId ? (c) => c.jobId === jobId : undefined));
  });

  app.get('/api/clips/:id', (req, res) => res.json(getClipOr404(req.params.id)));

  const applyClipPatch = (clip, body) => {
    const job = store.get('jobs', clip.jobId);
    const patch = {};
    const str = (v, max) => String(v ?? '').slice(0, max);
    if ('hook' in body) patch.hook = str(body.hook, 120).trim();
    if ('title' in body) patch.title = str(body.title, 100).trim();
    if ('description' in body) patch.description = str(body.description, 5000);
    if ('hashtags' in body) {
      const list = Array.isArray(body.hashtags) ? body.hashtags : String(body.hashtags || '').split(/[\s,]+/);
      patch.hashtags = [...new Set(list.map((t) => String(t).trim().replace(/^#*/, '#').replace(/[^#\p{L}\p{N}_]/gu, '')).filter((t) => t.length > 1))].slice(0, 30);
    }
    if ('category' in body && typeof body.category === 'string') patch.category = body.category.slice(0, 30);
    let start = clip.start; let end = clip.end;
    if ('start' in body || 'end' in body) {
      const dur = job?.durationSec || Infinity;
      start = 'start' in body ? Number(body.start) : clip.start;
      end = 'end' in body ? Number(body.end) : clip.end;
      if (!Number.isFinite(start) || !Number.isFinite(end)) throw new HttpError(400, 'start/end must be numbers (seconds)');
      start = Math.max(0, start); end = Math.min(dur, end);
      if (end - start < 1) throw new HttpError(400, 'Clip must be at least 1 second long');
      if (end - start > 180) throw new HttpError(400, 'Clip must be at most 180 seconds long');
      patch.start = Math.round(start * 100) / 100;
      patch.end = Math.round(end * 100) / 100;
      const t = loadTranscript(clip.jobId);
      if (t) patch.transcript = textIn(t.words, patch.start, patch.end);
      if (!clip.file) patch.durationSec = Math.round((patch.end - patch.start) * 100) / 100;
    }
    if ('coldOpen' in body) {
      const co = body.coldOpen;
      if (co === null || co === false) patch.coldOpen = null;
      else if (co && Number.isFinite(Number(co.start)) && Number.isFinite(Number(co.end)) && Number(co.end) > Number(co.start)) {
        patch.coldOpen = { start: Number(co.start), end: Math.min(Number(co.end), Number(co.start) + 1.5) };
      } else throw new HttpError(400, 'coldOpen must be null or {start, end}');
    }
    // Drop a cold open that no longer fits inside the clip.
    const co = 'coldOpen' in patch ? patch.coldOpen : clip.coldOpen;
    if (co && (co.start < start || co.end > end + 0.01)) patch.coldOpen = null;
    if ('style' in body) patch.style = sanitizeStyle(body.style, clip.style);
    return Object.keys(patch).length ? store.update('clips', clip.id, patch) : clip;
  };

  app.patch('/api/clips/:id', (req, res) => {
    const clip = getClipOr404(req.params.id);
    res.json(applyClipPatch(clip, req.body || {}));
  });

  app.post('/api/clips/:id/render', (req, res) => {
    let clip = getClipOr404(req.params.id);
    const job = store.get('jobs', clip.jobId);
    if (!job) throw new HttpError(409, 'The job for this clip no longer exists');
    if (isJobActive(job.id) || ACTIVE_STATUSES.includes(job.status)) {
      throw new HttpError(409, 'This VOD is still being processed — try again when it is done');
    }
    if (req.body && Object.keys(req.body).length) clip = applyClipPatch(clip, req.body);
    requestClipRender(clip.id);
    res.status(202).json(store.get('clips', clip.id));
  });

  app.delete('/api/clips/:id', (req, res) => {
    const clip = getClipOr404(req.params.id);
    deleteClipData(clip);
    res.json({ ok: true });
  });

  // ---------------------------------------------------------------- system

  app.get('/api/system', (_req, res) => {
    const s = getSettings();
    res.json({
      ffmpeg: fs.existsSync(FFMPEG),
      ytdlp: ytdlpInstalled(),
      analyzer: s.anthropicApiKey ? 'claude' : 'heuristic',
      claudeModel: s.claudeModel,
      transcription: s.transcription.provider,
      localModel: s.transcription.localModel,
      localModelReady: localModelReady(s.transcription.localModel),
      queue: queueSnapshot(),
    });
  });
}

export function resumeJobs() {
  resume();
}
