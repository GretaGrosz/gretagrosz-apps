import { motion } from 'framer-motion';
import { scoreColor } from '../lib/meta';

export function ScoreRing({ score, size = 44, stroke = 4, label = true }: { score: number; size?: number; stroke?: number; label?: boolean }) {
  const s = Math.max(0, Math.min(100, Math.round(score || 0)));
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const color = scoreColor(s);
  return (
    <div
      className="relative grid shrink-0 place-items-center rounded-full bg-ink-950/80 backdrop-blur-md"
      style={{ width: size, height: size, boxShadow: `0 0 18px -4px ${color}88` }}
      title={`Virality score ${s}/100`}
    >
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="rgba(255,255,255,.1)" strokeWidth={stroke} fill="none" />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: c * (1 - s / 100) }}
          transition={{ duration: 1.1, ease: [0.2, 0.8, 0.2, 1], delay: 0.1 }}
        />
      </svg>
      {label && (
        <span
          className="absolute inset-0 grid place-items-center font-display font-extrabold tabular"
          style={{ color, fontSize: size * 0.34 }}
        >
          {s}
        </span>
      )}
    </div>
  );
}
