// ClipGoblin server: REST API + SSE + static web app + rendered media.
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import { paths, PORT, HOST, getSettings, updateSettings, publicSettings } from './config.js';
import { sseHandler } from './events.js';
import { flush } from './store.js';
import { registerJobRoutes, resumeJobs } from './routes/jobs.js';
import { registerPublishRoutes, startScheduler } from './publish/index.js';

const app = express();
app.use(express.json({ limit: '2mb' }));

app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.get('/api/events', sseHandler);

app.get('/api/settings', (_req, res) => res.json(publicSettings()));
app.put('/api/settings', (req, res) => res.json(publicSettings(updateSettings(req.body ?? {}))));

const ctx = { app, paths, getSettings, baseUrl: `http://localhost:${PORT}` };
registerJobRoutes(app, ctx);
registerPublishRoutes(app, ctx);

app.use('/media/clips', express.static(paths.clips, { maxAge: '1h' }));

if (fs.existsSync(paths.webDist)) {
  app.use(express.static(paths.webDist));
  app.get(/^(?!\/(api|media)\/).*/, (_req, res) => res.sendFile(path.join(paths.webDist, 'index.html')));
}

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: err.message || 'Server error' });
});

app.listen(PORT, HOST, () => {
  console.log(`\n  👺 ClipGoblin running → http://localhost:${PORT}\n`);
  resumeJobs();
  startScheduler(ctx);
});

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => { flush(); process.exit(0); });
}
