// Highlight finder. With an Anthropic key, Claude reads the whole timestamped transcript plus the
// loudness spikes and picks clips like a top short-form editor. Without one, a heuristic scorer
// (loudness spikes + hype keywords + speech rate) still produces sensible, ranked clips.
import Anthropic from '@anthropic-ai/sdk';
import { meanDb } from './audio.js';
import { fmtTime, round, clamp, throwIfAborted, CanceledError } from './util.js';

export const CATEGORIES = ['funny', 'rage', 'wtf', 'clutch', 'wholesome', 'cringe', 'weird'];

// ---------------------------------------------------------------- transcript helpers

const SENT_END = /[.!?…]["')\]]*$/;

/** Group words into readable lines (sentence-ish), breaking on punctuation, pauses, length. */
export function buildLines(words, { maxWords = 16, gap = 0.7 } = {}) {
  const lines = [];
  let cur = null;
  words.forEach((w, i) => {
    if (cur && (w.s - words[i - 1].e > gap || cur.n >= maxWords)) { lines.push(cur); cur = null; }
    if (!cur) cur = { s: w.s, e: w.e, text: '', i0: i, i1: i, n: 0 };
    cur.text += (cur.n ? ' ' : '') + w.w;
    cur.e = w.e; cur.i1 = i; cur.n++;
    if (SENT_END.test(w.w) && cur.n >= 3) { lines.push(cur); cur = null; }
  });
  if (cur) lines.push(cur);
  return lines;
}

export function wordsIn(words, a, b) {
  return words.filter((w) => w.e > a && w.s < b);
}
export function textIn(words, a, b) {
  return wordsIn(words, a, b).map((w) => w.w).join(' ');
}

/**
 * Snap [s, e] to word boundaries and enforce min/max duration. Keeps untranscribed tails/heads
 * (screams and laughter are often not in the transcript) when the requested edge sits in a pause.
 */
export function snapRange(words, s, e, { minSec, maxSec, durationSec, energy }) {
  // A head/tail that sits in a pause is kept only if it's loud (untranscribed scream/laugh).
  const loudGap = (a, b) => !energy || b - a < 0.2 || meanDb(energy, a, b) > (energy.speechDb ?? -25) - 8;
  s = clamp(s, 0, durationSec); e = clamp(e, s + 0.5, durationSec);
  if (!words.length) return { start: round(s), end: round(clamp(e, s + minSec, Math.min(durationSec, s + maxSec))) };

  // --- start
  let i = words.findIndex((w) => w.e > s + 0.05);
  if (i < 0) i = words.length - 1;
  if (words[i].s < s && s - words[i].s > (words[i].e - words[i].s) / 2 && i + 1 < words.length && words[i + 1].s - s < 1.2) i++; // mid-word: move to next word if close
  const prevEnd = i > 0 ? words[i - 1].e : 0;
  let start = s < words[i].s - 0.15 && loudGap(s, words[i].s) ? Math.max(s, prevEnd + 0.05) : Math.max(prevEnd + 0.02, words[i].s - 0.12);
  start = clamp(start, 0, durationSec);

  // --- end
  let j = -1;
  for (let k = words.length - 1; k >= 0; k--) if (words[k].s < e - 0.05) { j = k; break; }
  if (j < i) j = i;
  const nextStart = j + 1 < words.length ? words[j + 1].s : durationSec;
  let end = e > words[j].e + 0.25 && loudGap(words[j].e, e) ? Math.min(e, nextStart - 0.05) : Math.min(words[j].e + 0.3, nextStart - 0.02);
  end = Math.max(end, words[j].e + 0.05);

  // --- min duration: add setup before the start first (the ending/payoff is sacred), stopping at
  // a sentence start once long enough; then extend forward if still short.
  while (end - start < minSec && i > 0 && end - words[i - 1].s <= maxSec && words[i].s - words[i - 1].e < 1.5) {
    i--;
    start = Math.max(i > 0 ? words[i - 1].e + 0.02 : 0, words[i].s - 0.12);
  }
  if (end - start >= minSec) {
    // Nudge back to the beginning of the sentence if it's close.
    for (let k = i; k > 0 && words[i].s - words[k].s < 7 && end - words[k].s <= maxSec; k--) {
      if (SENT_END.test(words[k - 1].w) || words[k].s - words[k - 1].e > 0.6) {
        start = Math.max(words[k - 1].e + 0.02, words[k].s - 0.12);
        break;
      }
    }
  }
  while (end - start < minSec && j + 1 < words.length && words[j + 1].e - start <= maxSec) {
    j++;
    end = Math.min(words[j].e + 0.3, j + 1 < words.length ? words[j + 1].s - 0.02 : durationSec);
  }
  if (end - start < minSec) end = Math.min(durationSec, start + minSec);
  if (end - start < minSec) start = Math.max(0, end - minSec);

  // --- max duration: cut back to a sentence end if possible
  if (end - start > maxSec) {
    const limit = start + maxSec;
    let best = -1; let bestSent = -1;
    for (let k = i; k < words.length && words[k].e + 0.25 <= limit; k++) {
      best = k;
      if (SENT_END.test(words[k].w) && words[k].e - start >= Math.max(minSec, maxSec * 0.6)) bestSent = k;
    }
    const k = bestSent >= 0 ? bestSent : best;
    end = k >= 0 ? Math.min(words[k].e + 0.25, limit) : limit;
  }
  return { start: round(start), end: round(Math.min(end, durationSec)) };
}

function snapColdOpen(words, co, clip) {
  if (!co || co.start == null || co.end == null) return null;
  let s = Math.max(co.start, clip.start); let e = Math.min(co.end, clip.end);
  if (e - s < 0.4) return null;
  // Snap edges outward to word boundaries but never exceed 1.5 s.
  const inside = wordsIn(words, s, e);
  if (inside.length) {
    if (inside[0].s < s && s - inside[0].s < 0.4) s = inside[0].s;
    const last = inside[inside.length - 1];
    if (last.e > e && last.e - e < 0.4) e = last.e;
  }
  e = Math.min(e, s + 1.5);
  // Pointless if the payoff is right at the start of the clip.
  if (s - clip.start < 3) return null;
  return { start: round(s), end: round(e) };
}

function cleanHashtags(tags) {
  const out = [];
  for (let t of tags || []) {
    t = String(t).trim().replace(/^#*/, '#').replace(/[^#\p{L}\p{N}_]/gu, '');
    if (t.length > 1 && !out.some((x) => x.toLowerCase() === t.toLowerCase())) out.push(t);
  }
  if (!out.some((t) => t.toLowerCase() === '#shorts')) out.unshift('#shorts');
  return out.slice(0, 6);
}

/** Validate raw candidates → snapped, de-overlapped, ranked clip specs. */
export function finalizeClips(raw, { words, options, durationSec, energy }) {
  const { minSec, maxSec, maxClips } = options;
  const specs = [];
  for (const c of raw) {
    const s = Number(c.start); const e = Number(c.end);
    if (!Number.isFinite(s) || !Number.isFinite(e) || e <= s) continue;
    const r = snapRange(words, s, e, { minSec, maxSec, durationSec, energy });
    if (r.end - r.start < Math.min(minSec, 5)) continue;
    const spec = {
      start: r.start,
      end: r.end,
      score: clamp(Math.round(Number(c.score) || 50), 0, 100),
      hook: String(c.hook || '').trim().slice(0, 80),
      title: String(c.title || c.hook || 'Stream highlight').trim().slice(0, 90),
      description: String(c.description || '').trim().slice(0, 2000),
      hashtags: cleanHashtags(c.hashtags),
      category: CATEGORIES.includes(c.category) ? c.category : 'funny',
      why: String(c.why || '').trim().slice(0, 300),
    };
    spec.coldOpen = snapColdOpen(words, c.coldOpen ?? c.cold_open, spec);
    spec.transcript = textIn(words, spec.start, spec.end);
    specs.push(spec);
  }
  // Highest score wins any overlap.
  specs.sort((a, b) => b.score - a.score);
  const kept = [];
  for (const c of specs) {
    const overlaps = kept.some((k) => Math.min(k.end, c.end) - Math.max(k.start, c.start) > 1);
    if (!overlaps) kept.push(c);
    if (kept.length >= maxClips) break;
  }
  return kept.map((c, i) => ({ ...c, rank: i + 1 }));
}

// ---------------------------------------------------------------- Claude

export const SYSTEM_PROMPT = `You are the head editor of a top-tier clip channel that turns long Twitch/YouTube/Kick stream VODs into vertical Shorts, TikToks and Reels that routinely do millions of views. You have an instinct for what makes a stranger stop scrolling in the first second and watch to the end — and then watch again.

You will receive the full timestamped transcript of a stream VOD (auto-transcribed; expect some mis-heard words) interleaved with loudness spikes from the audio track. Pick the moments that will perform best as standalone short-form clips.

## What wins
- A strong first 1–2 seconds. Start ON the action, on the line that sets up the payoff, or mid-reaction. Never start on dead air, greetings, "so anyway", "okay chat", or a slow wind-up.
- Self-contained. Someone with zero context on this streamer, game or community must understand what is happening within ~3 seconds. If it needs something said earlier in the stream, skip it — or start earlier so the setup is included.
- A clear payoff: punchline, fail, death, rage outburst, absurd twist, reveal, clutch play, or a genuine emotional reaction. End roughly 0.5–2 s after the payoff/reaction peaks. Cut the tail; do not let it fizzle into small talk.
- Loopability is a bonus: endings that flow back into the opening line make people rewatch.
- Best categories, roughly in order: genuine reactions (screaming, laughing fits, disbelief), rage, absurd non-sequiturs and weird moments, funny fails and deaths, unhinged or spicy hot takes, chaotic chat interactions that stand alone, wholesome surprises, clutch plays with hype reactions.
- Avoid: moments that need prior context, long explanations, tutorials, sponsor reads, routine sub/donation reading (unless something funny happens), menus/loading/AFK, inside jokes, anything mean-spirited toward a private person.

## Signals
- \`<<LOUD +N dB, Xs>>\` markers are moments where the audio jumps well above the streamer's normal level. Screams, laughter and hype are often NOT transcribed, so a loud marker with little text nearby is frequently the best reaction in the stream. Treat clusters of loud markers plus exclamations ("no way", "what", "bro", profanity, laughter) as strong highlight candidates.
- \`(… Ns silence …)\` marks a pause in speech (gameplay, reading chat silently, or a reaction that wasn't transcribed).
- Bursts of fast speech usually mean excitement.

## Rules for each clip
- start/end: seconds from the VOD, using the bracketed timestamps. Start just before the first word you want (we snap to word boundaries). Duration must be between MIN and MAX seconds (given below); the sweet spot is 20–40 s — shorter is better when the story is complete.
- Clips must not overlap.
- cold_open: optional pattern interrupt. A ≤1.5 s slice of the payoff (the most extreme reaction or the punchline) that we flash at the very start before rewinding to the beginning. Only use it when the payoff is at least ~5 s into the clip and seeing it first creates a "how did we get here?" itch. It must lie inside the clip. Otherwise null.
- hook: on-screen text shown for the first ~3 s. Max 7 words. Create a curiosity gap without spoiling the payoff and without lying: "wait for it" variants, weird-specific details ("he lost a fight to a DOOR"), stakes ("1 hp and chat is screaming"), POV framing. Casual lowercase voice with ONE word in caps for emphasis works well. At most one emoji, and the hook must still work if the emoji is not rendered.
- title: ≤ 90 characters for YouTube Shorts / TikTok. Punchy, specific, searchable; casual style; optionally one emoji; no hashtags.
- description: 1–2 short conversational sentences for the post caption; ending with a question that invites comments is good.
- hashtags: 3–6. Always include #shorts, mix broad (#fyp, #twitch, #gaming, #streamer, #funny) with niche tags (game name, topic).
- category: one of funny, rage, wtf, clutch, wholesome, cringe, weird.
- score: predicted retention/virality 0–100. Be calibrated: most usable clips land 50–80; reserve 90+ for truly exceptional moments.
- why: one sentence on why this will hold attention.

Return the clips sorted best-first. Quality over quantity: return fewer than the maximum if the VOD lacks great moments, but return at least one clip if anything is usable.`;

export const CLIP_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  required: ['clips'],
  properties: {
    clips: {
      type: 'array',
      items: {
        type: 'object',
        additionalProperties: false,
        required: ['start', 'end', 'cold_open', 'hook', 'title', 'description', 'hashtags', 'category', 'score', 'why'],
        properties: {
          start: { type: 'number', description: 'Clip start, seconds from VOD start' },
          end: { type: 'number', description: 'Clip end, seconds from VOD start' },
          cold_open: {
            anyOf: [
              { type: 'object', additionalProperties: false, required: ['start', 'end'], properties: { start: { type: 'number' }, end: { type: 'number' } } },
              { type: 'null' },
            ],
          },
          hook: { type: 'string' },
          title: { type: 'string' },
          description: { type: 'string' },
          hashtags: { type: 'array', items: { type: 'string' } },
          category: { type: 'string', enum: CATEGORIES },
          score: { type: 'integer' },
          why: { type: 'string' },
        },
      },
    },
  },
};

/** Compact transcript for the prompt: "[734.2] text" lines + loudness markers + silence markers. */
export function buildPromptTranscript(words, energy) {
  const lines = buildLines(words);
  const items = lines.map((l) => ({ t: l.s, text: `[${l.s.toFixed(1)}] ${l.text}` }));
  for (let k = 1; k < lines.length; k++) {
    const gap = lines[k].s - lines[k - 1].e;
    if (gap >= 3) items.push({ t: lines[k - 1].e + 0.01, text: `[${lines[k - 1].e.toFixed(1)}] (… ${Math.round(gap)}s silence …)` });
  }
  for (const sp of energy?.spikes || []) {
    items.push({ t: sp.t - 0.001, text: `[${sp.t.toFixed(1)}] <<LOUD +${Math.round(sp.rise)} dB, ${(sp.end - sp.t).toFixed(1)}s>>` });
  }
  items.sort((a, b) => a.t - b.t);
  return items.map((i) => i.text).join('\n');
}

const FALLBACK_MODELS = new Set(['claude-opus-5-5', 'claude-opus-5', 'claude-fable-5-1', 'claude-fable-5', 'claude-sonnet-5-5']);

/** Extract the clip list from a Claude Message (throws a readable error on refusal/truncation). */
export function parseClaudeResponse(msg) {
  if (msg.stop_reason === 'refusal') {
    const cat = msg.stop_details?.category ? ` (${msg.stop_details.category})` : '';
    throw new Error(`Claude declined to analyze this VOD${cat}`);
  }
  const text = (msg.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('');
  if (!text.trim()) throw new Error(`Claude returned no clip list (stop_reason: ${msg.stop_reason})`);
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    // Be forgiving if something wrapped the JSON.
    const m = text.match(/\{[\s\S]*\}/);
    try { json = m && JSON.parse(m[0]); } catch { json = null; }
  }
  if (!json || !Array.isArray(json.clips)) {
    throw new Error(msg.stop_reason === 'max_tokens' ? 'Claude ran out of output tokens before finishing the clip list' : 'Claude returned an unreadable clip list');
  }
  return json.clips.map((c) => ({ ...c, coldOpen: c.cold_open ?? null }));
}

export async function analyzeWithClaude({ words, energy, options, durationSec, settings, title, signal, onStage, client }) {
  client ??= new Anthropic({ apiKey: settings.anthropicApiKey, maxRetries: 3, timeout: 20 * 60 * 1000 });
  const model = settings.claudeModel || 'claude-opus-5-5';
  const transcript = buildPromptTranscript(words, energy);
  const user = `VOD: ${title || 'stream VOD'}
Duration: ${fmtTime(durationSec)} (${Math.round(durationSec)} s)
Clip length: MIN ${options.minSec} s, MAX ${options.maxSec} s
Return at most ${options.maxClips} clips.

<transcript>
${transcript}
</transcript>

Pick the best clips now.`;

  const params = {
    model,
    max_tokens: 64000,
    thinking: { type: 'adaptive' },
    output_config: { effort: 'high', format: { type: 'json_schema', schema: CLIP_SCHEMA } },
    system: SYSTEM_PROMPT,
    messages: [{ role: 'user', content: user }],
  };
  if (FALLBACK_MODELS.has(model)) {
    params.betas = ['server-side-fallback-2026-07-01'];
    params.fallbacks = 'default';
  }

  const t0 = Date.now();
  const tick = setInterval(() => onStage?.(`Claude is watching the VOD… ${Math.round((Date.now() - t0) / 1000)}s`), 2000);
  try {
    onStage?.('Claude is watching the VOD…');
    let msg;
    try {
      const stream = client.beta.messages.stream(params, { signal });
      let chars = 0;
      stream.on('text', (d) => {
        chars += d.length;
        onStage?.(`Claude is writing the clip list… ${chars} chars`);
      });
      msg = await stream.finalMessage();
    } catch (e) {
      if (signal?.aborted) throw new CanceledError();
      if (e instanceof Anthropic.AuthenticationError) throw new Error('Anthropic rejected the API key — check Settings');
      if (e instanceof Anthropic.PermissionDeniedError) throw new Error(`Anthropic API: permission denied for ${model}`);
      if (e instanceof Anthropic.NotFoundError) throw new Error(`Model "${model}" not found — check Settings → Claude model`);
      if (e instanceof Anthropic.RateLimitError) throw new Error('Anthropic rate limit hit — try again in a minute');
      if (e instanceof Anthropic.BadRequestError) throw new Error(`Anthropic API rejected the request: ${e.message}`);
      if (e instanceof Anthropic.APIError) throw new Error(`Anthropic API error ${e.status ?? ''}: ${e.message}`);
      throw e;
    }
    const raw = parseClaudeResponse(msg);
    const servedBy = msg.model;
    return { raw, model: servedBy, usage: msg.usage };
  } finally {
    clearInterval(tick);
  }
}

// ---------------------------------------------------------------- heuristic

const KEYWORDS = [
  // [regex, weight, category]
  [/\bno+ way\b/, 3, 'wtf'], [/\bwhat the\b/, 3, 'wtf'], [/\bwtf\b/, 3, 'wtf'], [/\bwhat\??!+/, 2, 'wtf'],
  [/\bhow\b.*\?/, 1, 'wtf'], [/\bhaunted|cursed|impossible|insane|crazy|unreal|wild\b/, 2, 'wtf'],
  [/\bbro+\b|\bbruh+\b|\bdude\b/, 1.5, 'funny'], [/\blmf?ao+\b|\blo+l\b|\brofl\b/, 3, 'funny'],
  [/\b(ha ?){2,}|\bhaha+|\bhehe+/, 3, 'funny'], [/\bi'?m (literally )?dead\b|\bi'?m crying\b/, 3, 'funny'],
  [/\boh my god\b|\bomg\b|\bholy\b|\bjesus\b/, 2.5, 'wtf'], [/\bclip (that|it|this)\b/, 4, 'funny'],
  [/\blet'?s go+\b|\bclutch\b|\bpog\w*\b|\bgg\b|\bwe did it\b/, 3, 'clutch'],
  [/\bf+u+c+k+\w*|\bshit\w*|\bdamn\w*|\bbitch\w*|\bwhy+\b.*!|\bare you (kidding|serious)\b|\bi hate\b/, 2.5, 'rage'],
  [/\brun+\b|\bhelp+\b|\bscream\w*|\bchasing\b/, 2, 'wtf'],
  [/\bthank you so much\b|\blove you\b|\bwholesome\b|\bbest\b|\bgifted\b/, 1.5, 'wholesome'],
  [/\bhot take\b|\bfight me\b|\bunpopular opinion\b/, 3, 'weird'],
  [/\bcringe\b|\bawkward\b|\bembarrass\w*/, 2, 'cringe'],
  [/\bweird\b|\bwhy is\b|\bwhat is (that|this)\b/, 2, 'weird'],
];

const STOP = new Set('the a an and or but so to of in on at for with is are was were be been it this that i you he she we they me my your our his her them just like okay ok yeah oh um uh really very what why how when where there here then than im its dont cant wont gonna going chat bro literally actually right well get got have has had do does did not no yes one two three all some any can will would should could about out up down over into from by as if because'.split(' '));

function hashStr(s) { let h = 2166136261; for (const c of s) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }

const HOOKS = {
  funny: ['WAIT FOR IT', 'he really said that', 'this is NOT how it was supposed to go', 'i was not ready for this', 'chat lost it after this', 'the ending got me'],
  wtf: ['what did we just WITNESS', 'nobody expected this', 'wait… what just happened', 'this game is CURSED', 'watch the corner', 'he did NOT see that coming'],
  rage: ['he was so calm… until this', 'this broke him', 'the rage was justified', '3 seconds from losing it'],
  clutch: ['1 in a million play', 'chat did NOT believe this', 'how did this WORK', 'the clutch of the year'],
  wholesome: ['this made his whole day', 'the most wholesome moment', 'chat came through'],
  cringe: ['i can\'t watch this', 'the secondhand embarrassment', 'this aged badly instantly'],
  weird: ['this take is UNHINGED', 'nobody asked but he said it', 'the strangest thing on stream'],
};
const EMOJI = { funny: '😭', wtf: '💀', rage: '😤', clutch: '🔥', wholesome: '🥹', cringe: '😬', weird: '🤨' };

/** Score every second of the VOD and grow clips around the hottest moments. */
export function analyzeHeuristic({ words, energy, options, durationSec, title }) {
  const n = Math.max(1, Math.ceil(durationSec));
  const heat = new Float64Array(n);
  const catVotes = Array.from({ length: n }, () => ({}));
  const vote = (t, cat, w) => { const i = clamp(Math.floor(t), 0, n - 1); catVotes[i][cat] = (catVotes[i][cat] || 0) + w; };

  // Keyword + punctuation signals.
  const lines = buildLines(words);
  for (const l of lines) {
    const lower = l.text.toLowerCase();
    for (const [re, w, cat] of KEYWORDS) {
      if (re.test(lower)) { heat[clamp(Math.floor(l.s), 0, n - 1)] += w; vote(l.s, cat, w); }
    }
    const excl = (l.text.match(/!/g) || []).length;
    const caps = l.text.split(/\s+/).filter((t) => t.length >= 2 && /^[A-Z!?']+$/.test(t)).length;
    heat[clamp(Math.floor(l.s), 0, n - 1)] += excl * 1.2 + caps * 0.8;
  }
  // Loudness spikes.
  for (const sp of energy?.spikes || []) {
    const w = clamp(sp.rise / 3, 0.5, 5) * (1 + Math.min(2, sp.end - sp.t) / 2);
    heat[clamp(Math.floor(sp.peakT ?? sp.t), 0, n - 1)] += w;
  }
  // Speech rate (excited fast talking).
  const rate = new Float64Array(n);
  for (const w of words) rate[clamp(Math.floor(w.s), 0, n - 1)]++;
  const activeRates = [...rate].filter((r) => r > 0).sort((a, b) => a - b);
  const medRate = activeRates[Math.floor(activeRates.length / 2)] || 2;
  for (let i = 0; i < n; i++) if (rate[i] > medRate * 1.4) heat[i] += 0.6 * (rate[i] / medRate - 1);

  // Smooth over ~5 s.
  const smooth = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    let s = 0;
    for (let k = -3; k <= 3; k++) s += (heat[i + k] || 0) * (1 - Math.abs(k) / 4);
    smooth[i] = s;
  }

  // Peak picking: greedy, peaks at least minSec apart.
  const order = [...smooth.keys()].sort((a, b) => smooth[b] - smooth[a]);
  const peaks = [];
  for (const i of order) {
    if (smooth[i] <= 0.5) break;
    if (peaks.some((p) => Math.abs(p - i) < options.minSec)) continue;
    peaks.push(i);
    if (peaks.length >= options.maxClips * 3) break;
  }
  const maxHeat = smooth[peaks[0]] || 1;

  const raw = [];
  for (const p of peaks) {
    // Start at the line that begins ~6-10 s before the peak (setup), end ~3-5 s after it (reaction).
    const setupTarget = p - clamp(options.minSec * 0.5, 5, 10);
    // Prefer lines that begin a sentence (or follow a pause) so the clip never opens mid-thought.
    const isSentStart = (l) => l.i0 === 0 || SENT_END.test(words[l.i0 - 1].w) || l.s - words[l.i0 - 1].e > 0.6;
    const pool = lines.filter((l) => l.s <= Math.max(0, p - 2) && l.s >= p - options.maxSec * 0.6);
    const sentPool = pool.filter(isSentStart);
    const startLine = (sentPool.length ? sentPool : pool).reduce((best, l) => (!best || Math.abs(l.s - setupTarget) < Math.abs(best.s - setupTarget) ? l : best), null);
    const start = startLine ? startLine.s : Math.max(0, p - 6);
    const endTarget = Math.max(p + 4, start + options.minSec);
    // End on a natural beat: keep going through lines that follow without a real pause (the payoff
    // and the reaction to it usually come back-to-back), stopping before maxSec.
    let k = lines.findIndex((l) => l.e >= endTarget);
    if (k < 0) k = lines.length - 1;
    while (k >= 0 && k + 1 < lines.length && lines[k + 1].s - lines[k].e < 1.0 && lines[k + 1].e - start <= options.maxSec * 0.95) k++;
    const endLine = lines[k];
    let end = endLine ? Math.max(endLine.e + 0.3, start + options.minSec) : start + options.minSec;
    end = Math.min(end, start + options.maxSec, durationSec);

    // Category by votes in the window.
    const tally = {};
    for (let t = Math.floor(start); t < Math.ceil(end) && t < n; t++) for (const [c, v] of Object.entries(catVotes[t])) tally[c] = (tally[c] || 0) + v;
    const category = Object.entries(tally).sort((a, b) => b[1] - a[1])[0]?.[0] || 'funny';

    // Score: window heat density + peak strength.
    let windowHeat = 0;
    for (let t = Math.floor(start); t < Math.ceil(end) && t < n; t++) windowHeat += heat[t];
    const density = windowHeat / Math.sqrt(Math.max(5, end - start));
    const score = Math.round(clamp(38 + 35 * (smooth[p] / maxHeat) + 4 * Math.min(5, density / 2), 30, 92));

    // Cold open: the loudest moment of the clip if it's far enough in.
    let coldOpen = null;
    const spikesIn = (energy?.spikes || []).filter((s) => s.peakT > start + 5 && s.peakT < end - 0.5).sort((a, b) => b.rise - a.rise);
    if (options.coldOpen !== false && spikesIn.length) {
      const sp = spikesIn[0];
      coldOpen = { start: Math.max(start, sp.peakT - 0.5), end: Math.min(end, sp.peakT + 1.0) };
    }

    // Quote: the punchiest short line near the peak (for titles).
    const near = lines.filter((l) => l.s >= start && l.e <= end + 0.5);
    const punchy = near
      .filter((l) => l.n >= 3 && !/^(ha|he|lol|lmao)/i.test(l.text))
      .map((l) => ({ l, v: (l.text.match(/[!?]/g) || []).length * 2 + (meanDb(energy, l.s, l.e) - energy.speechDb) / 3 - Math.abs(l.s - p) / 10 - Math.max(0, l.n - 8) }))
      .sort((a, b) => b.v - a.v)[0]?.l;
    let quote = punchy ? punchy.text.replace(/\s+/g, ' ').trim() : '';
    const qWords = quote.split(' ');
    if (qWords.length > 9) quote = `${qWords.slice(0, 9).join(' ')}…`;
    quote = quote.replace(/[.,]+$/, '');

    const hookList = HOOKS[category] || HOOKS.funny;
    const h = hashStr(`${start}`);
    const hook = `${hookList[h % hookList.length]} ${EMOJI[category] || ''}`.trim();
    const titleText = quote ? `"${quote}" ${EMOJI[category] || ''}`.trim() : `${hookList[(h + 1) % hookList.length]} ${EMOJI[category] || ''}`;

    // Hashtags: platform + category + most frequent meaningful word.
    const freq = {};
    for (const w of wordsIn(words, start, end)) {
      const k = w.w.toLowerCase().replace(/[^a-z0-9]/g, '');
      if (k.length >= 4 && !STOP.has(k) && !/ly$|ing$/.test(k)) freq[k] = (freq[k] || 0) + 1;
    }
    const topic = Object.entries(freq).filter(([, c]) => c >= 2).sort((a, b) => b[1] - a[1] || b[0].length - a[0].length)[0]?.[0];
    const hashtags = ['#shorts', '#twitch', '#fyp', `#${category === 'clutch' ? 'gaming' : category}`, '#streamer'];
    if (topic) hashtags.push(`#${topic}`);

    raw.push({
      start, end, score, category, coldOpen, hook,
      title: titleText.slice(0, 90),
      description: `${quote ? `${quote}… ` : ''}wait for the ending ${EMOJI[category] || ''}\nWould you have survived this? 👇`.trim(),
      hashtags,
      why: `Loud reaction + ${category} keywords around ${fmtTime(p)} (heat ${smooth[p].toFixed(1)}).`,
    });
  }
  return { raw };
}

/** Run Claude if a key is configured (falling back to the heuristic on failure). */
export async function analyze({ words, energy, options, durationSec, settings, title, signal, onStage }) {
  throwIfAborted(signal);
  if (!words.length) {
    // Nothing transcribed (music-only VOD?) — fall back to loudness-only heuristic.
    const { raw } = analyzeHeuristic({ words, energy, options, durationSec, title });
    return { analyzer: 'heuristic', clips: finalizeClips(raw, { words, options, durationSec, energy }), note: 'No speech detected — clips picked from loudness only' };
  }
  if (settings.anthropicApiKey) {
    try {
      const { raw, model } = await analyzeWithClaude({ words, energy, options, durationSec, settings, title, signal, onStage });
      const clips = finalizeClips(raw, { words, options, durationSec, energy });
      if (clips.length) return { analyzer: 'claude', model, clips };
      throw new Error('Claude returned no usable clips');
    } catch (e) {
      if (e.canceled || signal?.aborted) throw e;
      const { raw } = analyzeHeuristic({ words, energy, options, durationSec, title });
      return { analyzer: 'heuristic', clips: finalizeClips(raw, { words, options, durationSec, energy }), note: `Claude analysis failed (${e.message}) — used the built-in heuristic instead` };
    }
  }
  onStage?.('Scoring moments (heuristic — add an Anthropic key for smarter picks)…');
  const { raw } = analyzeHeuristic({ words, energy, options, durationSec, title });
  return { analyzer: 'heuristic', clips: finalizeClips(raw, { words, options, durationSec, energy }) };
}

